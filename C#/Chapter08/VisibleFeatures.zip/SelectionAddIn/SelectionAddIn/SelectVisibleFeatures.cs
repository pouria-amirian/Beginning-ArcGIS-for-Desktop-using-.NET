﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.ArcMapUI;

namespace SelectionAddIn
{
    public class SelectVisibleFeatures : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public SelectVisibleFeatures()
        {
        }

        protected override void OnClick()
        {

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();

            ISpatialFilter spatialFilter = new SpatialFilter();
            spatialFilter.Geometry = (map as IActiveView).Extent;
            spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelContains;

            while (layer != null)
            {
                if (layer is IFeatureLayer2)
                {
                    if (layer.Visible)
                    {
                        IFeatureLayer2 featureLayer = layer as IFeatureLayer2;
                        IFeatureSelection featureSelection = featureLayer as IFeatureSelection;

                        featureSelection.SelectFeatures(spatialFilter, esriSelectionResultEnum.esriSelectionResultNew, false);
                    }
                }
                layer = enumLayer.Next();
            }
            mxdoc.ActiveView.Refresh();
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
