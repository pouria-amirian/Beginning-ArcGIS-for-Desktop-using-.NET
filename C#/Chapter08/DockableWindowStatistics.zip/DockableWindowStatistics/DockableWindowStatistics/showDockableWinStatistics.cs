﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;

namespace DockableWindowStatistics
{
    public class showDockableWinStatistics : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public showDockableWinStatistics()
        {
        }

        protected override void OnClick()
        {
            
            
            
            //UID dockwinID = new UIDClass();
            //dockwinID.Value = ThisAddIn.IDs.dockableStatistics;

            ////UID dockWinID = new UIDClass();
            ////dockWinID.Value = ThisAddIn.IDs.LayerReporter;

            ////IDockableWindow dockableReporter = ArcMap.DockableWindowManager.GetDockableWindow(dockWinID);
            ////dockableReporter.Show(true);

            //IDockableWindow dockablewindow = ArcMap.DockableWindowManager.GetDockableWindow(dockwinID);
            //dockablewindow.Show(true);

            UID dockableWinUID = new UIDClass();
            dockableWinUID.Value = ThisAddIn.IDs.DockableWinStatistics;

            IDockableWindow statsticsDockableWin = ArcMap.DockableWindowManager.GetDockableWindow(dockableWinUID);
            statsticsDockableWin.Show(true);


        }

        protected override void OnUpdate()
        {
        }
    }
}
