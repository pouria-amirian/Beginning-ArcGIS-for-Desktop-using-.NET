﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;


namespace DockableWindowStatistics
{
    /// <summary>
    /// Designer class of the dockable window add-in. It contains user interfaces that
    /// make up the dockable window.
    /// </summary>
    public partial class DockableWinStatistics : UserControl
    {
        public DockableWinStatistics(object hook)
        {
            InitializeComponent();
            this.Hook = hook;
        }

        /// <summary>
        /// Host object of the dockable window
        /// </summary>
        private object Hook
        {
            get;
            set;
        }

        /// <summary>
        /// Implementation class of the dockable window add-in. It is responsible for 
        /// creating and disposing the user interface class of the dockable window.
        /// </summary>
        public class AddinImpl : ESRI.ArcGIS.Desktop.AddIns.DockableWindow
        {
            private DockableWinStatistics m_windowUI;

            public AddinImpl()
            {
            }

            protected override IntPtr OnCreateChild()
            {
                m_windowUI = new DockableWinStatistics(this.Hook);
                return m_windowUI.Handle;
            }

            protected override void Dispose(bool disposing)
            {
                if (m_windowUI != null)
                    m_windowUI.Dispose(disposing);

                base.Dispose(disposing);
            }

        }

        IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;

        private void btnPopulateLayerList_Click(object sender, EventArgs e)
        {
            lstLayers.Items.Clear();
            cboNumFields.Tag = null;

            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();

            while (layer != null)
            {
                if (layer is IFeatureLayer2)
                {
                    lstLayers.Items.Add(layer.Name);
                }
                layer = enumLayer.Next();
            }
        }

        private void lstLayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboNumFields.Items.Clear();
            string selectedLayerName = null;
            if (lstLayers.SelectedIndex >= 0)
            {
                selectedLayerName = lstLayers.SelectedItem.ToString();
            }

            if (selectedLayerName == null)
            { return; }

            //getting all the numerical fields
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();
            IFeatureLayer2 featureLayer = null;

            while (layer != null)
            {
                if (layer.Name == selectedLayerName)
                {
                    featureLayer = layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }

            IFeatureClass FC = featureLayer.FeatureClass;
            for (int i = 0; i < FC.Fields.FieldCount; i++)
            {
                IField field = FC.Fields.Field[i];
                if (field.Type == esriFieldType.esriFieldTypeDouble || field.Type == esriFieldType.esriFieldTypeInteger || field.Type == esriFieldType.esriFieldTypeSingle || field.Type == esriFieldType.esriFieldTypeSmallInteger)
                {
                    cboNumFields.Items.Add(field.Name);
                }
                //to be able to reach to the parent FeatureLayer
                cboNumFields.Tag = (featureLayer as ILayer).Name;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string selectedFieldName = null;
            if (cboNumFields.SelectedIndex >= 0)
            {
                selectedFieldName = cboNumFields.SelectedItem.ToString();
            }

            if (selectedFieldName == null)
            { return; }

            if (cboNumFields.Tag == null)
            {
                lblReport.Text = "";
                return; 
            }

            string featureLayerName = cboNumFields.Tag.ToString();
         
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();
            IFeatureLayer2 featureLayer = null;

            while (layer != null)
            {
                if (layer.Name == featureLayerName)
                {
                    featureLayer = layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }

            if (featureLayer == null)
            { return; }

            IFeatureClass FC = featureLayer.FeatureClass;
            IFeatureCursor featureCursor = FC.Search(null, true);


            IDataStatistics dataStatistics = new DataStatisticsClass();
            dataStatistics.Field = selectedFieldName;
            dataStatistics.Cursor = featureCursor as ICursor;

            IStatisticsResults sR = dataStatistics.Statistics;

            lblReport.Text = string.Format("Count: {0}\n", sR.Count);
            lblReport.Text += string.Format("Min: {0:#.00}\n", sR.Minimum);
            lblReport.Text += string.Format("Max: {0:#.00}\n", sR.Maximum);
            lblReport.Text += string.Format("Sum: {0:#.00}\n", sR.Sum);
            lblReport.Text += string.Format("Average: {0:#.00}\n", sR.Mean);
            lblReport.Text += string.Format("Standard Deviation: {0:#.00}\n", sR.StandardDeviation);
        }
    }
}
