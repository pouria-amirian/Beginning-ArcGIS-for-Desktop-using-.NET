﻿namespace DockableWindowStatistics
{
    partial class DockableWinStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPopulateLayerList = new System.Windows.Forms.Button();
            this.lblReport = new System.Windows.Forms.Label();
            this.lstLayers = new System.Windows.Forms.ListBox();
            this.cboNumFields = new System.Windows.Forms.ComboBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPopulateLayerList
            // 
            this.btnPopulateLayerList.Location = new System.Drawing.Point(24, 22);
            this.btnPopulateLayerList.Name = "btnPopulateLayerList";
            this.btnPopulateLayerList.Size = new System.Drawing.Size(214, 27);
            this.btnPopulateLayerList.TabIndex = 0;
            this.btnPopulateLayerList.Text = "List of Layers";
            this.btnPopulateLayerList.UseVisualStyleBackColor = true;
            this.btnPopulateLayerList.Click += new System.EventHandler(this.btnPopulateLayerList_Click);
            // 
            // lblReport
            // 
            this.lblReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReport.Location = new System.Drawing.Point(22, 346);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(216, 154);
            this.lblReport.TabIndex = 1;
            // 
            // lstLayers
            // 
            this.lstLayers.FormattingEnabled = true;
            this.lstLayers.ItemHeight = 14;
            this.lstLayers.Location = new System.Drawing.Point(25, 67);
            this.lstLayers.Name = "lstLayers";
            this.lstLayers.Size = new System.Drawing.Size(213, 172);
            this.lstLayers.TabIndex = 2;
            this.lstLayers.SelectedIndexChanged += new System.EventHandler(this.lstLayers_SelectedIndexChanged);
            // 
            // cboNumFields
            // 
            this.cboNumFields.FormattingEnabled = true;
            this.cboNumFields.Location = new System.Drawing.Point(25, 269);
            this.cboNumFields.Name = "cboNumFields";
            this.cboNumFields.Size = new System.Drawing.Size(213, 22);
            this.cboNumFields.TabIndex = 3;
            
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(22, 307);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(214, 27);
            this.btnCalculate.TabIndex = 4;
            this.btnCalculate.Text = "Calculate Statistics";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // DockableWinStatistics
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.cboNumFields);
            this.Controls.Add(this.lstLayers);
            this.Controls.Add(this.lblReport);
            this.Controls.Add(this.btnPopulateLayerList);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "DockableWinStatistics";
            this.Size = new System.Drawing.Size(264, 517);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPopulateLayerList;
        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.ListBox lstLayers;
        private System.Windows.Forms.ComboBox cboNumFields;
        private System.Windows.Forms.Button btnCalculate;

    }
}
