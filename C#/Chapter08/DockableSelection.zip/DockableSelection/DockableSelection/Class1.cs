using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace DockableSelection
{
    [Guid("7ef72fdd-2e11-438a-b65f-95dc7bebce87")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("DockableSelection.Class1")]
    public class Class1
    {
    }
}
