namespace DockableSelection
{
    partial class selectionDockable
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPlaceholder = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnPopulateList = new System.Windows.Forms.Button();
            this.lblReport = new System.Windows.Forms.Label();
            this.lstStates = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // labelPlaceholder
            // 
            this.labelPlaceholder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPlaceholder.Location = new System.Drawing.Point(0, 0);
            this.labelPlaceholder.Name = "labelPlaceholder";
            this.labelPlaceholder.Size = new System.Drawing.Size(338, 655);
            this.labelPlaceholder.TabIndex = 0;
            this.labelPlaceholder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(24, 475);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(216, 23);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear Selection";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(24, 305);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(216, 23);
            this.btnSelect.TabIndex = 2;
            this.btnSelect.Text = "Select Cities in the Selected State";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnPopulateList
            // 
            this.btnPopulateList.Location = new System.Drawing.Point(24, 45);
            this.btnPopulateList.Name = "btnPopulateList";
            this.btnPopulateList.Size = new System.Drawing.Size(216, 23);
            this.btnPopulateList.TabIndex = 3;
            this.btnPopulateList.Text = "Populate List of States";
            this.btnPopulateList.UseVisualStyleBackColor = true;
            this.btnPopulateList.Click += new System.EventHandler(this.btnPopulateList_Click);
            // 
            // lblReport
            // 
            this.lblReport.Location = new System.Drawing.Point(21, 355);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(219, 97);
            this.lblReport.TabIndex = 4;
            // 
            // lstStates
            // 
            this.lstStates.FormattingEnabled = true;
            this.lstStates.Location = new System.Drawing.Point(24, 98);
            this.lstStates.Name = "lstStates";
            this.lstStates.Size = new System.Drawing.Size(216, 199);
            this.lstStates.TabIndex = 5;
            this.lstStates.SelectedIndexChanged += new System.EventHandler(this.lstStates_SelectedIndexChanged);
            // 
            // selectionDockable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lstStates);
            this.Controls.Add(this.lblReport);
            this.Controls.Add(this.btnPopulateList);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.labelPlaceholder);
            this.Name = "selectionDockable";
            this.Size = new System.Drawing.Size(338, 655);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelPlaceholder;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnPopulateList;
        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.ListBox lstStates;
    }
}
