﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace myFirstWPFApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddition_Click(object sender, RoutedEventArgs e)
        {
             //since the inputs (entered by user) are string 
            //we have to convert them to double

            //get the first num
            double firstNum = 0;
            firstNum = double.Parse(txtFirstNum.Text);

            //get the second num
            double secondNum = double.Parse(txtSecondNum.Text);

            // + operator for string concatenate them
            label3.Content = firstNum.ToString() + " + " + secondNum.ToString()
            + " = " + firstNum + secondNum;
       }
      
        void testToString()
        {

            string GIS = "  Geographical Information System ";

            /*GIS = GIS.TrimStart();
            //  "Geographical Information System "
            
            GIS = GIS.ToUpper();
            // "GEOGRAPHICAL INFORMATION SYSTEM"
            
            GIS = GIS.Replace("GEOGRAPHICAL", "Geospatial");
            //Geospatial INFORMATION SYSTEM

            bool IsGepspatial = GIS.Contains("Geospatial");
            // true
            
            int length = GIS.Length;
            //32
            
            char[] GISCharArray = GIS.ToCharArray(); 
            // 32 elements are in array
            char myInitial = GISCharArray[4]; //p
        

            string[] sep = { " " };
            string[] GISStringArray = GIS.Split(sep,
                StringSplitOptions.RemoveEmptyEntries);

            //Creating Accronym
            GIS = GIS.Trim();
            string accronym = GIS[0].ToString();
            //GIS[0] is char so we need to convert it to string

            while (GIS.Contains(" "))
            {
                GIS = GIS.Substring(GIS.IndexOf(" ") + 1);
                accronym += GIS.Trim()[0].ToString();

            }

            string g = "Geospatial";
            string i = "Information";
            string s = "Systems";
            string gis = string.Format("GIS is stand for {0} {1} {2}", g, i, s);
            gis = "GIS is stand for " + g + " " + i + " " + s;

            double num = 88.1388;
            string output = "";
            //we can use format characters in Format method
            output = string.Format("{0:c}", num);
            //$88.14  - c character is used for currency 
            output = string.Format("{0:f1}", num);
            //88.1   - f is for floating point and 
            //1 is for the minimum number of digits 
            output = string.Format("{0:###,###.000000}", num);
            //88.138800 
            output = string.Format("{0:000,###.000###}", num);
            //000,088.1388
        }

        void usingDATE()
        {
            DateTime myBirthday = DateTime.Parse("5/5/1982");
            string day = myBirthday.ToLongDateString();
            //bool isLeap

        }

        void usingArray()
        {
            int[,] intArray = { { 1, 100 }, { 2, 200 }, { 3, 300 }, { 4, 400 } };

            int lengthOfArray = intArray.Length;
            //8 . Total number of elements

            lengthOfArray = intArray.GetLength(0);
            //4 . Number of elements in specified dimention

            int rows = intArray.GetUpperBound(0);
            //3 . Number of rows = 4 (since it is zero based) 

            int cols = intArray.GetUpperBound(1);
            //1 . Number of columns= 2 (since it is zero based)

        }

        void testTheNarrowing()
        {
            int intAge = 120;
            byte byteAge = (byte)intAge;



            // the following block of code results in run time error
            //Arithmetic operation resulted in an overflow
            checked
            {
                int intNum = int.MaxValue;
                long lngNum = intNum + 1L;
                //lngNum is equal to 2147483648 

                intNum = (int)lngNum;
                //intNum is exactly equals to int.MinValue (-2147783648)
            }
        }*/
    }
}
