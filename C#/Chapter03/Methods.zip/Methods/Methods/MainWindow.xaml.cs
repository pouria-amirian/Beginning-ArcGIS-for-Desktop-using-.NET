﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Methods
{
 
 
    /// <summary>
    /// 
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UsingAddMethod()
        {
            int intAddition = AddTwoNumber(10, 100);
        }
        //private int AddTwoNumbers()
        //{
        //    int firstNum = 10;
        //    int secondNum = 100;
        //    //we have to use the return keyword
        //    return firstNum + secondNum;
        //}

        public void doSomething()
        {
            //code goes here
            //no return keyword
           
            
        }
    /// <summary>
    /// Adds two input numbers
    /// </summary>
    /// <param name="firstNum">first integer number for addition</param>
    /// <param name="secondNum">second integer number for addition</param>
    /// <returns>summation of the first and second input</returns>
        private int AddTwoNumber(int firstNum, int secondNum)
        {
            return firstNum + secondNum;
        }


        private double AddTwoNumbers(int a, int b)
        {
            return a + b;
        }

        private double AddTwoNumbers(float a, float b)
        {
            return a + b;
        }

        private double AddTwoNumbers(byte a, byte b)
        {
            return a + b;

        }



        private string Multiplication(double a, double b, bool format = false)
        {

            if (format == true)
            {
                return string.Format("{0:f4}", a * b);
            }
            else
            {
                return string.Format("{0}", a * b);
            }
        }


        private string FlexibleMultiplication(double a, double b, bool formatNumber = false, bool useCurrencySign = false)
        {
            string result = "";
          
            if (formatNumber == true)
            {
                if (useCurrencySign == true)
                {
                    result = "$" + string.Format("{0:f4}", a * b);
                }
                else
                {
                    result = string.Format("{0:f4}", a * b);
                }
            }
            else
            {
                if (useCurrencySign == true)
                {
                    result = "$" + Math.Round(a*b,2);
                }
                else
                {
                    result = string.Format("{0}", a * b);
                }
            }

            return result;
        }

        private void testMethodOverloading()
        {
            //string testMultiplication = "";
            //testMultiplication = Multiplication(1388.0, 8.8);
            ////12214.4

            //testMultiplication = Multiplication(1388.0, 8.8, true);
            ////12214.4000
            string testMultiplication = "";
            testMultiplication = FlexibleMultiplication(28.10, 20.09);
            //564.529

            testMultiplication = FlexibleMultiplication(28.10, 20.09, true);
            //564.5290

            testMultiplication = FlexibleMultiplication(28.10, 20.09, false, true);
            //$564.53

            testMultiplication = FlexibleMultiplication(28.10, 20.09, true, true);
            //$546.5290

            testMultiplication = FlexibleMultiplication(b: 20.09, a: 28.10, useCurrencySign: true);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            testMethodOverloading();
        }



    }


}
