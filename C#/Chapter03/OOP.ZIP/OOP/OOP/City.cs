﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    class City
    {
        // master constructor
        public City(string name, string country, decimal area, long population)
        {
            this.Name = name;
            this.Country = country;
            this.Area = area;
            this.Population = population;
        }

        public City(string name, decimal area, long population)
            : this(name, "", area, population)
        {
            //there is no need for any code here
            //notice how "this" keyword is used in chaining constructors
        }

        public City(string name, decimal area)
            : this(name, "", area, 0)
        { }

        //empty constructor
        public City() { }

        //first version
        //private string name;
        //public string Name
        //{
        //    get
        //    {
        //        return name;
        //    }
        //    set
        //    {
        //        name = value;
        //    }
        //}
        //private string country;


        public string Name
        { get; set; }

        public string Country
        { get; set; }

        public decimal Area
        {
            get;
            set;
        }

        private long population;
        public long Population
        {
            get
            {
                return population;
            }
            set
            {
                if (value > 0)
                {
                    population = value;
                }
                else
                {
                    population = 0;
                }
            }

        }

        public decimal getPopulationDensity()
        {
            return this.Population / this.Area;
        }





        void test()
        {

            //City dublin = getCityByName("Dublin");


        }

        City getCityByName(string name)
        {
            City myCity = new City();
            myCity.Name = name;
            
            
            City london = new City();
            //or do some search
            City shiraz = new City("Shiraz", 179, 1600000);
            City paris = new City("Paris", 105, 2300000);
            
            
            return myCity;
        }
    }
}
//class ClientOfCity
//{
//    void testForInstantiation()
//    {

//        City shiraz = new City();
//        //Also we could instantiate an object in two steps
//        City paris;
//        paris = new City();

//        //releasing memory which was allocated to this object
//        paris = null;

//    }

//    void testForProerties()
//    {
//        City hannover = new City();
//        hannover.Name = "Hannover";
//        hannover.Country = "Germany";

//        string info = string.Format("Name:{0}, Country:{1}", hannover.Name, hannover.Country);

//    }

//}



