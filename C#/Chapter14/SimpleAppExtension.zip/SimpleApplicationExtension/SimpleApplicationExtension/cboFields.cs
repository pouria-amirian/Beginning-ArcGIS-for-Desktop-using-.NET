﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SimpleApplicationExtension
{
    public class cboFields : ESRI.ArcGIS.Desktop.AddIns.ComboBox
    {
        private static cboFields s_cboFields;
        private static string s_selectedField;

        public cboFields()
        {
            s_cboFields = this;
        }
        //override methods
        protected override void OnUpdate()
        {
            //the state of this Add-in component must be controled by the extension
            this.Enabled = SimpleExtension.IsExtensionEnabled();
        }
        protected override void OnSelChange(int cookie)
        {
            if (cookie < 0)
            { return; }
            s_selectedField = this.GetItem(cookie).Caption;
        }

        //for sharing functionality
        internal static string GetSelectedField()
        {
            return s_selectedField;
        }

        internal static void ClearAllItems()
        {
            s_selectedField = null;
            s_cboFields.Clear();
        }

        internal static void AddItem(string fieldName)
        {
            s_cboFields.Add(fieldName);
        }
    }

}
