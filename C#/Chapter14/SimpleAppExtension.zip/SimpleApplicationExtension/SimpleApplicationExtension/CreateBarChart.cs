﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace SimpleApplicationExtension
{
    public class CreateBarChart : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public CreateBarChart()
        {
        }

        protected override void OnClick()
        {
            frmBarchart chartForm = new frmBarchart();
            chartForm.FeatureLayerName = cboFeatureLayers.GetSelectedFeatureLayer();
            chartForm.ValueFieldName = cboFields.GetSelectedField();
            if (chartForm.ValueFieldName == null || chartForm.FeatureLayerName == null)
            {
                string errorMsg = "Please select a FeatureLayer and a Field";
                System.Windows.Forms.MessageBox.Show(errorMsg);       
                return;
            }

            chartForm.ShowDialog();
        }

        protected override void OnUpdate()
        {
            this.Enabled = SimpleExtension.IsExtensionEnabled();
        }
    }
}
