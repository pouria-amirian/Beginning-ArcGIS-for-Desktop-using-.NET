﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.ArcMapUI;

namespace SimpleApplicationExtension
{
    public class cboFeatureLayers : ESRI.ArcGIS.Desktop.AddIns.ComboBox
    {
        private static cboFeatureLayers s_cboFeatureLayers;
        private static string s_selectedFeatureLayer;

        public cboFeatureLayers()
        {
            s_cboFeatureLayers = this;
        }

        protected override void OnUpdate()
        {
            //the state of this Add-in component must be controled by the extension
            this.Enabled = SimpleExtension.IsExtensionEnabled();
        }

        protected override void OnSelChange(int cookie)
        {
            if (cookie < 0)
            { return; }
            s_selectedFeatureLayer = this.GetItem(cookie).Caption;

            //populate  cboFields
            cboFields.ClearAllItems();
            IMxDocument mxdoc = ArcMap.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;

            for (int i = 0; i < map.LayerCount; i++)
            {
                if (map.Layer[i] is IFeatureLayer && map.Layer[i].Name == s_selectedFeatureLayer)
                {
                    IFeatureClass fClass = ((map.Layer[i]) as IFeatureLayer).FeatureClass;
                    for (int j = 0; j < fClass.Fields.FieldCount; j++)
                    {
                        switch (fClass.Fields.Field[j].Type)
                        {
                            case esriFieldType.esriFieldTypeDouble:
                            case esriFieldType.esriFieldTypeInteger:
                            case esriFieldType.esriFieldTypeSingle:
                            case esriFieldType.esriFieldTypeSmallInteger:
                                cboFields.AddItem(fClass.Fields.Field[j].Name);
                                break;
                        }
                    }
                    //since selected featureLayer is found there is no need to continue
                    break;
                }
            }
        }

        //for sharing functionality
        internal static string GetSelectedFeatureLayer()
        {
            return s_selectedFeatureLayer;
        }

        internal static void ClearAllItems()
        {
            s_selectedFeatureLayer = null;
            s_cboFeatureLayers.Clear();
        }

        internal static void AddItem(string featureLayerName)
        {
            s_cboFeatureLayers.Add(featureLayerName);
        }
    }

}
