﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Desktop.AddIns;
using ESRI.ArcGIS.ArcMapUI;

namespace SimpleApplicationExtension
{
    public class SimpleExtension : ESRI.ArcGIS.Desktop.AddIns.Extension
    {
        private IMap map;
        private static SimpleExtension s_extension;

        public SimpleExtension()
        {

        }

        // helper methods
        private void InitializeExtension()
        {
            if (s_extension == null || this.State != ExtensionState.Enabled)
            { return; }

            // event wiring (registering and attaching event handlers to events)                
            IMxDocument mxdoc = ArcMap.Document as IMxDocument;
            map = mxdoc.FocusMap;
            IActiveViewEvents_Event aciteviewEvents = map as IActiveViewEvents_Event;
            aciteviewEvents.ItemAdded += new IActiveViewEvents_ItemAddedEventHandler(LayerAddedOrDeleted);
            aciteviewEvents.ItemDeleted += new IActiveViewEvents_ItemDeletedEventHandler(LayerAddedOrDeleted);

            FillcboFeatureLayers();
        }
        private void LayerAddedOrDeleted(object Item)
        {
            map = ArcMap.Document.FocusMap;
            FillcboFeatureLayers();
        }
        private void FillcboFeatureLayers()
        {
            cboFields.ClearAllItems();
            cboFeatureLayers.ClearAllItems();

            // Loop through the layers in the map and add the layer's name to the combo box.
            for (int i = 0; i < map.LayerCount; i++)
            {
                if (map.Layer[i] is IFeatureLayer)
                {
                    cboFeatureLayers.AddItem(map.Layer[i].Name);
                }
            }
        }
        private void UnInitializeExtension()
        {
            if (s_extension == null)
                return;

            // Detach event handlers
            IActiveViewEvents_Event activeviewEvents = map as IActiveViewEvents_Event;
            activeviewEvents.ItemAdded -= LayerAddedOrDeleted;
            activeviewEvents.ItemDeleted -= LayerAddedOrDeleted;
            activeviewEvents = null;

            cboFields.ClearAllItems();
            cboFeatureLayers.ClearAllItems();
        }


        //overriden methods
        protected override void OnStartup()
        {
            s_extension = this;
            InitializeExtension();
        }

        protected override void OnShutdown()
        {
            UnInitializeExtension();
            map = null;
            s_extension = null;
            base.OnShutdown();
        }

        protected override bool OnSetState(ExtensionState state)
        {

            this.State = state;
            if (state == ExtensionState.Enabled)
            {
                InitializeExtension();
            }
            else
            {
                UnInitializeExtension();
            }
            return true;
        }

        protected override ExtensionState OnGetState()
        {
            return this.State;
        }

        //static method
        //for managing and coordinating the state of other components
        internal static bool IsExtensionEnabled()
        {
            if (s_extension == null)
            {
                GetTheExtension();
            }

            if (s_extension == null)
            {
                return false;
            }

            if (s_extension.State == ExtensionState.Enabled)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static SimpleExtension GetTheExtension()
        {
            // Call FindExtension method to create the s_extension
            // if the extension has been checked in the Extensions window

            UID extensionID = new UIDClass();
            extensionID.Value = ThisAddIn.IDs.SimpleExtension;
            ArcMap.Application.FindExtensionByCLSID(extensionID);
            return s_extension;
        }

    }

}
