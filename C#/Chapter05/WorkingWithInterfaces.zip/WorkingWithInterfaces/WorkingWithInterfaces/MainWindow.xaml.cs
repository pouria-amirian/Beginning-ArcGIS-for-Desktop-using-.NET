﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WorkingWithInterfaces
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();


        }

        public void testInterface()
        {
            //only members of I2DShape are available
            I2DShape mySQ = new Square(2.0);
            double area = mySQ.CalculateArea();
            int numOfVertices = mySQ.NumberOfVertices;

            //to accessing perimeter we have to cast (Query) interface
            I2DShape2 mySQ2 = mySQ as I2DShape2;
            double perimeter = mySQ2.CalculatePerimeter();
            //both mySQ and mySQ2 are the same object 
            //with two different ways of exposing members

            //using is keyword
            if (mySQ is I2DShape2)
            {
                //following lines of code are the same
                I2DShape2 mySQ3 = (I2DShape2)mySQ;
                mySQ3 = mySQ as I2DShape2;
            }



        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            testInterface();
        }
    }
}
