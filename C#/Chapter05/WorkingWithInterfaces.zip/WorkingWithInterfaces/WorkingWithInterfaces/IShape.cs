﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WorkingWithInterfaces
{
    interface I2DShape
    {
        double CalculateArea();
        int NumberOfVertices { get; }
    }

    interface I2DShape2
    {
        double CalculatePerimeter();
    }

    public class Square : I2DShape, I2DShape2
    {
        private double side;
        public Square(double side)
        {
            this.side = side;
        }

        double I2DShape.CalculateArea()
        {
            return side * side;
        }

        int I2DShape.NumberOfVertices
        {
            get
            {
                return 4;
            }

        }

        double I2DShape2.CalculatePerimeter()
        {
            return 4 * this.side;
        }
    }
}
