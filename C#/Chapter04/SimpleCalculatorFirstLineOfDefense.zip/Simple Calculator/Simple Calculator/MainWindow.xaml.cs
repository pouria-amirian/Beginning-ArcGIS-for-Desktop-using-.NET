﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Simple_Calculator
{
    public partial class MainWindow : Window
    {
        double firstNum, secondNum, result;
        enum Operator
        {
            Addition,
            Subtraction,
            Multiplication,
            Division
        }
        Operator SelectedOperator;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void NumberClick(object sender, RoutedEventArgs e)
        {
            string enteredNum = "";
            Button clickedButton = (Button)sender;
            enteredNum = clickedButton.Content.ToString();
            lblResult.Content += enteredNum;
        }

        private void buttonPoint_Click(object sender, RoutedEventArgs e)
        {
            if (!lblResult.Content.ToString().Contains("."))
            {
                lblResult.Content += ".";
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
 
            //using first line of defense

            if (lblResult.Content==null ||  string.IsNullOrEmpty(lblResult.Content.ToString()))
            {
               
                firstNum = 0.0;
            }
            else
            { 
                //get the first number
                firstNum = double.Parse(lblResult.Content.ToString());
            }

            //determine the operator
            string strOperator = ((Button)sender).Content.ToString();
            switch (strOperator)
            {
                case "+":
                    SelectedOperator = Operator.Addition;
                    break;
                case "-":
                    SelectedOperator = Operator.Subtraction;
                    break;
                case "*":
                    SelectedOperator = Operator.Multiplication;
                    break;
                case "/":
                    SelectedOperator = Operator.Division;
                    break;
            }

            //clear the lblResult to make it ready for second number 
            lblResult.Content = "";
        }

        private void buttonEqual_Click(object sender, RoutedEventArgs e)
        {
            secondNum = double.Parse(lblResult.Content.ToString());

            switch (SelectedOperator)
            {
                case Operator.Addition:
                    result = firstNum + secondNum;
                    lblSummary.Content = string.Format("{0} + {1}", firstNum, secondNum);
                    break;
                case Operator.Subtraction:
                    result = firstNum - secondNum;
                    lblSummary.Content = string.Format("{0} - {1}", firstNum, secondNum);
                    break;
                case Operator.Multiplication:
                    result = firstNum * secondNum;
                    lblSummary.Content = string.Format("{0} * {1}", firstNum, secondNum);
                    break;
                case Operator.Division:
                    result = firstNum / secondNum;
                    lblSummary.Content = string.Format("{0} / {1}", firstNum, secondNum);
                    break;
            }

            lblResult.Content = result;
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lblResult.Content = "";
            lblSummary.Content = "";
        }
    }
}
