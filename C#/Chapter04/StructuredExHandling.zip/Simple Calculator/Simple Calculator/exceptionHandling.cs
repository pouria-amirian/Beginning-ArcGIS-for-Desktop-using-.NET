﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Simple_Calculator;

namespace Simple_Calculator
{
    class exceptionHandling
    {

        void CallerMethod()
        {
            try
            {
                int result = Divide(0, 0);
            }
            catch (Exception ex)
            {
                //reporting message to the end users
                string message = ex.Message;
            }
        }

        int Divide(int i, int j)
        {
            try
            {
                return i / j;
            }
            catch
            {
                Exception myEx = new Exception("divide by zero results in infinity");
                throw myEx;
            }
        }

        public string readATextFile()
        {
            string data = "";
            try
            {
                data = File.ReadAllText(@"c:\test.txt");
                return data;
            }
            catch (DirectoryNotFoundException ex)
            {
                throw new Exception("Directory not exists");
            }
            catch (FileNotFoundException ex)
            {
                throw new Exception("File Not Found");
            }
            catch (Exception ex)
            {
                //executed when non of above exception is occured
                throw new Exception("Something is wrong!");
            }
        }

    }
}
