﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KML
{
    class City
    {
        //properties
        public string Name
        { get; set; }

        public long Population
        { get; set; }

        public decimal Area
        { get; set; }

        public decimal X
        { get; set; }

        public decimal Y
        { get; set; }

        //constructors
        //master constructor
        public City(string name, long population, decimal area, decimal x, decimal y)
        {
            this.Name = name;
            this.Population = population;
            this.Area = area;
            this.X = x;
            this.Y = y;
        }
        //second constructor
        public City(string name, long population, decimal x, decimal y)
            : this(name, population, 0, x, y) { }
        //thrid constructor
        public City(string name, decimal x, decimal y)
            : this(name, 0, 0, x, y) { }
        //forth (empty) constructor
        public City() : this("", 0, 0) { }


        //methods
        public override string ToString()
        {
            //a little bit use of HTML tags
            return string.Format("{0}, {1}, {2}, {3}, {4}", this.Name, this.Population, this.Area, this.X, this.Y);
        }

        public string WriteKMLFragment()
        {
            string kmlFragment = "";
            kmlFragment += string.Format("<Placemark id='{0}'>", this.Name);
            kmlFragment += string.Format("<name>The City of {0}</name>", this.Name);
            kmlFragment += string.Format("<description>{0}</description>", this.CreateKMLDescription());

            kmlFragment += string.Format("<Point><coordinates>{0},{1})</coordinates></Point>", this.X, this.Y);
            kmlFragment += string.Format("</Placemark>");

            return kmlFragment;
        }
        private string CreateKMLDescription()
        {
            string description="";
            description += string.Format("<i>Name: </i>{0}<br />",this.Name);
                    description += string.Format("<i>Population: </i>{0} <br/>",this.Population);
                    description += string.Format("<i>Area: </i>{0} Square Kilometre",this.Area);
             
        return description;
        }
    }
}

