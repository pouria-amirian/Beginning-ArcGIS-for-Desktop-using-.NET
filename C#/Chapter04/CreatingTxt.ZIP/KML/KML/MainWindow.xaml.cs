﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace KML
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void btnWriteTextFile_Click(object sender, RoutedEventArgs e)
        {
            List<City> cities = new List<City>();
            cities.Add(new City("New York", 16500000, 1210, -74.0999m, 40.7500m));
            cities.Add(new City("Tokyo", 23650000, 2187, 139.8092m, 35.6830m));
            cities.Add(new City("Berlin", 5100000, 892, 13.3276m, 52.5163M));
            cities.Add(new City("Paris", 10000000, 105, 2.4328M, 48.8815m));

            //writing text file
            string fileAddress = @"C:\test.txt";
            FileStream fs = new FileStream(fileAddress, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                foreach (City ct in cities)
                {
                    sw.WriteLine(ct.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.Source);
            }
            finally
            {
                //cleanup
                sw.Close();
                fs.Close();
            }
        }

        private void btnconvert_Click(object sender, RoutedEventArgs e)
        {
            //Read the text file
            //and populate the list of City objects
            FileStream fs = new FileStream(@"c:\test.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);

            List<City> cities = new List<City>();
            try
            {
                string line = sr.ReadLine();

                while (line != null)
                {
                    string[] content = line.Split(",".ToCharArray());
                    City ct = new City();
                    ct.Name = content[0];
                    ct.Population = long.Parse(content[1]);
                    ct.Area = decimal.Parse(content[2]);
                    ct.X = decimal.Parse(content[3]);
                    ct.Y = decimal.Parse(content[4]);

                    cities.Add(ct);
                    line = sr.ReadLine();
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            finally
            {
                sr.Close();
                fs.Close();
            }

            //create kml
            StringBuilder sb = new StringBuilder();
            //append the kml prologue
            sb.Append(@"<?xml version='1.0' encoding='UTF-8'?><kml xmlns='http://www.opengis.net/kml/2.2'><Document>");

            foreach (City ct in cities)
            {
                sb.Append(ct.WriteKMLFragment());
            }

            //append the epilog og the kml file
            sb.Append(@"</Document></kml>");
            fs = new FileStream(@"c:\test.kml", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);

            try
            {
                sw.Write(sb.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sw.Close();
                fs.Close();
            }


        }
        void testText()
        {
            //for creating new files
            //FileStream fs = new FileStream(@"c:\test.dat", FileMode.Create);
            //StreamWriter sw = new StreamWriter(fs);
            //sw.WriteLine("this is content of a test.dat file");
            ////release the file resource
            //sw.Close();
            //fs.Close();


            ////for reading an existing file as a whole
            //FileStream fs = new FileStream(@"c:\test.dat", FileMode.Open);
            //StreamReader sr = new StreamReader(fs);
            ////reading content of file as a whole
            //string data = sr.ReadToEnd();
            ////cleanup
            //sr.Close();
            //fs.Close();


            //for reading an existing file line by line
            FileStream fs = new FileStream(@"c:\test.dat", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            string oneLineOfData = sr.ReadLine();
            while (oneLineOfData != null)
            {
                //code to process a line of data goes here
                oneLineOfData = sr.ReadLine();
            }
            sr.Close();
            fs.Close();


        }

        void testBinary()
        {
            FileStream fs = new FileStream(@"c:\test.dat", FileMode.Open);
            BinaryWriter bw = new BinaryWriter(fs);

        }
        void fastReading()
        {
            string[] linesOfData = { 
                "New York, 16500000, 1210, -74.0999, 40.7500",
                "Tokyo, 23650000, 2187, 139.8092, 35.6830",
                "Berlin, 5100000, 892, 13.3276, 52.5163" };

            //writing all lines in one shot
            File.WriteAllLines(@"c:\test.txt", linesOfData);

            //reading the text file line by line
            string[] contents = File.ReadAllLines(@"c:\test.txt");
        }

        private void btnKMZ_Click(object sender, RoutedEventArgs e)
        {
            Ionic.Zip.ZipFile zf = new Ionic.Zip.ZipFile();
            try
            {
                //we create the kml file in the previous step
                //also we can create kmz file in single step as well
                zf.AddFile(@"C:\test.kml");
                zf.Save(@"C:\test.kmz");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.Source);
            }
            finally
            {
                //cleanup code
                zf.Dispose();
            }
        }
    }
}
