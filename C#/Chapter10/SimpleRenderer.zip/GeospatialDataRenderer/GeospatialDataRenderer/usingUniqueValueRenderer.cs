﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace GeospatialDataRenderer
{
    public class usingUniqueValueRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingUniqueValueRenderer()
        {
        }

        protected override void OnClick()
        {
        }

        protected override void OnUpdate()
        {
        }
    }
}
