﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesRaster;

namespace GeospatialDataRenderer
{
    public class usingRasterRGBRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingRasterRGBRenderer()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IRasterLayer rasterLayer = null;
            while (layer != null)
            {
                if (layer is IRasterLayer)
                {
                    rasterLayer = layer as IRasterLayer;
                }
                layer = layers.Next();
            }
            if (rasterLayer == null)
            { return; }

            IRaster raster = rasterLayer.Raster;
            IRasterBandCollection rasterBC = raster as IRasterBandCollection;
            if (rasterBC.Count < 3)
            { return; }

            IRasterRGBRenderer2 rgbRen = new RasterRGBRendererClass();
            IRasterRenderer rasRen = rgbRen as IRasterRenderer;
            //little playing with the raster display
            rgbRen.RedBandIndex = 1;
            rgbRen.GreenBandIndex = 2;
            rgbRen.BlueBandIndex = 0;
            //use channel 2 value as transparency value for each pixel
            rgbRen.UseAlphaBand = true;
            rgbRen.AlphaBandIndex = 2;
            rasterLayer.Renderer = rasRen;
            //update is needed
            rasRen.Update();
            mxdoc.UpdateContents();
            mxdoc.ActiveView.Refresh();
        }

        protected override void OnUpdate()
        {
        }
    }
}
