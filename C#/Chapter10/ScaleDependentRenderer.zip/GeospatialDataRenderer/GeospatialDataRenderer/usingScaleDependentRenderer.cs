﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DisplayUI;
using ESRI.ArcGIS.CartoUI;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;

namespace GeospatialDataRenderer
{
    public class usingScaleDependentRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingScaleDependentRenderer()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 countiesFL = null;

            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. Counties (Generalized)")
                {
                    countiesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (countiesFL == null)
            { return; }
            try
            {
                IGeoFeatureLayer countiesGFL = countiesFL as IGeoFeatureLayer;

                IUniqueValueRenderer uVR = GetUniqueValueRenderer();
                IClassBreaksRenderer cBR = GetClassBreaksRenderer();

                IScaleDependentRenderer sDR = new ScaleDependentRendererClass();
                sDR.AddRenderer(cBR as IFeatureRenderer);
                sDR.Break[0] = 10000000;

                sDR.AddRenderer(uVR as IFeatureRenderer);
                sDR.Break[1] = 40000000;
                countiesGFL.Renderer = sDR as IFeatureRenderer;

                mxdoc.ActiveView.Refresh();
                mxdoc.UpdateContents();
            }
            catch (Exception ex)
            {
                ArcMap.Application.StatusBar.Message[0] = ex.Message;
            }
        }
        private IUniqueValueRenderer GetUniqueValueRenderer()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 countiesFL = null;

            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. Counties (Generalized)")
                {
                    countiesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (countiesFL == null)
            { return null; }

            IFeatureLayer2 FL = map.Layer[map.LayerCount - 1] as IFeatureLayer2;
            IFeatureCursor fCursor = FL.FeatureClass.Search(null, true);

            List<string> uniqueValues = new List<string>();
            IFeature feature = fCursor.NextFeature();
            int fieldIndex = FL.FeatureClass.Fields.FindField("STATE_NAME");

            while (feature != null)
            {
                if (uniqueValues.Contains(feature.Value[fieldIndex].ToString()) == false)
                {
                    uniqueValues.Add(feature.Value[fieldIndex].ToString());
                }
                feature = fCursor.NextFeature();
            }

            IUniqueValueRenderer uVRenderer = new UniqueValueRendererClass();
            uVRenderer.FieldCount = 1;
            uVRenderer.Field[0] = "STATE_NAME";

            IEnumColors enumColors = GetColorRamp(uniqueValues.Count);

            for (int i = 0; i < uniqueValues.Count; i++)
            {
                ISimpleFillSymbol simpleFSymbol = new SimpleFillSymbolClass();
                simpleFSymbol.Color = enumColors.Next();
                uVRenderer.AddValue(uniqueValues[i], "States", simpleFSymbol as ISymbol);
            }
            return uVRenderer;
        }
        private IClassBreaksRenderer GetClassBreaksRenderer()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 countiesFL = null;

            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. Counties (Generalized)")
                {
                    countiesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (countiesFL == null)
            { return null; }

            ITableHistogram tableHistogram = new TableHistogramClass();
            tableHistogram.Table = countiesFL.FeatureClass as ITable;
            tableHistogram.Field = "POP2000";

            IHistogram histogram = tableHistogram as IHistogram;
            object dataValues, dataFrequencies;
            histogram.GetHistogram(out dataValues, out dataFrequencies);

            IClassify classify = new QuantileClass();
            classify.SetHistogramData(dataValues, dataFrequencies);

            int numOfClasses = 5;
            classify.Classify(ref numOfClasses);

            double[] classBreaks = new double[numOfClasses];
            classBreaks = (double[])classify.ClassBreaks;


            IClassBreaksRenderer classBreaksRen = new ClassBreaksRendererClass();
            classBreaksRen.Field = "POP2000";
            classBreaksRen.BreakCount = numOfClasses;
            classBreaksRen.MinimumBreak = classBreaks[0];


            IEnumColors colors = GetColorRamp(numOfClasses);

            IFillSymbol fillSymbol = null;
            for (int i = 0; i < numOfClasses; i++)
            {
                fillSymbol = new SimpleFillSymbolClass();
                fillSymbol.Color = colors.Next();

                classBreaksRen.Symbol[i] = fillSymbol as ISymbol;
                classBreaksRen.Break[i] = classBreaks[i + 1];
                classBreaksRen.Label[i] = string.Format("{0}---{1}", classBreaks[i], classBreaks[i + 1]);
            }

            return classBreaksRen;
        }
              
        private IEnumColors GetColorRamp(int size)
        {
            IAlgorithmicColorRamp algColorRamp = new AlgorithmicColorRampClass();
            IRgbColor startColor = new RgbColorClass();
            startColor.Red = 255; startColor.Green = 204; startColor.Blue = 204;

            IRgbColor toColor = new RgbColorClass();
            toColor.Red = 219; toColor.Green = 0; toColor.Blue = 0;

            algColorRamp.FromColor = startColor;
            algColorRamp.ToColor = toColor;
            algColorRamp.Size = size;
            algColorRamp.Algorithm = esriColorRampAlgorithm.esriHSVAlgorithm;
            bool ok = true;
            algColorRamp.CreateRamp(out ok);
            return algColorRamp.Colors;
        }
        protected override void OnUpdate()
        {
        }
    }
}
