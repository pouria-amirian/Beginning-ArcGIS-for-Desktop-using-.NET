﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mgmt
{
    public static class util
    {
        public static string path = @"D:\DataFolder";
        public static string fileGDBName = "testFileGDB.gdb";
        public static string featureDatasetName = "pointFeatureClasses";
        public static string featureClassName = "majorCities";
        public static string xmlWorkspaceDocument = "FullGDB.xml";
        public static string xmlWorkspaceDocumentDS = "DatasetGDB.xml";
    }
}
