﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;

namespace mgmt
{
    public class OpenAndCloseDockable : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public OpenAndCloseDockable()
        {
        }

        protected override void OnClick()
        {
            UID myDockUID = new UIDClass();
            myDockUID.Value = ThisAddIn.IDs.MGMTDockableWin;

            IDockableWindow myDockWin = ArcMap.DockableWindowManager.GetDockableWindow(myDockUID);
            if (myDockWin.IsVisible())
            {

                myDockWin.Show(false);
            }
            else
            {

                myDockWin.Show(true);
            }
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
