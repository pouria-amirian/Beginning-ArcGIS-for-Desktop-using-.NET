﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.GeoDatabaseDistributed;
using ESRI.ArcGIS.GeoprocessingUI;
using ESRI.ArcGIS.Geoprocessing;
namespace mgmt
{
    /// <summary>
    /// Designer class of the dockable window add-in. It contains user interfaces that
    /// make up the dockable window.
    /// </summary>
    public partial class MGMTDockableWin : UserControl
    {
        public MGMTDockableWin(object hook)
        {
            InitializeComponent();
            this.Hook = hook;
        }

        /// <summary>
        /// Host object of the dockable window
        /// </summary>
        private object Hook
        {
            get;
            set;
        }

        /// <summary>
        /// Implementation class of the dockable window add-in. It is responsible for 
        /// creating and disposing the user interface class of the dockable window.
        /// </summary>
        public class AddinImpl : ESRI.ArcGIS.Desktop.AddIns.DockableWindow
        {
            private MGMTDockableWin m_windowUI;

            public AddinImpl()
            {
            }

            protected override IntPtr OnCreateChild()
            {
                m_windowUI = new MGMTDockableWin(this.Hook);
                return m_windowUI.Handle;
            }

            protected override void Dispose(bool disposing)
            {
                if (m_windowUI != null)
                    m_windowUI.Dispose(disposing);

                base.Dispose(disposing);
            }

        }


        void test()
        {
            //for sde Geodatabase
            Guid sdebGUID = new Guid("D9B4FA40-D6D9-11D1-AA81-00C04FA33A15");
            Type factoryType = Type.GetTypeFromCLSID(sdebGUID);
            IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;

            IPropertySet pSet = new PropertySetClass();
            pSet.SetProperty("Database", @"D:\DataFolder\testGDB.gdb");//path of Database
            IWorkspace ws = wsF.Open(pSet, ArcMap.Application.hWnd);
            IFeatureWorkspace fws = ws as IFeatureWorkspace;

        }
        private void btnCreatePersonalGDB_Click(object sender, EventArgs e)
        {
            try
            {


                string path = util.path;
                string fileGDBName = util.fileGDBName;

                if (System.IO.Directory.Exists(path + "\\" + fileGDBName))
                {
                    MessageBox.Show("there is a file geodatabase with the same path and name");
                    return;
                }


                //for file Geodatabase
                Guid fgdbGUID = new Guid("71FE75F0-EA0C-4406-873E-B7D53748AE7E");
                Type factoryType = Type.GetTypeFromCLSID(fgdbGUID);
                //Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");

                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                wsF.Create(path, fileGDBName, null, ArcMap.Application.hWnd);
                IWorkspaceName wsName = wsF.Create(path, fileGDBName, null, ArcMap.Application.hWnd);
                IName nameObj = wsName as IName;
                IWorkspace ws = nameObj.Open() as IWorkspace;



                //MessageBox.Show(string.Format("Type of Workspace: {0}\n Is Directory? {1}\n Full Path: {2}", ws.Type.ToString(), ws.IsDirectory().ToString(), ws.PathName));
                IFeatureWorkspace fws = null;
                //fws.
                //release all the references to singleton object (WorkspaceFactory)
                //ESRI.ArcGIS.ADF.ComReleaser.ReleaseCOMObject(wsF);
                //alternativly
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreateFeatureClass_Click(object sender, EventArgs e)
        {
            try
            {


                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }
                //IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;

                IWorkspace2 ws = fws as IWorkspace2;

                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == true)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass already exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //create fields
                IFieldsEdit fields = new FieldsClass();
                //fields.FieldCount_2 = 5;

                IFieldEdit field = new FieldClass();
                field.Name_2 = "ObjectID";
                field.Type_2 = esriFieldType.esriFieldTypeOID;
                fields.AddField(field);
                //fields.Field_2[0] = field;

                // Create a geometry definition (and spatial reference) for the feature class.
                IGeometryDefEdit geometryDefEdit = new GeometryDefClass();
                geometryDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
                ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
                int coordinateSystemID = (int)esriSRGeoCSType.esriSRGeoCS_WGS1984;
                ISpatialReference spatialReference = spatialReferenceFactory.CreateGeographicCoordinateSystem(coordinateSystemID);

                ISpatialReferenceResolution spatialReferenceResolution = spatialReference as ISpatialReferenceResolution;
                spatialReferenceResolution.ConstructFromHorizon();
                ISpatialReferenceTolerance spatialReferenceTolerance = spatialReference as ISpatialReferenceTolerance;
                spatialReferenceTolerance.SetDefaultXYTolerance();
                geometryDefEdit.SpatialReference_2 = spatialReference;

                field = new FieldClass();
                field.Name_2 = "Shape";
                field.Type_2 = esriFieldType.esriFieldTypeGeometry;
                field.GeometryDef_2 = geometryDefEdit;
                //fields.Field_2[1] = field;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Name";
                field.Type_2 = esriFieldType.esriFieldTypeString;
                //fields.Field_2[2] = field;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Population";
                field.Type_2 = esriFieldType.esriFieldTypeInteger;
                //fields.Field_2[3] = field;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Area";
                field.Type_2 = esriFieldType.esriFieldTypeDouble;
                //fields.Field_2[4] = field;
                fields.AddField(field);

                IFeatureClass fc = fws.CreateFeatureClass(fcName, fields, null, null, esriFeatureType.esriFTSimple, "Shape", null);

                //release all the references to singleton object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreateDomain_Click(object sender, EventArgs e)
        {
            try
            {

                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }
                ICodedValueDomain codedDomain = new CodedValueDomainClass();
                codedDomain.AddCode(1, "Is Capital");
                codedDomain.AddCode(0, "Is not Capital");
                IDomain capitalDomain = codedDomain as IDomain;
                capitalDomain.Name = "CapitalDomain";
                capitalDomain.FieldType = esriFieldType.esriFieldTypeSmallInteger;
                capitalDomain.SplitPolicy = esriSplitPolicyType.esriSPTDuplicate;
                capitalDomain.MergePolicy = esriMergePolicyType.esriMPTAreaWeighted;
                IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
                IWorkspaceDomains wsD = ws as IWorkspaceDomains;
                wsD.AddDomain(capitalDomain);

                //release all the references to singleton object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAssignDomain_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;

                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);
                //get the Domain
                IWorkspaceDomains3 wsD = ws as IWorkspaceDomains3;
                IDomain capitalDomain = wsD.get_DomainByName("CapitalDomain");

                //create a new field
                IFieldEdit2 field = new FieldClass();
                field.Name_2 = "status";
                field.Type_2 = esriFieldType.esriFieldTypeSmallInteger;
                field.DefaultValue_2 = 0;
                field.Domain_2 = capitalDomain;

                fc.AddField(field);
                //release all the references to singleton object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInsertFeaturesUsingStore_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;

                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);

                List<City> cities = new List<City>();
                cities.Add(new City("New York", 16500000, 1210, -74.0999, 40.7500));
                cities.Add(new City("Tokyo", 23650000, 2187, 139.8092, 35.6830));
                cities.Add(new City("Berlin", 5100000, 892, 13.3276, 52.5163));
                cities.Add(new City("Paris", 10000000, 105, 2.4328, 48.8815));

                int idxName = fc.Fields.FindField("Name");
                int idxPop = fc.Fields.FindField("Population");
                int idxArea = fc.Fields.FindField("Area");

                if (idxName < 0 || idxArea < 0 || idxPop < 0)
                { return; }

                foreach (City ct in cities)
                {
                    IFeature city = fc.CreateFeature();
                    IPoint point = new PointClass();
                    point.X = ct.X;
                    point.Y = ct.Y;
                    city.Shape = point;

                    city.Value[idxName] = ct.Name;
                    city.Value[idxPop] = ct.Population;
                    city.Value[idxArea] = ct.Area;
                    //for assigning default values to unspecified fields (for example status)
                    IRowSubtypes cityST = city as IRowSubtypes;
                    cityST.InitDefaultValues();
                    city.Store();
                }


                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnInsertCursor_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;

                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);

                List<City> cities = new List<City>();
                cities.Add(new City("New York", 16500000, 1210, -74.0999, 40.7500));
                cities.Add(new City("Tokyo", 23650000, 2187, 139.8092, 35.6830));
                cities.Add(new City("Berlin", 5100000, 892, 13.3276, 52.5163));
                cities.Add(new City("Paris", 10000000, 105, 2.4328, 48.8815));

                int idxName = fc.Fields.FindField("Name");
                int idxPop = fc.Fields.FindField("Population");
                int idxArea = fc.Fields.FindField("Area");

                if (idxName < 0 || idxArea < 0 || idxPop < 0)
                { return; }

                IFeatureBuffer cityBuffer = fc.CreateFeatureBuffer();
                //Passing a true value to the UseBuffering parameter of the ITable.Insert method returns an insert cursor that buffers rows on the client side and sends them to the server in batches for increased performance. Always enable buffering, except when inserting rows outside an edit session (buffering can only be leveraged during an edit session).
                //When buffering is used with an insert cursor, a call to InsertRow does not write a new row to the database management system (DBMS), but to a client-side buffer. The rows contained in the buffer are written to the DBMS as a batched operation when ICursor.Flush is called, or when the buffer reaches its maximum size. Because a DBMS write can occur on the Flush call or the InsertRow call (if the buffer has reached its maximum size), both of these calls should have appropriate error handling.

                //Buffering can only be leveraged during an edit session.
                IFeatureCursor fCursor = fc.Insert(false);
                foreach (City ct in cities)
                {
                    IPoint point = new PointClass();
                    point.X = ct.X;
                    point.Y = ct.Y;
                    cityBuffer.Shape = point;

                    cityBuffer.set_Value(idxName, ct.Name);
                    cityBuffer.set_Value(idxPop, ct.Population);
                    cityBuffer.set_Value(idxArea, ct.Area);
                    IRowSubtypes cityST = cityBuffer as IRowSubtypes;
                    cityST.InitDefaultValues();
                    fCursor.InsertFeature(cityBuffer);
                }

                fCursor.Flush();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(fCursor);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdateUsingFeature_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;
                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);
                int idxStatus = fc.Fields.FindField("status");

                IQueryFilter qF = new QueryFilterClass();
                qF.WhereClause = "\"Name\" <> \'New York\'";
                //When using a search cursor to perform updates, recycling should always be disabled.
                IFeatureCursor fCursor = fc.Search(qF, false);
                IFeature city = fCursor.NextFeature();
                while (city != null)
                {
                    city.Delete();
                    city.Value[idxStatus] = "New " + city.Value[];
                    city.Store();
                    city = fCursor.NextFeature();
                }


                System.Runtime.InteropServices.Marshal.ReleaseComObject(fCursor);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateUsingUpdateCursor_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;
                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);
                int idxStatus = fc.Fields.FindField("status");

                IQueryFilter qF = new QueryFilterClass();
                qF.WhereClause = "\"Name\" <> \'New York\'";
                //When using a search cursor to perform updates, recycling should always be disabled.
                // In simple cases such as those shown earlier in this topic, enabling recycling is safe and results in better performance. Cases where recycling should not be used are those where multiple features need to be read at once. 
                

                IFeatureCursor fCursor = fc.Update(qF, true);
                IFeature city = fCursor.NextFeature();
                while (city != null)
                {
                    
                    city.set_Value(idxStatus, 1);
                    fCursor.UpdateFeature(city);
                    city = fCursor.NextFeature();
                }


                System.Runtime.InteropServices.Marshal.ReleaseComObject(fCursor);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

      

            
       
        }

        private void btnDeleteFeatures_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                IWorkspace2 ws = fws as IWorkspace2;
                if (ws.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);
                int idxStatus = fc.Fields.FindField("status");

                IQueryFilter qF = new QueryFilterClass();
                qF.WhereClause = "\"Name\" <> \'New York\'";
                //In the simplest case, a single feature that has already been retrieved can be deleted by calling IFeature.Delete. If bulk features are being deleted and the geodatabase is an ArcSDE geodatabase, the most efficient approach requires the use of a search cursor and the IFeature.Delete method.

                //if the geodatabase is a local geodatabase (a file or personal geodatabase), the most efficient method for bulk deletion is the ITable.DeleteSearchedRows method as shown in the following code example:
                ITable tableFC = fc as ITable;
                tableFC.DeleteSearchedRows(qF);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExportWholeGDB_Click(object sender, EventArgs e)
        {
            Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
            IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
            string fileGDBAddress = util.path + "\\" + util.fileGDBName;
            string fcName = util.featureClassName;
            //check the existance of the file geodatabase
            if (!System.IO.Directory.Exists(fileGDBAddress))
            {
                MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                return;
            }

            IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IWorkspace;
            IGdbXmlExport xmlExporter = new GdbExporterClass();
            xmlExporter.ExportWorkspace(ws, util.path + "\\" + util.xmlWorkspaceDocument, true, false, true);


        }

        private void btnExportUSAFDStoXML_Click(object sender, EventArgs e)
        {
            try
            {

                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string featureDSName = util.featureDatasetName;
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory workspaceFactory = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                IWorkspace ws = workspaceFactory.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);




                //retreive the featureDataset
                IWorkspace2 ws2 = ws as IWorkspace2;
                if (ws2.get_NameExists(esriDatasetType.esriDTFeatureDataset, featureDSName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureDataset doesn't exist in the {1} file geodatabase", featureDSName, util.fileGDBName));
                    return;
                }



                IFeatureWorkspace fws = ws as IFeatureWorkspace;
                IFeatureDataset fds = fws.OpenFeatureDataset(featureDSName);
                IName fdsName = fds.FullName;



                // Create a new names enumerator and add the feature dataset name.
                IEnumNameEdit enumNameEdit = new NamesEnumeratorClass();
                enumNameEdit.Add(fdsName);
                IEnumName enumName = enumNameEdit as IEnumName;

                //Typically when name mappings are created, they are from one geodatabase to another and conflicts might occur. When creating name mappings from a geodatabase to a new XML workspace document, the "target" might be several geodatabases, each of which can result in different conflicts. Because conflict resolution can occur when importing an XML workspace document into a geodatabase, it can be disregarded at this stage.

                //In the following code example, the target geodatabase in the GenerateNameMapping example is the source geodatabase. This will create the name mappings with conflicts, but the conflicts can be ignored and the application can move on to the export process.

                //In some cases, modifying the name mappings can be required, for example, if the datasets should be renamed in the workspace document. For more information on working with name mappings, see Copying and pasting geodatabase datasets.
                IDataset wsDataset = ws as IDataset;
                IName wsName = wsDataset.FullName;

                IGeoDBDataTransfer geoDBDataTransfer = new GeoDBDataTransferClass();
                IEnumNameMapping enumNameMapping = null;
                geoDBDataTransfer.GenerateNameMapping(enumName, wsName, out enumNameMapping);

                // Create an exporter and export the dataset with binary geometry, not compressed,
                // and including metadata.


                IGdbXmlExport gdbXmlExport = new GdbExporterClass();
                gdbXmlExport.ExportDatasets(enumNameMapping, util.path + "\\" + util.xmlWorkspaceDocumentDS, true, false, true);
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(workspaceFactory);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreateFDS_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fdsName = util.featureDatasetName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;

                IWorkspace2 ws = fws as IWorkspace2;

                if (ws.get_NameExists(esriDatasetType.esriDTFeatureDataset, fdsName) == true)
                {
                    MessageBox.Show(string.Format("The {0} FeatureDataset already exist in the {1} file geodatabase", fdsName, util.fileGDBName));
                    return;
                }

                //create SRS object
                ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
                int coordinateSystemID = (int)esriSRGeoCSType.esriSRGeoCS_WGS1984;
                ISpatialReference spatialReference = spatialReferenceFactory.CreateGeographicCoordinateSystem(coordinateSystemID);

                ISpatialReferenceResolution spatialReferenceResolution = spatialReference as ISpatialReferenceResolution;
                spatialReferenceResolution.ConstructFromHorizon();
                ISpatialReferenceTolerance spatialReferenceTolerance = spatialReference as ISpatialReferenceTolerance;
                spatialReferenceTolerance.SetDefaultXYTolerance();

                IFeatureDataset fds = fws.CreateFeatureDataset(fdsName, spatialReference);

                //create fields
                IFieldsEdit fields = new FieldsClass();
                fields.FieldCount_2 = 5;

                IFieldEdit field = new FieldClass();
                field.Name_2 = "ObjectID";
                field.Type_2 = esriFieldType.esriFieldTypeOID;
                fields.Field_2[0] = field;

                // Create a geometry definition for the feature class
                // there is no need to set the spatial reference, as it is inherited from the feature dataset.
                IGeometryDefEdit geometryDef = new GeometryDefClass();
                geometryDef.GeometryType_2 = esriGeometryType.esriGeometryPoint;

                field = new FieldClass();
                field.Name_2 = "Shape";
                field.Type_2 = esriFieldType.esriFieldTypeGeometry;
                field.GeometryDef_2 = geometryDef;
                fields.Field_2[1] = field;

                field = new FieldClass();
                field.Name_2 = "Name";
                field.Type_2 = esriFieldType.esriFieldTypeString;
                fields.Field_2[2] = field;

                field = new FieldClass();
                field.Name_2 = "Population";
                field.Type_2 = esriFieldType.esriFieldTypeInteger;
                fields.Field_2[3] = field;


                field = new FieldClass();
                field.Name_2 = "Area";
                field.Type_2 = esriFieldType.esriFieldTypeDouble;
                fields.Field_2[4] = field;

                fds.CreateFeatureClass(util.featureClassName + "2", fields, null, null, esriFeatureType.esriFTSimple, "Shape", null);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }



        private void btnCreateGDBAndTransferData_Click(object sender, EventArgs e)
        {
            try
            {
                string path = util.path;
                string fileGDBName = "tempForExport.gdb";

                if (System.IO.Directory.Exists(path + "\\" + fileGDBName))
                {
                    MessageBox.Show("there is a file geodatabase with the same path and name");
                    return;
                }


                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;

                //wsN is new and empty GDB
                IWorkspaceName wsNTarget = wsF.Create(path, fileGDBName, null, ArcMap.Application.hWnd);
                IName wsNTName = wsNTarget as IName;
                //IWorkspace wsTarget = wsNTName.Open() as IWorkspace;

                //////////////////////////////////////
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string featureDSName = util.featureDatasetName;

                IWorkspace wsSource = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);


                //retreive the featureDataset
                IWorkspace2 ws2 = wsSource as IWorkspace2;
                if (ws2.get_NameExists(esriDatasetType.esriDTFeatureDataset, featureDSName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureDataset doesn't exist in the {1} file geodatabase", featureDSName, util.fileGDBName));
                    return;
                }
                IDataset wsDataset = wsSource as IDataset;
                IName wsName = wsDataset.FullName;

                IFeatureWorkspace fws = wsSource as IFeatureWorkspace;
                IFeatureDataset fds = fws.OpenFeatureDataset(featureDSName);
                IName fdsName = fds.FullName;

                IEnumNameEdit enumNameEdit = new NamesEnumeratorClass();
                enumNameEdit.Add(fdsName);
                IEnumName enumName = enumNameEdit as IEnumName;


                IGeoDBDataTransfer geoDBDataTransfer = new GeoDBDataTransferClass();
                IEnumNameMapping enumNameMapping = null;
                bool foundConflicts = geoDBDataTransfer.GenerateNameMapping(enumName, wsNTName, out enumNameMapping);
                geoDBDataTransfer.Transfer(enumNameMapping, wsNTName);

                MessageBox.Show("data transfer finished successfully");
                //release all the references to singleton object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnImport_Click(object sender, EventArgs e)
        {
            //create new and empty file geodatabase

            try
            {
                string path = util.path;
                string fileGDBName = "tempForImport.gdb";
                string fileGdbFullPath = util.path + "\\" + fileGDBName;

                if (System.IO.Directory.Exists(fileGdbFullPath))
                {
                    MessageBox.Show("there is a file geodatabase with the same path and name");
                    return;
                }


                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;

                //wsN is new and empty GDB
                IWorkspaceName wsNTarget = wsF.Create(path, fileGDBName, null, ArcMap.Application.hWnd);
                IName wsNTName = wsNTarget as IName;
                IWorkspace ws = wsNTName.Open() as IWorkspace;


                string xmlWorkspaceDocPath = util.path + "\\" + util.xmlWorkspaceDocument;

                IGdbXmlImport gdbXmlImport = new GdbImporterClass();
                IEnumNameMapping enumNameMapping = null;
                Boolean conflictsFound = gdbXmlImport.GenerateNameMapping(xmlWorkspaceDocPath, ws, out enumNameMapping);


                // Import the workspace document, including both schema and data.
                gdbXmlImport.ImportWorkspace(xmlWorkspaceDocPath, enumNameMapping, ws, false);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void btnDeleteAllFeaturesInOneShot_Click(object sender, EventArgs e)
        {
            ICommandBars commandBars = ArcMap.Application.Document.CommandBars;
            UID clearSelectedFeaturesUID = new ESRI.ArcGIS.esriSystem.UIDClass();
            clearSelectedFeaturesUID.Value = "{37C833F3-DBFD-11D1-AA7E-00C04FA37860}";
            ICommandItem commandItem = commandBars.Find(clearSelectedFeaturesUID, false, false);

            if (commandItem != null)
            {
                commandItem.Execute();
            }
        }

        private void btnDeleteFGDB_Click(object sender, EventArgs e)
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;

                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                //first all datasets inside it must be deleted then 
                IDataset gdbAsws = fws as IDataset;
                if (gdbAsws.CanDelete())
                {
                    gdbAsws.Delete();
                    MessageBox.Show("Deleted");
                }

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreateEmptyFDS_Click(object sender, EventArgs e)
        {
            Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
            IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
            string fileGDBAddress = util.path + "\\" + util.fileGDBName;
            string fdsName = util.featureDatasetName;
            //check the existance of the file geodatabase
            if (!System.IO.Directory.Exists(fileGDBAddress))
            {
                MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                return;
            }

            //IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
            IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
            IFeatureWorkspace fws = ws as IFeatureWorkspace;

            IWorkspace2 ws2 = fws as IWorkspace2;

            if (ws2.get_NameExists(esriDatasetType.esriDTFeatureDataset, fdsName) == true)
            {
                MessageBox.Show(string.Format("The {0} FeatureDataset already exist in the {1} file geodatabase", fdsName, util.fileGDBName));
                return;
            }

            //create SRS object
            ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
            ISpatialReference srs = spatialReferenceFactory.CreateESRISpatialReferenceFromPRJFile(@"D:\DataFolder\higherResolutionWGS84.prj");
            IFeatureDataset fds = fws.CreateFeatureDataset(fdsName, srs);
            
           
            //int coordinateSystemID = (int)esriSRGeoCSType.esriSRGeoCS_WGS1984;
            ESRI.ArcGIS.Geometry.esriSRProjCSType
            ISpatialReference srs = spatialReferenceFactory.CreateGeographicCoordinateSystem(4326);
            IFeatureDataset fds = fws.CreateFeatureDataset(fdsName, srs);
        }


    }
}
