﻿namespace mgmt
{
    partial class MGMTDockableWin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreatePersonalGDB = new System.Windows.Forms.Button();
            this.btnCreateFeatureClass = new System.Windows.Forms.Button();
            this.btnAssignDomain = new System.Windows.Forms.Button();
            this.btnCreateDomain = new System.Windows.Forms.Button();
            this.btnInsertFeaturesUsingStore = new System.Windows.Forms.Button();
            this.btnInsertCursor = new System.Windows.Forms.Button();
            this.btnUpdateUsingFeature = new System.Windows.Forms.Button();
            this.btnUpdateUsingUpdateCursor = new System.Windows.Forms.Button();
            this.btnDeleteFeatures = new System.Windows.Forms.Button();
            this.btnExportWholeGDB = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnExportUSAFDStoXML = new System.Windows.Forms.Button();
            this.btnCreateFDS = new System.Windows.Forms.Button();
            this.btnDeleteAllFeaturesInOneShot = new System.Windows.Forms.Button();
            this.btnCreateGDBAndTransferData = new System.Windows.Forms.Button();
            this.btnDeleteFGDB = new System.Windows.Forms.Button();
            this.btnCreateEmptyFDS = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCreatePersonalGDB
            // 
            this.btnCreatePersonalGDB.Location = new System.Drawing.Point(23, 0);
            this.btnCreatePersonalGDB.Name = "btnCreatePersonalGDB";
            this.btnCreatePersonalGDB.Size = new System.Drawing.Size(293, 33);
            this.btnCreatePersonalGDB.TabIndex = 0;
            this.btnCreatePersonalGDB.Text = "Create File GDB";
            this.btnCreatePersonalGDB.UseVisualStyleBackColor = true;
            this.btnCreatePersonalGDB.Click += new System.EventHandler(this.btnCreatePersonalGDB_Click);
            // 
            // btnCreateFeatureClass
            // 
            this.btnCreateFeatureClass.Location = new System.Drawing.Point(23, 84);
            this.btnCreateFeatureClass.Name = "btnCreateFeatureClass";
            this.btnCreateFeatureClass.Size = new System.Drawing.Size(293, 33);
            this.btnCreateFeatureClass.TabIndex = 1;
            this.btnCreateFeatureClass.Text = "Create standalone Point FeatureClass";
            this.btnCreateFeatureClass.UseVisualStyleBackColor = true;
            this.btnCreateFeatureClass.Click += new System.EventHandler(this.btnCreateFeatureClass_Click);
            // 
            // btnAssignDomain
            // 
            this.btnAssignDomain.Location = new System.Drawing.Point(23, 252);
            this.btnAssignDomain.Name = "btnAssignDomain";
            this.btnAssignDomain.Size = new System.Drawing.Size(293, 33);
            this.btnAssignDomain.TabIndex = 2;
            this.btnAssignDomain.Text = "Add field and Assign domain To existing Field";
            this.btnAssignDomain.UseVisualStyleBackColor = true;
            this.btnAssignDomain.Click += new System.EventHandler(this.btnAssignDomain_Click);
            // 
            // btnCreateDomain
            // 
            this.btnCreateDomain.Location = new System.Drawing.Point(23, 210);
            this.btnCreateDomain.Name = "btnCreateDomain";
            this.btnCreateDomain.Size = new System.Drawing.Size(293, 33);
            this.btnCreateDomain.TabIndex = 3;
            this.btnCreateDomain.Text = "Create Domain";
            this.btnCreateDomain.UseVisualStyleBackColor = true;
            this.btnCreateDomain.Click += new System.EventHandler(this.btnCreateDomain_Click);
            // 
            // btnInsertFeaturesUsingStore
            // 
            this.btnInsertFeaturesUsingStore.Location = new System.Drawing.Point(23, 294);
            this.btnInsertFeaturesUsingStore.Name = "btnInsertFeaturesUsingStore";
            this.btnInsertFeaturesUsingStore.Size = new System.Drawing.Size(293, 33);
            this.btnInsertFeaturesUsingStore.TabIndex = 4;
            this.btnInsertFeaturesUsingStore.Text = "Feature.Store()";
            this.btnInsertFeaturesUsingStore.UseVisualStyleBackColor = true;
            this.btnInsertFeaturesUsingStore.Click += new System.EventHandler(this.btnInsertFeaturesUsingStore_Click);
            // 
            // btnInsertCursor
            // 
            this.btnInsertCursor.Location = new System.Drawing.Point(23, 336);
            this.btnInsertCursor.Name = "btnInsertCursor";
            this.btnInsertCursor.Size = new System.Drawing.Size(293, 33);
            this.btnInsertCursor.TabIndex = 5;
            this.btnInsertCursor.Text = "using Insert cursor";
            this.btnInsertCursor.UseVisualStyleBackColor = true;
            this.btnInsertCursor.Click += new System.EventHandler(this.btnInsertCursor_Click);
            // 
            // btnUpdateUsingFeature
            // 
            this.btnUpdateUsingFeature.Location = new System.Drawing.Point(23, 378);
            this.btnUpdateUsingFeature.Name = "btnUpdateUsingFeature";
            this.btnUpdateUsingFeature.Size = new System.Drawing.Size(293, 33);
            this.btnUpdateUsingFeature.TabIndex = 6;
            this.btnUpdateUsingFeature.Text = "Update using the Search Cursor";
            this.btnUpdateUsingFeature.UseVisualStyleBackColor = true;
            this.btnUpdateUsingFeature.Click += new System.EventHandler(this.btnUpdateUsingFeature_Click);
            // 
            // btnUpdateUsingUpdateCursor
            // 
            this.btnUpdateUsingUpdateCursor.Location = new System.Drawing.Point(23, 420);
            this.btnUpdateUsingUpdateCursor.Name = "btnUpdateUsingUpdateCursor";
            this.btnUpdateUsingUpdateCursor.Size = new System.Drawing.Size(293, 33);
            this.btnUpdateUsingUpdateCursor.TabIndex = 7;
            this.btnUpdateUsingUpdateCursor.Text = "Update using the Update Cursor";
            this.btnUpdateUsingUpdateCursor.UseVisualStyleBackColor = true;
            this.btnUpdateUsingUpdateCursor.Click += new System.EventHandler(this.btnUpdateUsingUpdateCursor_Click);
            // 
            // btnDeleteFeatures
            // 
            this.btnDeleteFeatures.Location = new System.Drawing.Point(23, 462);
            this.btnDeleteFeatures.Name = "btnDeleteFeatures";
            this.btnDeleteFeatures.Size = new System.Drawing.Size(293, 33);
            this.btnDeleteFeatures.TabIndex = 8;
            this.btnDeleteFeatures.Text = "Delete Features";
            this.btnDeleteFeatures.UseVisualStyleBackColor = true;
            this.btnDeleteFeatures.Click += new System.EventHandler(this.btnDeleteFeatures_Click);
            // 
            // btnExportWholeGDB
            // 
            this.btnExportWholeGDB.Location = new System.Drawing.Point(23, 548);
            this.btnExportWholeGDB.Name = "btnExportWholeGDB";
            this.btnExportWholeGDB.Size = new System.Drawing.Size(293, 33);
            this.btnExportWholeGDB.TabIndex = 9;
            this.btnExportWholeGDB.Text = "Export Full GDB to XML";
            this.btnExportWholeGDB.UseVisualStyleBackColor = true;
            this.btnExportWholeGDB.Click += new System.EventHandler(this.btnExportWholeGDB_Click);
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(23, 674);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(293, 33);
            this.btnImport.TabIndex = 10;
            this.btnImport.Text = "Import Full GDB to XML";
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnExportUSAFDStoXML
            // 
            this.btnExportUSAFDStoXML.Location = new System.Drawing.Point(23, 590);
            this.btnExportUSAFDStoXML.Name = "btnExportUSAFDStoXML";
            this.btnExportUSAFDStoXML.Size = new System.Drawing.Size(293, 33);
            this.btnExportUSAFDStoXML.TabIndex = 11;
            this.btnExportUSAFDStoXML.Text = "Export pointFeatureClasses FDS to XML";
            this.btnExportUSAFDStoXML.UseVisualStyleBackColor = true;
            this.btnExportUSAFDStoXML.Click += new System.EventHandler(this.btnExportUSAFDStoXML_Click);
            // 
            // btnCreateFDS
            // 
            this.btnCreateFDS.Location = new System.Drawing.Point(23, 168);
            this.btnCreateFDS.Name = "btnCreateFDS";
            this.btnCreateFDS.Size = new System.Drawing.Size(293, 33);
            this.btnCreateFDS.TabIndex = 12;
            this.btnCreateFDS.Text = "Create FeatureDataset";
            this.btnCreateFDS.UseVisualStyleBackColor = true;
            this.btnCreateFDS.Click += new System.EventHandler(this.btnCreateFDS_Click);
            // 
            // btnDeleteAllFeaturesInOneShot
            // 
            this.btnDeleteAllFeaturesInOneShot.Location = new System.Drawing.Point(23, 504);
            this.btnDeleteAllFeaturesInOneShot.Name = "btnDeleteAllFeaturesInOneShot";
            this.btnDeleteAllFeaturesInOneShot.Size = new System.Drawing.Size(293, 35);
            this.btnDeleteAllFeaturesInOneShot.TabIndex = 13;
            this.btnDeleteAllFeaturesInOneShot.Text = "Delete All Features in one shot";
            this.btnDeleteAllFeaturesInOneShot.UseVisualStyleBackColor = true;
            this.btnDeleteAllFeaturesInOneShot.Click += new System.EventHandler(this.btnDeleteAllFeaturesInOneShot_Click);
            // 
            // btnCreateGDBAndTransferData
            // 
            this.btnCreateGDBAndTransferData.Location = new System.Drawing.Point(23, 632);
            this.btnCreateGDBAndTransferData.Name = "btnCreateGDBAndTransferData";
            this.btnCreateGDBAndTransferData.Size = new System.Drawing.Size(293, 33);
            this.btnCreateGDBAndTransferData.TabIndex = 14;
            this.btnCreateGDBAndTransferData.Text = "Create empty FGDB and Transfer MajorFC";
            this.btnCreateGDBAndTransferData.UseVisualStyleBackColor = true;
            this.btnCreateGDBAndTransferData.Click += new System.EventHandler(this.btnCreateGDBAndTransferData_Click);
            // 
            // btnDeleteFGDB
            // 
            this.btnDeleteFGDB.Location = new System.Drawing.Point(23, 42);
            this.btnDeleteFGDB.Name = "btnDeleteFGDB";
            this.btnDeleteFGDB.Size = new System.Drawing.Size(293, 33);
            this.btnDeleteFGDB.TabIndex = 15;
            this.btnDeleteFGDB.Text = "Delete File GDB";
            this.btnDeleteFGDB.UseVisualStyleBackColor = true;
            this.btnDeleteFGDB.Click += new System.EventHandler(this.btnDeleteFGDB_Click);
            // 
            // btnCreateEmptyFDS
            // 
            this.btnCreateEmptyFDS.Location = new System.Drawing.Point(23, 126);
            this.btnCreateEmptyFDS.Name = "btnCreateEmptyFDS";
            this.btnCreateEmptyFDS.Size = new System.Drawing.Size(293, 33);
            this.btnCreateEmptyFDS.TabIndex = 16;
            this.btnCreateEmptyFDS.Text = "Create Empty FDS";
            this.btnCreateEmptyFDS.UseVisualStyleBackColor = true;
            this.btnCreateEmptyFDS.Click += new System.EventHandler(this.btnCreateEmptyFDS_Click);
            // 
            // MGMTDockableWin
            // 
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.btnCreateEmptyFDS);
            this.Controls.Add(this.btnDeleteFGDB);
            this.Controls.Add(this.btnCreateGDBAndTransferData);
            this.Controls.Add(this.btnDeleteAllFeaturesInOneShot);
            this.Controls.Add(this.btnCreateFDS);
            this.Controls.Add(this.btnExportUSAFDStoXML);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.btnExportWholeGDB);
            this.Controls.Add(this.btnDeleteFeatures);
            this.Controls.Add(this.btnUpdateUsingUpdateCursor);
            this.Controls.Add(this.btnUpdateUsingFeature);
            this.Controls.Add(this.btnInsertCursor);
            this.Controls.Add(this.btnInsertFeaturesUsingStore);
            this.Controls.Add(this.btnCreateDomain);
            this.Controls.Add(this.btnAssignDomain);
            this.Controls.Add(this.btnCreateFeatureClass);
            this.Controls.Add(this.btnCreatePersonalGDB);
            this.Name = "MGMTDockableWin";
            this.Size = new System.Drawing.Size(348, 734);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCreatePersonalGDB;
        private System.Windows.Forms.Button btnCreateFeatureClass;
        private System.Windows.Forms.Button btnAssignDomain;
        private System.Windows.Forms.Button btnCreateDomain;
        private System.Windows.Forms.Button btnInsertFeaturesUsingStore;
        private System.Windows.Forms.Button btnInsertCursor;
        private System.Windows.Forms.Button btnUpdateUsingFeature;
        private System.Windows.Forms.Button btnUpdateUsingUpdateCursor;
        private System.Windows.Forms.Button btnDeleteFeatures;
        private System.Windows.Forms.Button btnExportWholeGDB;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Button btnExportUSAFDStoXML;
        private System.Windows.Forms.Button btnCreateFDS;
        private System.Windows.Forms.Button btnDeleteAllFeaturesInOneShot;
        private System.Windows.Forms.Button btnCreateGDBAndTransferData;
        private System.Windows.Forms.Button btnDeleteFGDB;
        private System.Windows.Forms.Button btnCreateEmptyFDS;

    }
}
