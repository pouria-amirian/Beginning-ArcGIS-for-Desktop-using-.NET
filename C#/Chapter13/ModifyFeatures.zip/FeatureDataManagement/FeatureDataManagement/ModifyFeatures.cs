﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Windows.Forms;
using ESRI.ArcGIS.Editor;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;

namespace FeatureDataManagement
{
    public class ModifyFeatures : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ModifyFeatures()
        {
        }

        protected override void OnClick()
        {
            try
            {
                //creating a domain
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }
                ICodedValueDomain codedDomain = new CodedValueDomainClass();
                codedDomain.AddCode(1, "Is Capital");
                codedDomain.AddCode(0, "Is not Capital");
                IDomain capitalDomain = codedDomain as IDomain;
                capitalDomain.Name = "CapitalDomain";
                capitalDomain.FieldType = esriFieldType.esriFieldTypeSmallInteger;
                capitalDomain.SplitPolicy = esriSplitPolicyType.esriSPTDuplicate;
                capitalDomain.MergePolicy = esriMergePolicyType.esriMPTAreaWeighted;
                IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
                IWorkspaceDomains3 wsD = ws as IWorkspaceDomains3;
                wsD.AddDomain(capitalDomain);

                //add field and assign domain
                //get the FeatureClass
                IFeatureWorkspace fws = ws as IFeatureWorkspace;
                IFeatureClass fc = fws.OpenFeatureClass(util.featureClassName);
                            
                //create a new field
                IFieldEdit2 field = new FieldClass();
                field.Name_2 = "status";
                field.Type_2 = esriFieldType.esriFieldTypeSmallInteger;
                field.DefaultValue_2 = 0;
                field.Domain_2 = capitalDomain;

                fc.AddField(field);

                //update
                int idxStatus = fc.Fields.FindField("status");

                IQueryFilter qF = new QueryFilterClass();
                qF.WhereClause = "\"Name\" <> \'New York\'";
                
                IFeatureCursor fCursor = fc.Update(qF, true);
                IFeature city = fCursor.NextFeature();
                while (city != null)
                {
                    city.set_Value(idxStatus, 1);
                    fCursor.UpdateFeature(city);
                    city = fCursor.NextFeature();
                }


                System.Runtime.InteropServices.Marshal.ReleaseComObject(fCursor);

                //release all the references to singleton object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
