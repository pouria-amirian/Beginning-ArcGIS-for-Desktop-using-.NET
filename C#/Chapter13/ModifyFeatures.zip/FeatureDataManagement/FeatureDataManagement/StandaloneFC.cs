﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Windows.Forms;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geometry;

namespace FeatureDataManagement
{
    public class StandaloneFC : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public StandaloneFC()
        {
        }

        protected override void OnClick()
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }
                IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
                IFeatureWorkspace fws = ws as IFeatureWorkspace;
                //check the existance of the FeatureClass
                IWorkspace2 ws2 = fws as IWorkspace2;
                if (ws2.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == true)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass already exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //create fields
                IFieldsEdit fields = new FieldsClass();

                IFieldEdit field = new FieldClass();
                field.Name_2 = "ObjectID";
                field.Type_2 = esriFieldType.esriFieldTypeOID;
                fields.AddField(field);

                // Create a geometry definition (and spatial reference) for the feature class.
                IGeometryDefEdit geometryDefEdit = new GeometryDefClass();
                geometryDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPoint;
                ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
                int coordinateSystemID = (int)esriSRGeoCSType.esriSRGeoCS_WGS1984;
                ISpatialReference spatialReference = spatialReferenceFactory.CreateGeographicCoordinateSystem(coordinateSystemID);
                geometryDefEdit.SpatialReference_2 = spatialReference;

                field = new FieldClass();
                field.Name_2 = "Shape";
                field.Type_2 = esriFieldType.esriFieldTypeGeometry;
                field.GeometryDef_2 = geometryDefEdit as IGeometryDef;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Name";
                field.Type_2 = esriFieldType.esriFieldTypeString;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Population";
                field.Type_2 = esriFieldType.esriFieldTypeInteger;
                fields.AddField(field);

                field = new FieldClass();
                field.Name_2 = "Area";
                field.Type_2 = esriFieldType.esriFieldTypeDouble;
                fields.AddField(field);

                IFeatureClass fc = fws.CreateFeatureClass(fcName, fields, null, null, esriFeatureType.esriFTSimple, "Shape", null);
                MessageBox.Show(fcName + " created successsfully");
                //release all the references to singleton COM object (WorkspaceFactory)
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
