﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
//using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geometry;
using System.Windows.Forms;
using ESRI.ArcGIS.Editor;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;


namespace FeatureDataManagement
{
    public class InsertNewFeatures : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public InsertNewFeatures()
        {
        }

        protected override void OnClick()
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fcName = util.featureClassName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }
                IWorkspace ws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
                IFeatureWorkspace fws = ws as IFeatureWorkspace;
                IWorkspace2 ws2 = fws as IWorkspace2;
                if (ws2.get_NameExists(esriDatasetType.esriDTFeatureClass, fcName) == false)
                {
                    MessageBox.Show(string.Format("The {0} FeatureClass doesn't exist in the {1} file geodatabase", fcName, util.fileGDBName));
                    return;
                }

                //get the FeatureClass
                IFeatureClass fc = fws.OpenFeatureClass(fcName);
                //create list of major cities
                List<City> cities = new List<City>();
                cities.Add(new City("New York", 16500000, 1210, -74.0999, 40.7500));
                cities.Add(new City("Tokyo", 23650000, 2187, 139.8092, 35.6830));
                cities.Add(new City("Berlin", 5100000, 892, 13.3276, 52.5163));
                cities.Add(new City("Paris", 10000000, 105, 2.4328, 48.8815));
              
                IFeatureLayer fl = new FeatureLayerClass();
                fl.Name = fcName;
                fl.FeatureClass = fc;
                IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
                IMap map = mxdoc.FocusMap;
                map.AddLayer(fl);

             
                int idxName = fc.Fields.FindField("Name");
                int idxPop = fc.Fields.FindField("Population");
                int idxArea = fc.Fields.FindField("Area");

                if (idxName < 0 || idxArea < 0 || idxPop < 0)
                { return; }
                UID editorExtension = new UIDClass();
                editorExtension.Value = "esriEditor.Editor";
                IEditor3 editor = ArcMap.Application.FindExtensionByCLSID(editorExtension) as IEditor3;
                editor.StartEditing(ws);

                IFeatureBuffer cityBuffer = fc.CreateFeatureBuffer();
                //Buffering can only be used during an edit session.
                IFeatureCursor fCursor = fc.Insert(true);
                foreach (City ct in cities)
                {
                    IPoint point = new PointClass();
                    point.X = ct.X;
                    point.Y = ct.Y;
                    cityBuffer.Shape = point;

                    cityBuffer.set_Value(idxName, ct.Name);
                    cityBuffer.set_Value(idxPop, ct.Population);
                    cityBuffer.set_Value(idxArea, ct.Area);
                    IRowSubtypes cityST = cityBuffer as IRowSubtypes;
                    cityST.InitDefaultValues();
                    fCursor.InsertFeature(cityBuffer);
                }

                fCursor.Flush();
                editor.StopEditing(true);
                MessageBox.Show("All features inserted successfully");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(fCursor);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
                mxdoc.ActiveView.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        protected override void OnUpdate()
        {
        }
    }
}
