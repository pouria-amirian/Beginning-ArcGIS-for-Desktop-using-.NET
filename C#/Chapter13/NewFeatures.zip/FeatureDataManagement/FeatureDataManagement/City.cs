﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureDataManagement
{
    class City
    {
        //properties
        public string Name
        { get; set; }

        public long Population
        { get; set; }

        public decimal Area
        { get; set; }

        public double X
        { get; set; }

        public double Y
        { get; set; }

        public City(string name, long population, decimal area, double x, double y)
        {
            this.Name = name;
            this.Population = population;
            this.Area = area;
            this.X = x;
            this.Y = y;
        }
    }
}
