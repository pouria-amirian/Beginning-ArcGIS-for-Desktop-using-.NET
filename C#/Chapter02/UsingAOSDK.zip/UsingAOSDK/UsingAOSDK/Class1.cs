using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UsingAOSDK
{
    [Guid("e9fc66b1-2fba-45ee-a88e-da7688c24a49")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("UsingAOSDK.Class1")]
    public class Class1
    {
    }
}
