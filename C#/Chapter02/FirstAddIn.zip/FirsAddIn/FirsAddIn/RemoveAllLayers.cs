﻿using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FirsAddIn
{
    public class RemoveAllLayers : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public RemoveAllLayers()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            map.ClearLayers();
            IActiveView activeView = map as IActiveView;
            activeView.Refresh();
            mxdoc.UpdateContents();

        }

        protected override void OnClick()
        {
        }

        protected override void OnUpdate()
        {
        }
    }
}
