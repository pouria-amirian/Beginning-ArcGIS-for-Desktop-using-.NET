﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FirsAddIn
{
    public class ShowTime : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ShowTime()
        {
        }

        protected override void OnClick()
        {
            ArcMap.Application.Caption = DateTime.Now.ToLongTimeString();
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
