﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.CatalogUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Catalog;

namespace LayersOfMaps
{
    public class ShowAddDialog : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ShowAddDialog()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;

            //Setting some properties for GxDialog instance
            IGxDialog gxd = new GxDialogClass();
            gxd.AllowMultiSelect = true;
            gxd.ButtonCaption = "Add Layer";
            gxd.Title = "Add Layer Window";
            gxd.RememberLocation = true;

            //creating filter for GxDialog instance
            IGxObjectFilter gxObjFilter = new GxFilterLayersClass();
            gxd.ObjectFilter = gxObjFilter;

            //Adding each selected layer to map
            IEnumGxObject gxEnumObj;
            gxd.DoModalOpen(ArcMap.Application.hWnd, out gxEnumObj);
            
            IGxObject gxObj = gxEnumObj.Next();
            while (gxObj != null)
            {
                IGxLayer gxlayer = gxObj as IGxLayer;
                mxdoc.AddLayer(gxlayer.Layer);
                gxObj = gxEnumObj.Next();
            }
            //refreshing the main window and TOC
            mxdoc.ActiveView.Refresh();
            mxdoc.UpdateContents();
        }

        protected override void OnUpdate()
        {
        }
    }
}
