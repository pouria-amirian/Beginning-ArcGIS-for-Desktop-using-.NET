﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;

namespace LayersOfMaps
{
    public class FeatureLayerInspector : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public FeatureLayerInspector()
        {
        }

        protected override void OnClick()
        {
            string data = "";
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            ILayer selectedLayer = mxdoc.SelectedLayer;

            if (selectedLayer != null)
            {
                if (selectedLayer is IFeatureLayer2)
                {
                    //using IFeatureLayer2 interface
                    IFeatureLayer2 selectedFL = selectedLayer as IFeatureLayer2;
                    data += "Data Source Type: " + selectedFL.DataSourceType + "\n";
                    data += "Shape Type: " + selectedFL.ShapeType + "\n";
                    data += "Is Selectable? " + selectedFL.Selectable + "\n";
                    data += "Primary Display Field: " + selectedFL.DisplayField + "\n";

                    //using ILayerFields interface
                    ILayerFields selectedLayerFields = selectedFL as ILayerFields;
                    data += "field count: " + selectedLayerFields.FieldCount + "\n";
                    data += "Third Field Name: " + selectedLayerFields.Field[2].Name;

                    //using IGeoFeatureLayer interface
                    IGeoFeatureLayer selectedGFL = selectedFL as IGeoFeatureLayer;
                    //toggle labeling for selected layer
                    if (selectedGFL.DisplayAnnotation == true)
                    {
                        selectedGFL.DisplayAnnotation = false;
                    }
                    else
                    {
                        selectedGFL.DisplayAnnotation = true;
                    }

                    //since we modify rendering of the map by toggle labeling
                    //we have to refresh the main window of ArcMap
                    mxdoc.ActiveView.Refresh();


                    Message msgForm = new Message();
                    msgForm.lbl.Text = data;
                    msgForm.ShowDialog();
                }

                if (selectedLayer is IRasterLayer)
                {
                    IRasterLayer selectedRL = selectedLayer as IRasterLayer;
                    data += "Number of Bands: " + selectedRL.BandCount + "\n";
                    data += "Number of Columns: " + selectedRL.ColumnCount + "\n";
                    data += "Number of Rows: " + selectedRL.RowCount + "\n";
                    data += "File Path: " + selectedRL.FilePath + "\n";
                    data += "Is Pyramid Created? " + selectedRL.PyramidPresent;

                    Message msgForm = new Message();
                    msgForm.lbl.Text = data;
                    msgForm.ShowDialog();
                }
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
