﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
namespace SimpleSchemaReporter
{
    public class SimpleSchemaReporter : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public SimpleSchemaReporter()
        {
        }

        protected override void OnClick()
        {
       IMxDocument mxDoc = ArcMap.Application.Document as IMxDocument;

            if (mxDoc.SelectedItem is IFeatureLayer2 || mxDoc.SelectedItem is ITable)
            {
                ITable selectedTbl = mxDoc.SelectedItem as ITable;
                reportSchema(selectedTbl);

            }
        }
         void reportSchema(ITable table)
        {
            //Build a generic list of fldClass instances 
            List<fldClass> fldClassList = new List<fldClass>();

            
            IFields2 fields = table.Fields as IFields2;
            for (int i = 0; i < fields.FieldCount; i++)
            {
                IField2 field = fields.Field[i] as IField2;
                fldClass fldClassInstance = new fldClass(i + 1);
                //code for dealing with each field
                fldClassInstance.AliasName = field.AliasName;
                fldClassInstance.Name = field.Name;

                fldClassInstance.IsNullable = field.IsNullable;
                fldClassInstance.IsRequired = field.Required;

                fldClassInstance.FieldType = field.Type;
                fldClassInstance.Length = field.Length;
                //populating list
                fldClassList.Add(fldClassInstance);
            }
            //for being able to use the Name of Table or FeatureClass
            IDataset dsTable = table as IDataset;
            
            frmGrid gridForm = new frmGrid();
            //databinding
            gridForm.dgv.DataSource = fldClassList;
            gridForm.Text = "Simple Schema of: " + dsTable.Name;
            gridForm.ShowDialog();
        }
        
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
