﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Catalog;
using ESRI.ArcGIS.CatalogUI;
using ESRI.ArcGIS.Framework;

namespace SimpleSchemaReporter
{
    public class AddAllFeatureClasses : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public AddAllFeatureClasses()
        {
        }

        protected override void OnClick()
        {
            IGxDialog gxd = new GxDialogClass();
            gxd.AllowMultiSelect = false;
            gxd.ButtonCaption = "Add FileGDB";
            gxd.Title = "Add All FeatureClasses inside FileGDB";
            gxd.RememberLocation = true;

            IGxObjectFilter gxObjFilter = new GxFilterFileGeodatabasesClass();
            gxd.ObjectFilter = gxObjFilter;

            IEnumGxObject gxEnumObj;
            gxd.DoModalOpen(ArcMap.Application.hWnd, out gxEnumObj);

            IGxObject gxObj = gxEnumObj.Next();
            //getting the address of fileGDB
            string fileGDBAddress = gxObj.FullName;

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IWorkspaceFactory wsf = new FileGDBWorkspaceFactoryClass();
            IFeatureWorkspace fws = wsf.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
            IWorkspace ws = fws as IWorkspace;
            //get all FeatureDatasets inside fileGDB
            IEnumDataset enumDS = ws.get_Datasets(esriDatasetType.esriDTFeatureDataset);
            try
            {
                //first FeatureDataset
                IDataset featureDataSet = enumDS.Next();
                while (featureDataSet != null)
                {
                    //get all FeatureClasses inside a FeatureDataset
                    IEnumDataset featureClassesInFDS = featureDataSet.Subsets;
                    IDataset singleFeatureClassAsDataset = featureClassesInFDS.Next();

                    while (singleFeatureClassAsDataset != null)
                    {
                        if (singleFeatureClassAsDataset is IFeatureClass)
                        {
                            IFeatureClass singleFeatureClass = singleFeatureClassAsDataset as IFeatureClass;
                            IFeatureLayer featureLayer = new FeatureLayerClass();
                            featureLayer.Name = singleFeatureClassAsDataset.Name;
                            featureLayer.FeatureClass = singleFeatureClass;
                            mxdoc.AddLayer(featureLayer);
                        }
                        singleFeatureClassAsDataset = featureClassesInFDS.Next();
                    }
                    featureDataSet = enumDS.Next();
                }
                mxdoc.ActiveView.Refresh();
                mxdoc.UpdateContents();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, ex.Source);
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
