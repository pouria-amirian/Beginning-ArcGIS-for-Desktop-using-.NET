﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Catalog;
using ESRI.ArcGIS.CatalogUI;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geodatabase;

namespace CSV2Table
{
    public class csvConvertor : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public enum FieldDataType
        {
            numeric,
            text,
            date
        }

        public csvConvertor()
        {
        }



        protected override void OnClick()
        {
            //using gxdiaolog to get the text file
            IGxDialog gxd = new GxDialogClass();
            gxd.AllowMultiSelect = false;
            gxd.ButtonCaption = "Select txt file";
            gxd.Title = "Select a text file to be converted to a Table inside a File GDB";
            gxd.RememberLocation = true;

            IGxObjectFilter gxTxtFilter = new GxFilterTextFilesClass();
            gxd.ObjectFilter = gxTxtFilter;

            IEnumGxObject gxEnumObj;
            gxd.DoModalOpen(ArcCatalog.Application.hWnd, out gxEnumObj);

            IGxObject gxObj = gxEnumObj.Next();
            //user clicks on cancel button
            if (gxObj == null)
            { return; }

            //getting the address of text file
            string fileAddress = gxObj.FullName;
            //set the name of table as the name of text file
            string tableName = gxObj.BaseName;
            //again displaying gxDialog to select file GDB
            gxd.ButtonCaption = "Select FileGDB";
            gxd.Title = "Select target file Geodatabase ";
            IGxObjectFilter gxGDBFilter = new GxFilterFileGeodatabasesClass();
            gxd.ObjectFilter = gxGDBFilter;
            gxd.DoModalOpen(ArcCatalog.Application.hWnd, out gxEnumObj);
            gxObj = gxEnumObj.Next();
            if (gxObj == null)
            { return; }
            //getting the address of fileGDB
            string fileGDBAddress = gxObj.FullName;

            FileStream fs = new FileStream(fileAddress, FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            try
            {
                //read the first line (field names)
                string lineOfTxtFile = sr.ReadLine();
                //extracting fieldNames
                string[] spliter = { "," };
                string[] fieldNames = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries);
                //read the second line of text file (first line of data)
                lineOfTxtFile = sr.ReadLine();
                //create fields based on the data type of first record
                string[] dataItems = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries);
                //Create collection of Fields to be used to build a Table
                IFieldsEdit fields = CreateTableSchema(dataItems, fieldNames);
                //create Table instance
                ITable table = CreateTable(tableName, fields, fileGDBAddress);
                //table exists
                if (table == null)
                { return; }

                //create each row as reader reads the text file
                while (lineOfTxtFile != null)
                {
                    IRow row = table.CreateRow();
                    //Important tip: any table must have one OID Field
                    //the first field is OID
                    for (int i = 0; i < table.Fields.FieldCount - 1; i++)
                    {
                        if (table.Fields.Field[i + 1].Type == esriFieldType.esriFieldTypeDouble)
                        {
                            row.Value[i + 1] = double.Parse(dataItems[i]);
                        }
                        else if (table.Fields.Field[i].Type == esriFieldType.esriFieldTypeDate)
                        {
                            row.Value[i + 1] = DateTime.Parse(dataItems[i]);
                        }
                        else
                        {
                            row.Value[i + 1] = dataItems[i].Trim();
                        }
                    }
                    //saving a row in table
                    row.Store();

                    lineOfTxtFile = sr.ReadLine();
                    if (lineOfTxtFile != null)
                    {
                        dataItems = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries);
                    }
                }
            }
            catch (Exception ex)
            {
                ArcCatalog.Application.Caption = ex.Message;
            }
            finally
            {
                sr.Close();
                fs.Close();
            }

        }


        private ITable CreateTable(string tableName, IFieldsEdit fields, string fileGDBAddress)
        {

            IWorkspaceFactory wsf = new FileGDBWorkspaceFactoryClass();
            IWorkspace ws = wsf.OpenFromFile(fileGDBAddress, ArcCatalog.Application.hWnd);

            IFeatureWorkspace fws = ws as IFeatureWorkspace;
            IWorkspace2 ws2 = ws as IWorkspace2;
            if (!ws2.get_NameExists(esriDatasetType.esriDTTable, tableName))
            {
                ITable table = fws.CreateTable(tableName, fields, null, null, "");
                return table;
            }
            return null;
        }



        private FieldDataType DetermineTheFieldType(string item)
        {
            double num;
            DateTime date;
            if (double.TryParse(item, out num))
            {
                return FieldDataType.numeric;
            }
            else if (DateTime.TryParse(item, out date))
            {
                return FieldDataType.date;
            }
            //otherwise it is text
            return FieldDataType.text;
        }

        private IFieldsEdit CreateTableSchema(string[] dataItemsOfFirstLine, string[] fieldNames)
        {
            IFieldsEdit fields = new FieldsClass();
            fields.FieldCount_2 = fieldNames.Length + 1;
            //creating OID field
            IFieldEdit OIDField = new FieldClass() as IFieldEdit2;
            OIDField.Name_2 = "ObjectIDentifier";
            OIDField.Type_2 = esriFieldType.esriFieldTypeOID;
            fields.Field_2[0] = OIDField;

            for (int i = 0; i < fieldNames.Length; i++)
            {
                IFieldEdit2 newField = new FieldClass() as IFieldEdit2;
                FieldDataType FDT = DetermineTheFieldType(dataItemsOfFirstLine[i]);

                newField.Name_2 = fieldNames[i].Trim();

                switch (FDT)
                {
                    case FieldDataType.numeric:
                        newField.Type_2 = esriFieldType.esriFieldTypeDouble;
                        break;
                    case FieldDataType.date:
                        newField.Type_2 = esriFieldType.esriFieldTypeDate;
                        break;
                    default:
                        newField.Type_2 = esriFieldType.esriFieldTypeString;
                        break;
                }

                fields.Field_2[i + 1] = newField;
            }
            return fields;
        }


        protected override void OnUpdate()
        {
            Enabled = ArcCatalog.Application != null;
        }
    }
}
