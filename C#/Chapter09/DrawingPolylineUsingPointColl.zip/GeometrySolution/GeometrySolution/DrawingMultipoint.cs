﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class DrawingMultipoint : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawingMultipoint()
        {
        }

        protected override void OnClick()
        {
            IPoint centerPoint = new PointClass();
            centerPoint.PutCoords(0, 0);

            IPoint fromPoint = new PointClass();
            fromPoint.PutCoords(100, 0);

            IPoint toPoint = new PointClass();
            toPoint.PutCoords(0, 200);

            ICircularArc circularArcConstruction = new CircularArcClass();
            circularArcConstruction.PutCoords(centerPoint, fromPoint, toPoint, esriArcOrientation.esriArcClockwise);

            IMultipoint multipoint = new MultipointClass();
            IConstructMultipoint multipointConst = multipoint as IConstructMultipoint;
            //divide circularArc in equal-length parts
            multipointConst.ConstructDivideLength(circularArcConstruction as ICurve, 50);

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 100; color.Blue = 255; color.Green = 0;

            ISimpleMarkerSymbol simpleMarkerSymbol = new SimpleMarkerSymbolClass();
            simpleMarkerSymbol.Color = color;
            screenDisp.SetSymbol(simpleMarkerSymbol as ISymbol);
            screenDisp.DrawMultipoint(multipoint);

            screenDisp.FinishDrawing();

        }

        protected override void OnUpdate()
        {
        }
    }
}
