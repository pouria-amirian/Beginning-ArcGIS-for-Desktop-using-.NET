﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;
namespace GeometrySolution
{
    public class DrawPoints : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawPoints()
        {
        }

        protected override void OnClick()
        {
            IPoint p1 = new PointClass();
            p1.X = 10; p1.Y = 10;

            IPoint p2 = new PointClass();
            p2.X = 20; p2.Y = 20;

            IPoint p3 = new PointClass();
            p3.PutCoords(35, 15);

            IPoint p4 = new PointClass();
            p4.X = 40; p4.Y = 17;

            IPoint p5 = new PointClass();
            p5.X = 50; p5.Y = 19;

            IPoint p6 = new PointClass();
            p6.X = 60; p6.Y = 18;

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;

            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            //screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            screenDisp.StartDrawing(0, screenCache);
            IRgbColor color = new RgbColorClass();
            color.Red = 0; color.Blue = 255; color.Green = 0;

            ISimpleMarkerSymbol simpleMarkerSymbol = new SimpleMarkerSymbolClass();
            //any call to draw methods must be between
            //StartDrawing() and FinishDrawing() methods
            simpleMarkerSymbol.Color = color;
            screenDisp.SetSymbol(simpleMarkerSymbol as ISymbol);
            screenDisp.DrawPoint(p1);
            screenDisp.DrawPoint(p2);
            screenDisp.DrawPoint(p3);
            screenDisp.DrawPoint(p4);
            screenDisp.DrawPoint(p5);
            screenDisp.DrawPoint(p6);
            screenDisp.FinishDrawing();
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
