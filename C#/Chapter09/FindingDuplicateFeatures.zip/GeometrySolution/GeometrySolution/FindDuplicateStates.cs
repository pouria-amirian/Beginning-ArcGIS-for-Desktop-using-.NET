﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class FindDuplicateStates : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public FindDuplicateStates()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();
            IFeatureLayer2 statesFLayer = null;

            while (layer != null)
            {
                if (layer.Name == "U.S. States (Generalized)" && layer is IFeatureLayer2)
                {
                    statesFLayer = layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }

            if (statesFLayer == null)
            { return; }

            string message = null;

            IPolygon polygon1 = null;
            IPolygon polygon2 = null;

            IRelationalOperator2 relOperator;
            for (int i = 1; i < statesFLayer.FeatureClass.FeatureCount(null); i++)
            {
                polygon1 = statesFLayer.FeatureClass.GetFeature(i).Shape as IPolygon;
                for (int j = i + 1; j <= statesFLayer.FeatureClass.FeatureCount(null); j++)
                {
                    polygon2 = statesFLayer.FeatureClass.GetFeature(j).Shape as IPolygon;
                    relOperator = polygon1 as IRelationalOperator2;
                    // if polygon1 == polygon2
                    if (relOperator.Equals(polygon2) == true)
                    {
                        message += string.Format("{0} and {1},", i, j);
                    }
                }
            }

            if (message != null)
            {
                ArcMap.Application.StatusBar.Message[0] = "Duplicate Features: " + message;
            }
            else
            {
                ArcMap.Application.StatusBar.Message[0] = "There is no duplicate in U.S. States Layer";
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
