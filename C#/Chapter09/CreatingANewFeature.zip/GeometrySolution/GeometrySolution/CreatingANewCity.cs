﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geodatabase;

namespace GeometrySolution
{
    public class CreatingANewCity : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public CreatingANewCity()
        {
        }

        protected override void OnClick()
        {
            //finding cities layer
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;

            ILayer layer = enumLayer.Next();
            IFeatureLayer2 cityFLayer = null;

            while (layer != null)
            {
                if (layer.Name == "U.S. Cities" && layer is IFeatureLayer2)
                {
                    cityFLayer = layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }

            if (cityFLayer == null)
            { return; }

            try
            {
                IFeature newCity = cityFLayer.FeatureClass.CreateFeature();
                IPoint citypoint = new PointClass();
                citypoint.PutCoords(-118.802581987, 34.020762811);
                newCity.Shape = citypoint;

                int nameFieldIndex = cityFLayer.FeatureClass.Fields.FindField("CITY_NAME");
                int stateFieldIndex = cityFLayer.FeatureClass.Fields.FindField("STATE_NAME");
                int popFieldIndex = cityFLayer.FeatureClass.Fields.FindField("POP1990");
                newCity.Value[nameFieldIndex] = "Malibu";
                newCity.Value[stateFieldIndex] = "California";
                newCity.Value[popFieldIndex] = 12000;

                newCity.Store();
            }
            catch (Exception ex)
            {
                ArcMap.Application.StatusBar.Message[0] = ex.Message;
            }

        }

        protected override void OnUpdate()
        {
        }
    }
}
