﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class DrawingPolygonInteriorExteriorRings : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawingPolygonInteriorExteriorRings()
        {
        }

        protected override void OnClick()
        {
            //exterior Ring
            IPoint p1 = new PointClass();
            p1.X = 70; p1.Y = 70;

            IPoint p2 = new PointClass();
            p2.X = 110; p2.Y = 70;

            IPoint p3 = new PointClass();
            p3.X = 110; p3.Y = 20;

            IPoint p4 = new PointClass();
            p4.X = 70; p4.Y = 20;

            IPointCollection exRing = new RingClass();
            exRing.AddPoint(p1);
            exRing.AddPoint(p2);
            exRing.AddPoint(p3);
            exRing.AddPoint(p4);

            //interior Ring
            IPoint p5 = new PointClass();
            p5.X = 100; p5.Y = 55;

            IPoint p6 = new PointClass();
            p6.X = 80; p6.Y = 55;

            IPoint p7 = new PointClass();
            p7.X = 80; p7.Y = 40;

            IPoint p8 = new PointClass();
            p8.X = 100; p8.Y = 40;

            IPointCollection inRing = new RingClass();
            inRing.AddPoint(p5);
            inRing.AddPoint(p6);
            inRing.AddPoint(p7);
            inRing.AddPoint(p8);

            IGeometryCollection polygon = new PolygonClass();
            polygon.AddGeometry(exRing as IGeometry);
            polygon.AddGeometry(inRing as IGeometry);

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 255; color.Blue = 28; color.Green = 20;
            ISimpleFillSymbol simpleFillSymbol = new SimpleFillSymbolClass();
            simpleFillSymbol.Color = color;

            screenDisp.SetSymbol(simpleFillSymbol as ISymbol);
            screenDisp.DrawPolygon(polygon as IGeometry);

            screenDisp.FinishDrawing();
        }

        protected override void OnUpdate()
        {
        }
    }
}
