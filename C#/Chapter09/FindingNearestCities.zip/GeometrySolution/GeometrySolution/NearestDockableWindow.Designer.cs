﻿namespace GeometrySolution
{
    partial class NearestDockableWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPopulateListOfCitiesStates = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lstCities = new System.Windows.Forms.ListBox();
            this.lstStates = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCalculateDistance = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPopulateListOfCitiesStates
            // 
            this.btnPopulateListOfCitiesStates.Location = new System.Drawing.Point(6, 19);
            this.btnPopulateListOfCitiesStates.Name = "btnPopulateListOfCitiesStates";
            this.btnPopulateListOfCitiesStates.Size = new System.Drawing.Size(269, 33);
            this.btnPopulateListOfCitiesStates.TabIndex = 0;
            this.btnPopulateListOfCitiesStates.Text = "Populate List of Cities and States";
            this.btnPopulateListOfCitiesStates.UseVisualStyleBackColor = true;
            this.btnPopulateListOfCitiesStates.Click += new System.EventHandler(this.btnPopulateListOfCitiesStates_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Find Distance From:";
            // 
            // lstCities
            // 
            this.lstCities.FormattingEnabled = true;
            this.lstCities.ItemHeight = 16;
            this.lstCities.Location = new System.Drawing.Point(6, 97);
            this.lstCities.Name = "lstCities";
            this.lstCities.Size = new System.Drawing.Size(269, 148);
            this.lstCities.TabIndex = 2;
            // 
            // lstStates
            // 
            this.lstStates.FormattingEnabled = true;
            this.lstStates.ItemHeight = 16;
            this.lstStates.Location = new System.Drawing.Point(6, 284);
            this.lstStates.Name = "lstStates";
            this.lstStates.Size = new System.Drawing.Size(269, 148);
            this.lstStates.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "In:";
            // 
            // btnCalculateDistance
            // 
            this.btnCalculateDistance.Location = new System.Drawing.Point(6, 438);
            this.btnCalculateDistance.Name = "btnCalculateDistance";
            this.btnCalculateDistance.Size = new System.Drawing.Size(269, 41);
            this.btnCalculateDistance.TabIndex = 5;
            this.btnCalculateDistance.Text = "Calculate Distance";
            this.btnCalculateDistance.UseVisualStyleBackColor = true;
            this.btnCalculateDistance.Click += new System.EventHandler(this.btnCalculateDistance_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(6, 485);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(269, 150);
            this.dgv.TabIndex = 6;
            // 
            // NearestDockableWindow
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnCalculateDistance);
            this.Controls.Add(this.lstStates);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstCities);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPopulateListOfCitiesStates);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "NearestDockableWindow";
            this.Size = new System.Drawing.Size(300, 657);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPopulateListOfCitiesStates;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstCities;
        private System.Windows.Forms.ListBox lstStates;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCalculateDistance;
        private System.Windows.Forms.DataGridView dgv;

    }
}
