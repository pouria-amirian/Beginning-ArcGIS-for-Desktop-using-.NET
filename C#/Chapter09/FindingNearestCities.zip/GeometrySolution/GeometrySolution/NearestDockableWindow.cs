﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geodatabase;

namespace GeometrySolution
{
    /// <summary>
    /// Designer class of the dockable window add-in. It contains user interfaces that
    /// make up the dockable window.
    /// </summary>
    public partial class NearestDockableWindow : UserControl
    {
        public NearestDockableWindow(object hook)
        {
            InitializeComponent();
            this.Hook = hook;
        }

        /// <summary>
        /// Host object of the dockable window
        /// </summary>
        private object Hook
        {
            get;
            set;
        }

        /// <summary>
        /// Implementation class of the dockable window add-in. It is responsible for 
        /// creating and disposing the user interface class of the dockable window.
        /// </summary>
        public class AddinImpl : ESRI.ArcGIS.Desktop.AddIns.DockableWindow
        {
            private NearestDockableWindow m_windowUI;

            public AddinImpl()
            {
            }

            protected override IntPtr OnCreateChild()
            {
                m_windowUI = new NearestDockableWindow(this.Hook);
                return m_windowUI.Handle;
            }

            protected override void Dispose(bool disposing)
            {
                if (m_windowUI != null)
                    m_windowUI.Dispose(disposing);

                base.Dispose(disposing);
            }

        }
        public IFeatureLayer2 GetFeatureLayer(string layerName)
        {

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();
            while (layer != null)
            {
                if (layer.Name == layerName && layer is IFeatureLayer2)
                {
                    return layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }
            return null;
        }

        private void btnPopulateListOfCitiesStates_Click(object sender, EventArgs e)
        {
            lstCities.Items.Clear();
            lstStates.Items.Clear();
            lstCities.Sorted = true;
            lstStates.Sorted = true;

            IFeatureLayer2 statesFLayer = GetFeatureLayer("U.S. States (Generalized)");
            IFeatureLayer2 citiesFLayer = GetFeatureLayer("U.S. Cities");

            if (statesFLayer == null || citiesFLayer == null)
            { return; }

            IFeatureCursor featureCursor = statesFLayer.Search(null, true);
            IFeature feature = featureCursor.NextFeature();
            int statenameFieldIndex = statesFLayer.FeatureClass.Fields.FindField("STATE_NAME");
            while (feature != null)
            {
                lstStates.Items.Add(feature.Value[statenameFieldIndex]);
                feature = featureCursor.NextFeature();
            }

            featureCursor = citiesFLayer.Search(null, true);
            feature = featureCursor.NextFeature();
            int citynameFieldIndex = citiesFLayer.FeatureClass.Fields.FindField("CITY_NAME");
            while (feature != null)
            {
                lstCities.Items.Add(feature.Value[citynameFieldIndex]);
                feature = featureCursor.NextFeature();
            }
        }

        private void btnCalculateDistance_Click(object sender, EventArgs e)
        {
            List<NearCity> nearCities = new List<NearCity>();

            if (lstCities.SelectedIndex < 0 || lstStates.SelectedIndex < 0)
            { return; }

            string specifiedState = lstStates.SelectedItem.ToString();
            string specifiedCity = lstCities.SelectedItem.ToString();

            //select cities inside the specified state
            //select specified city and use its geometry as 
            //ProximityOperator to calculate all distances

            IQueryFilter qF = new QueryFilterClass();
            qF.WhereClause = string.Format("CITY_NAME='{0}'", specifiedCity);
            IFeatureClass citiesFC = GetFeatureLayer("U.S. Cities").FeatureClass;
            IFeatureSelection citiesFSelection = GetFeatureLayer("U.S. Cities") as IFeatureSelection;

            IFeatureCursor featureCursor = citiesFC.Search(qF, true);
            IFeature city = featureCursor.NextFeature();
            citiesFSelection.SelectFeatures(qF, esriSelectionResultEnum.esriSelectionResultNew, true);

            IProximityOperator proximityOp = city.Shape as IProximityOperator;

            qF.WhereClause = string.Format("STATE_NAME='{0}'", specifiedState);
            citiesFSelection.SelectFeatures(qF, esriSelectionResultEnum.esriSelectionResultAdd, false);

            featureCursor = citiesFC.Search(qF, true);
            IFeature candidateCity = featureCursor.NextFeature();

            int citynameFieldIndex = citiesFC.Fields.FindField("CITY_NAME");

            while (candidateCity != null)
            {
                NearCity aNearCity = new NearCity(candidateCity.Value[citynameFieldIndex].ToString());
                aNearCity.Distance = proximityOp.ReturnDistance(candidateCity.Shape as IGeometry4);
                nearCities.Add(aNearCity);
                candidateCity = featureCursor.NextFeature();
            }

            nearCities.Sort();
            dgv.DataSource = nearCities;
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            mxdoc.ActiveView.Extent = city.Shape.Envelope;
            mxdoc.ActiveView.Refresh();
        }
    }
}
