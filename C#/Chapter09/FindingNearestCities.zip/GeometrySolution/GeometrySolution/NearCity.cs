﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeometrySolution
{
    class NearCity:  IComparable<NearCity>
    {
        public string Name
        { get; set; }

        public double Distance
        { get; set; }

        public NearCity(string Name)
        {
             this.Name = Name;
        }

        public int CompareTo(NearCity other)
        {
            if (this.Distance > other.Distance)
            {
                return 1;
            }
            else if (this.Distance < other.Distance)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
