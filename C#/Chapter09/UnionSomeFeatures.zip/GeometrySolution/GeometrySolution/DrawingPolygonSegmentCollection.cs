﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class DrawingPolygonSegmentCollection : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawingPolygonSegmentCollection()
        {
        }

        protected override void OnClick()
        {
            Point p1 = new PointClass();
            p1.X = 10; p1.Y = 10;

            IPoint p2 = new PointClass();
            p2.X = 20; p2.Y = 20;

            ILine lineSegment1 = new LineClass();
            lineSegment1.FromPoint = p1;
            lineSegment1.ToPoint = p2;

            IPoint p3 = new PointClass();
            p3.X = 35; p3.Y = 15;

            IPoint p4 = new PointClass();
            p4.X = 40; p4.Y = 17;

            ICircularArc circularSegment = new CircularArcClass();
            circularSegment.PutCoords(p3, p2, p4, esriArcOrientation.esriArcClockwise);


            ISegmentCollection ringSegColl1 = new RingClass();
            ringSegColl1.AddSegment(lineSegment1 as ISegment);
            ringSegColl1.AddSegment(circularSegment as ISegment);

            IRing ring1 = ringSegColl1 as IRing;
            ring1.Close();

            IPoint p5 = new PointClass();
            p5.X = 50; p5.Y = 19;

            IPoint p6 = new PointClass();
            p6.X = 60; p6.Y = 18;

            IPoint p7 = new PointClass();
            p7.X = 70; p7.Y = 29;

            ILine lineSegment2 = new LineClass();
            lineSegment2.FromPoint = p5;
            lineSegment2.ToPoint = p6;

            ILine lineSegment3 = new LineClass();
            lineSegment3.FromPoint = p6;
            lineSegment3.ToPoint = p7;

            ISegmentCollection ringSegColl2 = new RingClass();
            ringSegColl2.AddSegment(lineSegment2 as ISegment);
            ringSegColl2.AddSegment(lineSegment3 as ISegment);

            IRing ring2 = ringSegColl2 as IRing;
            ring2.Close();

            IGeometryCollection polygon = new PolygonClass();
            polygon.AddGeometry(ring1 as IGeometry);
            polygon.AddGeometry(ring2 as IGeometry);

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 255; color.Blue = 28; color.Green = 20;

            ISimpleFillSymbol simpleFillSymbol = new SimpleFillSymbolClass();
            simpleFillSymbol.Color = color;
            screenDisp.SetSymbol(simpleFillSymbol as ISymbol);
            screenDisp.DrawPolygon(polygon as IGeometry);
            screenDisp.FinishDrawing();
        }

        protected override void OnUpdate()
        {
        }
    }
}
