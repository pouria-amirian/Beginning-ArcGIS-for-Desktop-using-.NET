﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class DrawingPolylines : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawingPolylines()
        {
        }

        protected override void OnClick()
        {
            //create a Line Segment
            Point p1 = new PointClass();
            p1.X = 10; p1.Y = 10;

            IPoint p2 = new PointClass();
            p2.X = 20; p2.Y = 20;

            ILine lineSegment = new LineClass();
            lineSegment.FromPoint = p1;
            lineSegment.ToPoint = p2;

            //create a CircularArc Segment
            IPoint p3 = new PointClass();
            p3.X = 35; p3.Y = 15;

            IPoint p4 = new PointClass();
            p4.X = 40; p4.Y = 17;

            ICircularArc circularSegment = new CircularArcClass();
            circularSegment.PutCoords(p3, p2, p4, esriArcOrientation.esriArcClockwise);
            
            //create a BezierCurve Segment
            IPoint p5 = new PointClass();
            p5.X = 50; p5.Y = 19;

            IPoint p6 = new PointClass();
            p6.X = 60; p6.Y = 18;

            IPoint p7 = new PointClass();
            p7.X = 70; p7.Y = 29;

            IPoint p8 = new PointClass();
            p8.X = 80; p8.Y = 38;

            IBezierCurve bezierSegment = new BezierCurveClass();
            IPoint[] controlPoints = { p5, p6, p7, p8 };
            IBezierCurveGEN bezierSegmenGen = bezierSegment as IBezierCurveGEN;
            bezierSegmenGen.PutCoords(ref controlPoints);

            //create a Polyline out of Segments
            ISegmentCollection path = new PathClass();
            path.AddSegment(lineSegment as ISegment);
            path.AddSegment(circularSegment as ISegment);
            path.AddSegment(bezierSegment as ISegment);

            IGeometryCollection polyline = new PolylineClass();
            polyline.AddGeometry(path as IGeometry);

            //draw the Polyline
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 255; color.Blue = 28; color.Green = 20;

            ISimpleLineSymbol simpleLineSymbol = new SimpleLineSymbolClass();
            simpleLineSymbol.Color = color;
            simpleLineSymbol.Width = 2;

            screenDisp.SetSymbol(simpleLineSymbol as ISymbol);
            screenDisp.DrawPolyline(polyline as IGeometry);

            screenDisp.FinishDrawing();
        }

        protected override void OnUpdate()
        {
        }
    }
}
