﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geodatabase;
namespace GeometrySolution
{
    public class UnionSomeFeatures : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public UnionSomeFeatures()
        {
        }

        protected override void OnClick()
        {
            IFeature california = GetState("California");
            IFeature arizona = GetState("Arizona");
            IFeature oregon = GetState("Oregon");

            if (california == null || arizona == null || oregon == null)
            { return; }

            ITopologicalOperator topoOperator = california.Shape as ITopologicalOperator;

            IPolygon5 unionPolygon = topoOperator.Union(arizona.Shape) as IPolygon5;
            IPolygon5 unionPolygon2 = (unionPolygon as ITopologicalOperator).Union(oregon.Shape) as IPolygon5;

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;

            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 214; color.Blue = 156; color.Green = 78;

            ISimpleFillSymbol simpleFillSymbol = new SimpleFillSymbolClass();
            simpleFillSymbol.Color = color;
            screenDisp.SetSymbol(simpleFillSymbol as ISymbol);

            screenDisp.DrawPolygon(unionPolygon2 as IGeometry);
            screenDisp.FinishDrawing();
        }

        protected override void OnUpdate()
        {
        }
        private IFeature GetState(string stateName)
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IMap map = activeView as IMap;
            IEnumLayer enumLayer = map.Layers;
            ILayer layer = enumLayer.Next();
            IFeatureLayer2 statesFLayer = null;

            while (layer != null)
            {
                if (layer.Name == "U.S. States (Generalized)" && layer is IFeatureLayer2)
                {
                    statesFLayer = layer as IFeatureLayer2;
                }
                layer = enumLayer.Next();
            }

            if (statesFLayer == null)
            { return null; }

            IQueryFilter qF = new QueryFilterClass();
            qF.WhereClause = string.Format("STATE_NAME='{0}'", stateName);
            IFeatureCursor featureCursor = statesFLayer.FeatureClass.Search(qF, true);
            IFeature state = featureCursor.NextFeature();

            return state;
        }
    }
}
