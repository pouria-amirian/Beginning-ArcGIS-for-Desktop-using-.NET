﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.ArcMapUI;

namespace GeometrySolution
{
    public class DrawingPolylineUsingPointColl : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DrawingPolylineUsingPointColl()
        {
        }

        protected override void OnClick()
        {
            //drawing a polyline
            Point p1 = new PointClass();
            p1.X = 10; p1.Y = 10;

            IPoint p2 = new PointClass();
            p2.X = 20; p2.Y = 20;

            IPoint p3 = new PointClass();
            p3.X = 35; p3.Y = 15;

            IPoint p4 = new PointClass();
            p4.X = 40; p4.Y = 17;

            IPoint p5 = new PointClass();
            p5.X = 50; p5.Y = 19;

            IPoint p6 = new PointClass();
            p6.X = 60; p6.Y = 18;

            IPolyline polyline = new PolylineClass();
            IPointCollection pointColl = polyline as IPointCollection;
            pointColl.AddPoint(p1);
            pointColl.AddPoint(p2);
            pointColl.AddPoint(p3);
            pointColl.AddPoint(p4);
            pointColl.AddPoint(p5);
            pointColl.AddPoint(p6);

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;
            IScreenDisplay screenDisp = activeView.ScreenDisplay;
            short screenCache = Convert.ToInt16(esriScreenCache.esriNoScreenCache);
            screenDisp.StartDrawing(screenDisp.hDC, screenCache);

            IRgbColor color = new RgbColorClass();
            color.Red = 255; color.Blue = 128; color.Green = 120;

            ISimpleLineSymbol simpleLineSymbol = new SimpleLineSymbolClass();
            simpleLineSymbol.Color = color;
            simpleLineSymbol.Width = 2;

            screenDisp.SetSymbol(simpleLineSymbol as ISymbol);
            screenDisp.DrawPolyline(polyline);

            screenDisp.FinishDrawing();
        }

        protected override void OnUpdate()
        {
        }
    }
}
