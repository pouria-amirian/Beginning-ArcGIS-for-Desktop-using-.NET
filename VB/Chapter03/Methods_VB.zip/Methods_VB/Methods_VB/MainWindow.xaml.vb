﻿Class MainWindow 
    

    Private Sub UsingAddMethod()

        Dim intAddition As Integer = AddTwoNumber(10, 100)

    End Sub
    Function AddTwoNumbers() As Integer

        Dim firstNum As Integer = 10
        Dim secondNum As Integer = 100
        'we have to use the return keyword
        Return firstNum + secondNum
    End Function
   
    Public Sub doSomething()

        'code goes here
        'no return keyword
    End Sub


    ''' <summary>
    ''' Adds two input numbers
    ''' </summary>
    ''' <param name="firstNum">first integer number for addition</param>
    ''' <param name="secondNum">second integer number for addition</param>
    ''' <returns>summation of the first and second input</returns>
    ''' <remarks></remarks>
    Private Function AddTwoNumber(ByVal firstNum As Integer, ByVal secondNum As Integer) As Integer

        Return firstNum + secondNum
    End Function


    Private Function AddTwoNumbers(ByVal a As Integer, ByVal b As Integer) As Integer

        Return a + b
    End Function

    Private Function AddTwoNumbers(ByVal a As Single, ByVal b As Single) As Double

        Return a + b
    End Function

    Private Function AddTwoNumbers(ByVal a As Short, ByVal b As Short) As Short

        Return a + b

    End Function



    Private Function Multiplication(ByVal a As Double, ByVal b As Double, Optional ByVal format As Boolean = False) As String


        If (format = True) Then

            Return String.Format("{0:f4}", a * b)

        Else

            Return String.Format("{0}", a * b)
        End If
    End Function


    Private Function FlexibleMultiplication(ByVal a As Double, ByVal b As Double, Optional ByVal formatNumber As Boolean = False, Optional ByVal useCurrencySign As Boolean = False) As String

        Dim result As String = ""

        If (formatNumber = True) Then

            If (useCurrencySign = True) Then

                result = "$" + String.Format("{0:f4}", a * b)

            Else

                result = String.Format("{0:f4}", a * b)

            End If
        Else

            If (useCurrencySign = True) Then

                result = "$" + Math.Round(a * b, 2)

            Else

                result = String.Format("{0}", a * b)

            End If
        End If
        Return result
    End Function

    Private Sub testMethodOverloading()

        'string testMultiplication = ""
        'testMultiplication = Multiplication(1388.0, 8.8)
        '//12214.4

        'testMultiplication = Multiplication(1388.0, 8.8, true)
        '//12214.4000
        Dim testMultiplication As String = ""
        testMultiplication = FlexibleMultiplication(28.1, 20.09)
        '564.529

        testMultiplication = FlexibleMultiplication(28.1, 20.09, True)
        '564.5290

        testMultiplication = FlexibleMultiplication(28.1, 20.09, False, True)
        '$564.53

        testMultiplication = FlexibleMultiplication(28.1, 20.09, True, True)
        '$546.5290

        testMultiplication = FlexibleMultiplication(b:=20.09, a:=28.1, useCurrencySign:=True)
    End Sub



End Class
