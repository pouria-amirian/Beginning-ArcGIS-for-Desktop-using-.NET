﻿Class MainWindow 

    Private Sub btnAddition_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnAddition.Click
        'since the inputs (entered by user) are string 
        'we have to convert them to double
        'get the first num
        Dim firstNum As Double = 0
        firstNum = Double.Parse(txtFirstNum.Text)
 
        'get the second num
        Dim secondNum As Double = 0
        secondNum = Double.Parse(txtSecondNum.Text)
        Label3.Content = firstNum.ToString() + " + " + secondNum.ToString() + " = " + (firstNum + secondNum).ToString()
    End Sub
End Class
