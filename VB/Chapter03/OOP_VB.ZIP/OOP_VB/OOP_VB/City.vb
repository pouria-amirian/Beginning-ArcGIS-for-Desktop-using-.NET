﻿Public Class City
    ' master constructor
    Public Sub New(ByVal name As String, ByVal country As String, ByVal area As Decimal, ByVal population As Long)

        Me.Name = name
        Me.Country = country
        Me.Area = area
        Me.Population = population

    End Sub
    Public Sub New(ByVal name As String, ByVal area As Decimal, ByVal population As Long)
        Me.New(name, "", area, population)
    End Sub


    'there is no need for any code here
    'notice how "me" keyword is used in chaining constructors
    Public Sub New(ByVal name As String, ByVal area As Decimal)
        Me.new(name, "", area, 0)
    End Sub

    'empty constructor
    Public Sub New()
    End Sub


    'first version
    'Private name As String
    'Public Property Name As String
    '    Get
    '        Name
    '    End Get
    '    Set(ByVal value As String)
    '        name = value
    '    End Set
    'End Property

    Public Property Name As String

    Public Property Country As String

    Public Property Area As Decimal

    Public Property Population As Long




    Public Function getPopulationDensity() As Decimal
        Return Me.Population / Me.Area
    End Function



    Sub test()
        Dim dublin As City=get
    End Sub

    Function getCityByName(ByVal name As String) As City
        Dim myCity As New City()
        myCity.Name = name
        Return myCity
    End Function



    Sub test()
        Dim dublin = getCityByName("Dublin")
    End Sub
  


End Class

Public Class ClientOfCity


    Sub testForInstatiation()
        Dim shiraz As City = New City()

        'Also we could instantiate an object in two steps
        Dim paris As City
        paris = New City()


        'releasing memory which was allocated to me object
        paris = Nothing


    End Sub

    Sub testForProerties()
        Dim hannover As City = New City()
        hannover.Name = "Hannover"
        hannover.Country = "Germany"

        Dim info As String = String.Format("Name:0, Country:1", hannover.Name, hannover.Country)

    End Sub

  
End Class




