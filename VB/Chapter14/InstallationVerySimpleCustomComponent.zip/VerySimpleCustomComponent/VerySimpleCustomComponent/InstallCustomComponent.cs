﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;

using System.Diagnostics;
using Microsoft.Win32;

namespace VerySimpleCustomComponent
{
    [RunInstaller(true)]
    public partial class InstallCustomComponent : System.Configuration.Install.Installer
    {
        public InstallCustomComponent()
        {
            InitializeComponent();
        }

        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
            //based on 64 or 32 bit it is different
            string processorArchitecture = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432");
            bool Is64bit = !string.IsNullOrEmpty(processorArchitecture);

            string EsriRegAsm = null;
            //find the folder containing ESRIRegAsm.exe
            string utilityInstallationPath = null;
            if (Is64bit)
            {
                RegistryKey regkey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\ESRI\ArcGIS");
                utilityInstallationPath = regkey.GetValue("InstallDir").ToString();
                regkey.Close();
            }
            else
            {
                RegistryKey regkey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ESRI\ArcGIS");
                utilityInstallationPath = regkey.GetValue("InstallDir").ToString();
                regkey.Close();
            }
            EsriRegAsm = utilityInstallationPath + @"bin\ESRIRegAsm.exe";

            //get from custom action
            string nameOfDll = "VerySimpleCustomComponent.dll";
            string installationFolder = this.Context.Parameters["installationDir"];
            string fullPathOfDll = installationFolder + nameOfDll;

            string switches = " /p:Desktop /s";
            string args = "\"" + fullPathOfDll + "\"" + switches;

            //execute using Process class
            int exitCode = ExecuteCommand(EsriRegAsm, args, 10000);
        }

        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);

            //based on 64 or 32 bit it is different
            string processorArchitecture = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432");
            bool Is64bit = !string.IsNullOrEmpty(processorArchitecture);

            string EsriRegAsm = null;
            //find the folder containing ESRIRegAsm.exe
            string utilityInstallationPath = null;
            if (Is64bit)
            {
                RegistryKey regkey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\ESRI\ArcGIS");
                utilityInstallationPath = regkey.GetValue("InstallDir").ToString();
                regkey.Close();
            }
            else
            {
                RegistryKey regkey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ESRI\ArcGIS");
                utilityInstallationPath = regkey.GetValue("InstallDir").ToString();
                regkey.Close();
            }
            EsriRegAsm = utilityInstallationPath + @"bin\ESRIRegAsm.exe";

            string installationFolder = this.Context.Parameters["installationDir"];
            string nameOfDll = "VerySimpleCustomComponent.dll";
            string fullPathOfDll = installationFolder + nameOfDll;
            string switches = " /p:Desktop /u /s";

            string args = "\"" + fullPathOfDll + "\"" + switches;

            //execute using Process class
            int exitCode = ExecuteCommand(EsriRegAsm, args, 10000);
        }
        
        public static int ExecuteCommand(string exe, string arguments, int
            Timeout)
        {
            ProcessStartInfo ProcessInfo = new ProcessStartInfo(exe, arguments);
            ProcessInfo.CreateNoWindow = true;
            ProcessInfo.UseShellExecute = false;
            ProcessInfo.ErrorDialog = true;
            //execute the Process
            Process Process = Process.Start(ProcessInfo);
            Process.WaitForExit(Timeout);

            int ExitCode = Process.ExitCode;
            Process.Close();
            return ExitCode;
        }


    }
}
