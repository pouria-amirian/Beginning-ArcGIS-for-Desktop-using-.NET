﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;
namespace ListenerComboBox
{
    public class cboFeatureLayer : ESRI.ArcGIS.Desktop.AddIns.ComboBox
    {
        //
        IMxDocument mxdoc;
        IMap map;

        //constructor of combobox
        public cboFeatureLayer()
        {
            mxdoc = ArcMap.Application.Document as IMxDocument;
            map = mxdoc.FocusMap;
            //get a reference to an object that implements specific event interface
            IActiveViewEvents_Event avEvent = map as IActiveViewEvents_Event;
            //register and insert event handlers with appropriate events
            avEvent.ItemAdded += new IActiveViewEvents_ItemAddedEventHandler(LayerAdded);
            avEvent.ItemDeleted += new IActiveViewEvents_ItemDeletedEventHandler(LayerAdded);
        }

        protected override void OnSelChange(int cookie)
        {
        }
        protected override void OnUpdate()
        {
        }

        //event handlers
        void LayerAdded(object item)
        {
            this.Clear();
            for (int i = 0; i < map.LayerCount; i++)
            {
                if (map.Layer[i] is IFeatureLayer)
                {
                    this.Add(map.Layer[i].Name);
                }
            }
        }

        //there is no need to this method
        //void LayerDeleted(object item)
        //{
        //    this.Clear();
        //    for (int i = 0; i < map.LayerCount; i++)
        //    {
        //        if (map.Layer[i] is IFeatureLayer)
        //        {
        //            this.Add(map.Layer[i].Name);
        //        }
        //    }
        //}

    }

}
