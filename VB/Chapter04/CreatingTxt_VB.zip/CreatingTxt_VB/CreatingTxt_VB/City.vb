﻿Public Class City
    Public Property Name As String
    Public Property Population As Long
    Public Property Area As Decimal
    Public Property X As Decimal
    Public Property Y As Decimal

    'Constructors
    'Master Constructor
    Public Sub New(ByVal name As String, ByVal population As Long, ByVal area As Decimal, ByVal x As Decimal, ByVal y As Decimal)
        Me.Name = name
        Me.Population = population
        Me.Area = area

        Me.X = x
        Me.Y = y
    End Sub

    Public Sub New(ByVal name As String, ByVal population As Long, ByVal x As Decimal, ByVal y As Decimal)
        Me.New(name, population, 0, x, y)
    End Sub

    Public Sub New(ByVal name As String, ByVal x As Decimal, ByVal y As Decimal)
        Me.New(name, 0, 0, x, y)
    End Sub

    Public Sub New()
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("{0}, {1}, {2}, {3}, {4}", Me.Name, Me.Population, Me.Area, Me.X, Me.Y)
    End Function

End Class
