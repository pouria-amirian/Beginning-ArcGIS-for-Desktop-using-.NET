﻿Class MainWindow 
    Dim firstNum, secondNum, result As Double
    Dim SelectedOperator As mathOperator

    Enum mathOperator As Integer
        Addition
        Subtraction
        Multiplication
        Division
    End Enum

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button9.Click, Button8.Click, Button7.Click, Button6.Click, Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button1.Click, Button11.Click
        Dim enteredNum As String = ""
        Dim clickedButton As Button = TryCast(sender, Button)
        enteredNum = clickedButton.Content.ToString()
        lblResult.Content += enteredNum
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button10.Click
        If (Not lblResult.Content.ToString().Contains(".")) Then

            lblResult.Content += "."
        End If
    End Sub
    Private Sub btnAddition_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnAddition.Click, btnSubtraction.Click, btnmultiplication.Click, btnDivision.Click
        'get the first number
        'firstNum = Double.Parse(lblResult.Content.ToString())
        'determine the operator
        If (String.IsNullOrEmpty(lblResult.Content)) Then
            firstNum = 0
        Else
            firstNum = Double.Parse(lblResult.Content.ToString())
        End If

        Dim strOperator As String = TryCast(sender, Button).Content.ToString()
        Select Case strOperator

            Case "+"
                SelectedOperator = mathOperator.Addition

            Case "-"
                SelectedOperator = mathOperator.Subtraction

            Case "*"
                SelectedOperator = mathOperator.Multiplication

            Case "/"
                SelectedOperator = mathOperator.Division

        End Select
        'clear the lblResult to make it ready for second number 
        lblResult.Content = ""
    End Sub


    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button12.Click
        secondNum = Double.Parse(lblResult.Content.ToString())
        Select SelectedOperator

            Case mathOperator.Addition
                result = firstNum + secondNum
                lblSummary.Content = String.Format("{0} + {1}", firstNum, secondNum)

            Case mathOperator.Subtraction
                result = firstNum - secondNum
                lblSummary.Content = String.Format("{0} - {1}", firstNum, secondNum)

            Case mathOperator.Multiplication
                result = firstNum * secondNum
                lblSummary.Content = String.Format("{0} * {1}", firstNum, secondNum)

            Case mathOperator.Division
                result = firstNum / secondNum
                lblSummary.Content = String.Format("{0} / {1}", firstNum, secondNum)

        End Select
        lblResult.Content = result
    End Sub




End Class
