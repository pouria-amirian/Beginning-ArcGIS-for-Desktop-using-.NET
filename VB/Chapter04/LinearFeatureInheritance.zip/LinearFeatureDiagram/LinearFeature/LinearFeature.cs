﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinearFeature
{
    class test
    {
        void testingInheritance()
        {
            Road r1 = new Road();
            r1.
        
        }

    }

    public class LinearFeature
    {
        public string Name
        { get; set; }

        public double Length
        { get; set; }

        public void Draw()
        {
            //implementation for General Drawing of linear features
        }
    }
    public class Road : LinearFeature
    {
    }

    public class River : LinearFeature
    {
        public override void Draw()
        {
            //implementation for Drawing of Rivers
        }
    }

    public class Railway : LinearFeature
    {
        public override void Draw()
        {
            //implementation for Drawing of Draw
        }

        public override string ToString()
        {
            return "Railway";
        }
    }


}
