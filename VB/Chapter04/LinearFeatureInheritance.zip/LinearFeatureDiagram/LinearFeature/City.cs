﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinearFeature
{
    class City
    {
        public string Name
        { get; set; }

        public long Population
        { get; set; }

        public double Area { get; set; }

        public double getPopulationDensity()
        { return this.Population / this.Area; }



        public City(string Name, long Population, double Area)
        {
            this.Name = Name;
            this.Population = Population;
            this.Area = Area;

        }
        public City(string Name, long Population) : this(Name, Population, 0) { }
        public City(string Name) : this(Name, 0) { }
        public City() { }


        public City Clone()
        {
            return new City(this.Name, this.Population, this.Area);
        }
    }
}
