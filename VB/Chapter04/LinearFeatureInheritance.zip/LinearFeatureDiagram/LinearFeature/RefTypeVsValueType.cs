﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinearFeature
{
    class RefTypeVsValueType
    {

        void testRefVsValue()
        {
            int i, j;
            i = 1388;

            j = i;
            //content of j is 1388
            //there are two integers in memory

            //create first instance
            City BigApple = new City("New York");

            //create second instance 
            City newYork = BigApple;
            //at this point there is one instance of City class
            //with two different names
            newYork.Name = "New York City";
            //this statement change the Name property of the instance
            //so if you check the BigApple.Name you will get "New York City"

        }

        void testClone()
        {
            //creating a first instance
            City BigApple = new City("New York");
            City NewYorkCity = BigApple.Clone();
            //at this point we have two instances with same properties
            //these two instances points to two different memory addresses

            NewYorkCity.Name = "Gotham";
            //the above code doesn't affect the BigApple.Name property 
        }

        void testComparisonAssignment()
        {
            int i, j;
            i = 138888;
            j = 138888;

            if (i == j)
            {
                //since the contents of those two integers are the same this is true 
            }

            City BigApple = new City("New York");
            City NewYork = new City("New York");

            if (BigApple == NewYork)
            {
                //this is false, there are two distinct instances            
            }

            City shiraz = new City("Shiraz");

            City cityOfRoses = shiraz.Clone();
            cityOfRoses.Name = "City of Flower and Nightingale";

            if (shiraz == cityOfRoses)
            {
                //this is true, there are two variable for one live object
            }

        }

        private void changeNumberByValue(int x)
        {
            x *= 100;
        }

        private void changeNumberByRef(ref int x)
        {
            x *= 100;
        }

        private void testByRefByValPassing()
        {
            int i = 10;

            changeNumberByValue(i);
            // i equals to 10 because only the content of i 
            //is passed into the called method

            changeNumberByRef(ref i);
            //i equals to 1000 because the reference to the memory location
            // is copied and passed into the called method
        }

        private int testOutKeyword(int number, out DateTime timeOfProcess)
        {
            timeOfProcess = DateTime.Now;
            return number * 100;
        }


        void testingOutKeyword()

        {
            int i = 1;
            DateTime t;
            i = testOutKeyword(i, out t);
            //at this point i is equal to 100
            //and t shows the time of execution
        
        }
    }

}
