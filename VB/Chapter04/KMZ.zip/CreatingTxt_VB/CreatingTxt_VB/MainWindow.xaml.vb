﻿Imports System.IO
Imports System.Text



Class MainWindow

    Private Sub btnWriteTextFile_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnWriteTextFile.Click
        Dim cities As New List(Of City)

        cities.Add(New City("New York", 16500000, 1210, -74.0999, 40.75))
        cities.Add(New City("Tokyo", 23650000, 2187, 139.8092, 35.683))
        cities.Add(New City("Berlin", 5100000, 892, 13.3276, 52.5163))
        cities.Add(New City("Paris", 10000000, 105, 2.4328, 48.8815))

        'writing text file
        Dim fileAddress As String = "C:\test.txt"
        Dim fs As FileStream = New FileStream(fileAddress, FileMode.Create)
        Dim sw As StreamWriter = New StreamWriter(fs)
        Try


            For Each ct As City In cities

                sw.WriteLine(ct.ToString())

            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message, ex.Source)

        Finally

            'cleanup
            sw.Close()
            fs.Close()
            Console.Beep()

        End Try


    End Sub

    Private Sub btnCreateKMLFile_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnCreateKMLFile.Click
        'Read the text file
        'and populate the list of City objects
        Dim fs As FileStream = New FileStream("c:\test.txt", FileMode.Open)
        Dim sr As StreamReader = New StreamReader(fs)

        Dim cities As List(Of City) = New List(Of City)
        Try

            Dim line As String = sr.ReadLine()
            While (line <> Nothing)

                Dim content() As String = line.Split(",").ToArray()

                Dim ct As City = New City()
                ct.Name = content(0)
                ct.Population = Long.Parse(content(1))
                ct.Area = Decimal.Parse(content(2))
                ct.X = Decimal.Parse(content(3))

                ct.Y = Decimal.Parse(content(4))
                cities.Add(ct)
                line = sr.ReadLine()
            End While

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Console.Beep()
        Finally

            sr.Close()
            fs.Close()
        End Try


        'create kml
        Dim sb As StringBuilder = New StringBuilder()

        'append the kml prologue
        sb.Append("<?xml version='1.0' encoding='UTF-8'?><kml xmlns='http://www.opengis.net/kml/2.2'><Document>")
        For Each ct As City In cities
            sb.Append(ct.WriteKMLFragment())
        Next

        'append the epilog of the kml file
        sb.Append("</Document></kml>")
        fs = New FileStream("c:\test.kml", FileMode.Create)
        Dim sw As StreamWriter = New StreamWriter(fs)
        Try

            sw.Write(sb.ToString())

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        Finally

            sw.Close()
            fs.Close()
        End Try
    End Sub

    Private Sub btnKMZ_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnKMZ.Click
        Dim zf As New Ionic.Zip.ZipFile()
        Try

            zf.AddFile("C:\test.kml")
            zf.Save("C:\test.kmz")
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        Finally
            zf.Dispose()
        End Try

    End Sub
End Class
