﻿Public Class City
    Public Property Name As String
    Public Property Population As Long
    Public Property Area As Decimal
    Public Property X As Decimal
    Public Property Y As Decimal

    'Constructors
    'Master Constructor
    Public Sub New(ByVal name As String, ByVal population As Long, ByVal area As Decimal, ByVal x As Decimal, ByVal y As Decimal)
        Me.Name = name
        Me.Population = population
        Me.Area = area

        Me.X = x
        Me.Y = y
    End Sub

    Public Sub New(ByVal name As String, ByVal population As Long, ByVal x As Decimal, ByVal y As Decimal)
        Me.New(name, population, 0, x, y)
    End Sub

    Public Sub New(ByVal name As String, ByVal x As Decimal, ByVal y As Decimal)
        Me.New(name, 0, 0, x, y)
    End Sub

    Public Sub New()
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("{0}, {1}, {2}, {3}, {4}", Me.Name, Me.Population, Me.Area, Me.X, Me.Y)
    End Function


    Private Function CreateKMLDescription() As String
        Dim description As String = ""
        description += String.Format("<i>Name: </i>{0}<br />", Me.Name)
        description += String.Format("<i>Population: </i>{0} <br/>", Me.Population)
        description += String.Format("<i>Area: </i>{0} Square Kilometre(", Me.Area)
        Return description
    End Function

    Public Function WriteKMLFragment() As String


        Dim kmlFragment As String = ""
        kmlFragment += String.Format("<Placemark id='{0}'>", Me.Name)


        kmlFragment += String.Format("<name>The City of {0}</name>", Me.Name)
        kmlFragment += String.Format("<description>{0}</description>", Me.CreateKMLDescription())
        kmlFragment += String.Format("<Point><coordinates>{0},{1})</coordinates></Point>", Me.X, Me.Y)
        kmlFragment += String.Format("</Placemark>")
        Return kmlFragment
 end function
End Class
