﻿
Public Class RefTypeVsValueType
    Sub testRefVsValue()

        Dim i, j As Integer
        i = 1388

        j = i
        'content of j is 1388
        'there are two integers in memory

        'create first instance
        Dim BigApple As New City("New York")


        'create second instance 
        Dim newYork As City = BigApple
        'at this point there is one instance of City class
        'with two different names

        newYork.Name = "New York City"
        'this statement change the Name property of the instance
        'so if you check the BigApple.Name you will get "New York City"

    End Sub

    Sub testClone()

        'creating a first instance
        Dim BigApple As New City("New York")
        Dim NewYorkCity As City = BigApple.Clone()
        'at this point we have two instances with same properties
        'these two instances points to two different memory addresses

        NewYorkCity.Name = "Gotham"
        'the above code doesn't affect the BigApple.Name property 
    End Sub


    Sub testComparisonAssignment()

        Dim i, j As Integer

        i = 138888
        j = 138888

        If (i = j) Then
            'since the contents of those two integers are the same this is true 
        End If

        Dim BigApple As New City("New York")
        Dim NewYork As New City("New York")

       

        If (BigApple Is NewYork) Then

            'this is false, there are two distinct instances            
        End If

        Dim shiraz As New City("Shiraz")

        Dim cityOfRoses As City = shiraz.Clone()
        cityOfRoses.Name = "City of Flower and Nightingale"

        If (shiraz Is cityOfRoses) Then

            'this is true, there are two variable for one live object
        End If

    End Sub

    Private Sub changeNumberByValue(ByVal x As Integer)

        x *= 100
    End Sub

    Private Sub changeNumberByRef(ByRef x As Integer)

        x *= 100
    End Sub

    Private Sub testByRefByValPassing()

        Dim i As Integer = 10

        changeNumberByValue(i)
        ' i equals to 10 because only the content of i 
        'is passed into the called method

        changeNumberByRef(i)
        'i equals to 1000 because the reference to the memory location
        ' is copied and passed into the called method
        End

        'There is no need for the Out keyword in VB.NET.
        ' Since Out in C# because C# doesn't let you use any variable without initializing it.

        'VB.net(doesn) 't need a special keyword as it automatically does it by itself.

    End Sub


   
End Class
