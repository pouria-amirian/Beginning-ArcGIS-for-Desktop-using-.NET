﻿
Public Class LinearFeature

    Public Property Length As Double
    Public Property Name As String
 

    Public Sub Draw()
        'implementation for Drawing of Draw
    End Sub

End Class

Public Class River
    Inherits LinearFeature

    Public Sub Draw()
        'implementation for Drawing of Draw
    End Sub

End Class


Public Class Road
    Inherits LinearFeature

End Class


Public Class Railway
    Inherits LinearFeature

    Public Sub Draw()
        'implementation for Drawing of Draw
    End Sub

    Public Function ToString() As String
        Return "Railway"
    End Function

End Class
