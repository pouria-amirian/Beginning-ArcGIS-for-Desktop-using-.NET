﻿Public Class City
    ' master constructor
    Public Sub New(ByVal name As String, ByVal country As String, ByVal area As Decimal, ByVal population As Long)

        Me.Name = name
        Me.Country = country
        Me.Area = area
        Me.Population = population

    End Sub
    Public Sub New(ByVal name As String, ByVal area As Decimal, ByVal population As Long)
        Me.New(name, "", area, population)
    End Sub


    'there is no need for any code here
    'notice how "me" keyword is used in chaining constructors
    Public Sub New(ByVal name As String, ByVal area As Decimal)
        Me.new(name, "", area, 0)
    End Sub
    Public Sub New(ByVal name As String)
        Me.new(name, "", 0, 0)
    End Sub
    'empty constructor
    Public Sub New()
    End Sub


    'first version
    'Private name As String
    'Public Property Name As String
    '    Get
    '        Name
    '    End Get
    '    Set(ByVal value As String)
    '        name = value
    '    End Set
    'End Property

    Public Property Name As String

    Public Property Country As String

    Public Property Area As Decimal

    Public Property Population As Long




    Public Function getPopulationDensity() As Decimal
        Return Me.Population / Me.Area
    End Function



    Public Function Clone()
        Return New City(Me.Name, Me.Population, Me.Area)
    End Function
   
  


End Class






