﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Display;

namespace CreatingOutputs
{
    public class AddNorthArrowTool : ESRI.ArcGIS.Desktop.AddIns.Tool
    {
        public AddNorthArrowTool()
        {
        }

        protected override void OnUpdate()
        {

        }
         

        protected override void OnMouseDown(MouseEventArgs arg)
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.PageLayout as IActiveView;
            IGraphicsContainer gc = mxdoc.PageLayout as IGraphicsContainer;

            IGraphicsContainer graphicsContainer = mxdoc.PageLayout as IGraphicsContainer;
            graphicsContainer.Reset();

            //only one North Arrow should be in a Layout
            IElement element = graphicsContainer.Next();
            while (element != null)
            {
                if (element is IMapSurroundFrame)
                {
                    IMapSurroundFrame MSF = element as IMapSurroundFrame;
                    if (MSF.MapSurround is INorthArrow)
                    {
                        gc.DeleteElement(element);
                    }
                }
                element = graphicsContainer.Next();
            }

            IPoint point = activeView.ScreenDisplay.DisplayTransformation.ToMapPoint(arg.X, arg.Y);
            IEnvelope envelope = new EnvelopeClass();

            envelope.XMin = point.X;
            envelope.YMin = point.Y;
            envelope.Width = 5;
            envelope.Height = 5;

            IStyleGallery styleGallery = mxdoc.StyleGallery;
            IEnumStyleGalleryItem enumStyleGallery = styleGallery.get_Items("North Arrows", "ESRI.STYLE", "Default");

            IStyleGalleryItem northArrowStyle = enumStyleGallery.Next();
            while (northArrowStyle != null)
            {
                if (northArrowStyle.Name == "ESRI North 3")
                {
                    break;
                }
                northArrowStyle = enumStyleGallery.Next();
            }

            INorthArrow northArrow = northArrowStyle.Item as INorthArrow;
            northArrow.Map = mxdoc.FocusMap;

            IMapSurroundFrame pMSFrame = new MapSurroundFrameClass();
            pMSFrame.MapSurround = northArrow;
            IElement MSElement = pMSFrame as IElement;
            MSElement.Geometry = envelope as IGeometry;

            gc.AddElement(MSElement, 0);
            mxdoc.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, null, null);
        }
    }

}
