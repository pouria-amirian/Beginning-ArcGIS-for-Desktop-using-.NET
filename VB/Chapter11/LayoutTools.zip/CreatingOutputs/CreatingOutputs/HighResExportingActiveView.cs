﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Output;
using ESRI.ArcGIS.Carto;

namespace CreatingOutputs
{
    public class HighResExportingActiveView : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public HighResExportingActiveView()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IActiveView activeView = mxdoc.ActiveView;

            IExport exporter = new ExportPNGClass();
            exporter.ExportFileName = @"c:\testHiRes.png";
            int screenRes = getScreenResolution();
            int outputRes = 300;
            exporter.Resolution = outputRes;
            double ratio = (double)outputRes / screenRes;

            IEnvelope pixelBBOX = new EnvelopeClass();
            pixelBBOX.XMin = activeView.ExportFrame.left * ratio;
            pixelBBOX.XMax = activeView.ExportFrame.right * ratio;
            pixelBBOX.YMin = activeView.ExportFrame.top * ratio;
            pixelBBOX.YMax = activeView.ExportFrame.bottom * ratio;
            exporter.PixelBounds = pixelBBOX;

            tagRECT exporterRectangle;
            exporterRectangle.left = activeView.ExportFrame.left * (int)ratio;
            exporterRectangle.bottom = activeView.ExportFrame.bottom * (int)ratio;
            exporterRectangle.top = activeView.ExportFrame.top * (int)ratio;
            exporterRectangle.right = activeView.ExportFrame.right * (int)ratio;

            int hdc = exporter.StartExporting();
            activeView.Output(hdc, outputRes, ref exporterRectangle, null, null);
            exporter.FinishExporting();
            exporter.Cleanup();
        }

        protected override void OnUpdate()
        {
        }

        private int getScreenResolution()
        {
            System.Windows.Forms.Form myForm = new System.Windows.Forms.Form();
            System.Drawing.Graphics myGraphic = myForm.CreateGraphics();
            return (int)myGraphic.DpiX;
        }
    }
}
