﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;

namespace CreatingOutputs
{
    public class DefaultLabelling : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public DefaultLabelling()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;

            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 statesFL = null;

            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. States (Generalized)")
                {
                    statesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (statesFL == null)
            { return; }
            IGeoFeatureLayer geoFeatureL = statesFL as IGeoFeatureLayer;
            IAnnotateLayerPropertiesCollection annotateLPC = geoFeatureL.AnnotationProperties;

            annotateLPC.Clear();
            geoFeatureL.DisplayAnnotation = true;

            IAnnotateLayerProperties annotateLP = new LabelEngineLayerPropertiesClass();
            IAnnotateLayerProperties annotateLP2 = new LabelEngineLayerPropertiesClass();
            
            annotateLP.WhereClause = "POP2000 > 4000000";

            annotateLP.Class = "LowerScale";
            annotateLP.AnnotationMaximumScale = 5000000;
            annotateLP.AnnotationMinimumScale = 20000000;

            annotateLP2.Class = "HigherScale";
            annotateLP2.AnnotationMaximumScale = 1000000;
            annotateLP2.AnnotationMinimumScale = 5000000;

            ILabelEngineLayerProperties2 labelELP1 = annotateLP as ILabelEngineLayerProperties2;
            ILabelEngineLayerProperties2 labelELP2 = annotateLP2 as ILabelEngineLayerProperties2;

            labelELP1.Expression = string.Format("\"State Name: \" +  UCase([STATE_NAME]) + vbNewline + \"State Abbreviation: \" + [STATE_ABBR] + vbNewline + \"Population :\" + FormatNumber([POP2000],0)");

            labelELP2.Expression = "\"State Name: \" +  [STATE_NAME]";

            annotateLPC.Add(annotateLP);
            annotateLPC.Add(annotateLP2);

            mxdoc.ActiveView.Refresh();
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
