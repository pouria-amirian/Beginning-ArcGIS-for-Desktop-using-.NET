﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Carto;

namespace CreatingOutputs
{
    public class AddGraphicTool : ESRI.ArcGIS.Desktop.AddIns.Tool
    {
        public AddGraphicTool()
        {
        }

        protected override void OnUpdate()
        {

        }

        protected override void OnMouseDown(ESRI.ArcGIS.Desktop.AddIns.Tool.MouseEventArgs arg)
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IGraphicsContainer gContiner = mxdoc.FocusMap as IGraphicsContainer;
            
            IDisplayTransformation dispTransformation = mxdoc.ActiveView.ScreenDisplay.DisplayTransformation;
            IPoint point = dispTransformation.ToMapPoint(arg.X, arg.Y);

            IRgbColor color = new RgbColorClass();
            color.Red = 255; color.Blue = 0; color.Green = 0;

            IRgbColor outlineColor = new RgbColorClass();
            outlineColor.Red = 0; outlineColor.Blue = 255; outlineColor.Green = 0;

            ISimpleMarkerSymbol simpleMarkerSymbol = new SimpleMarkerSymbolClass();
            simpleMarkerSymbol.Color = color;
            simpleMarkerSymbol.Outline = true;
            simpleMarkerSymbol.OutlineSize = 1.5;
            simpleMarkerSymbol.OutlineColor = outlineColor;
            simpleMarkerSymbol.Size = 7;

            if (arg.Button == System.Windows.Forms.MouseButtons.Left)
            {
                simpleMarkerSymbol.Style = esriSimpleMarkerStyle.esriSMSDiamond;
            }
            else if (arg.Button == System.Windows.Forms.MouseButtons.Right)
            {
                simpleMarkerSymbol.Style = esriSimpleMarkerStyle.esriSMSSquare;
            }

            IElement element = null;
            IMarkerElement markerElement = new MarkerElementClass();
            markerElement.Symbol = simpleMarkerSymbol;
            element = (IElement)markerElement;
            element.Geometry = point;

            gContiner.AddElement(element, 0);
            mxdoc.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, null, null);
        }
    }

}
