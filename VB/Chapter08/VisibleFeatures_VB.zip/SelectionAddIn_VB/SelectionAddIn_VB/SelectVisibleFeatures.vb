﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.ArcMapUI
Public Class SelectVisibleFeatures
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()

        Dim spatialFilter As ISpatialFilter = New SpatialFilter()
        spatialFilter.Geometry = TryCast(map, IActiveView).Extent
        spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelContains

        While layer IsNot Nothing
            If TypeOf layer Is IFeatureLayer2 Then
                If layer.Visible Then
                    Dim featureLayer As IFeatureLayer2 = TryCast(layer, IFeatureLayer2)
                    Dim featureSelection As IFeatureSelection = TryCast(featureLayer, IFeatureSelection)

                    featureSelection.SelectFeatures(spatialFilter, esriSelectionResultEnum.esriSelectionResultNew, False)
                End If
            End If
            layer = enumLayer.Next()
        End While
        mxdoc.ActiveView.Refresh()
    End Sub

    Protected Overrides Sub OnUpdate()
        Enabled = My.ArcMap.Application IsNot Nothing
    End Sub
End Class
