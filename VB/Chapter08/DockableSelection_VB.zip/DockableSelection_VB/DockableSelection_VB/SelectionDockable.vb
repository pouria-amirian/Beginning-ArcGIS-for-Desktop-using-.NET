Imports System.Runtime.InteropServices
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.SystemUI
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry



<ComClass(SelectionDockable.ClassId, SelectionDockable.InterfaceId, SelectionDockable.EventsId), _
 ProgId("DockableSelection_VB.SelectionDockable")> _
Public Class SelectionDockable
    Implements IDockableWindowDef

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "a938f84f-8e48-4131-963d-0981b18d9e66"
    Public Const InterfaceId As String = "0704dde7-7f4f-46f4-b629-12196ff093f0"
    Public Const EventsId As String = "85a8d091-c8f7-4bcb-a703-aed41aee461a"
#End Region

#Region "COM Registration Function(s)"
    <ComRegisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub RegisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryRegistration(registerType)

        'Add any COM registration code after the ArcGISCategoryRegistration() call

    End Sub

    <ComUnregisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub UnregisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryUnregistration(registerType)

        'Add any COM unregistration code after the ArcGISCategoryUnregistration() call

    End Sub

#Region "ArcGIS Component Category Registrar generated code"
    ''' <summary>
    ''' Required method for ArcGIS Component Category registration -
    ''' Do not modify the contents of this method with the code editor.
    ''' </summary>
    Private Shared Sub ArcGISCategoryRegistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxDockableWindows.Register(regKey)

    End Sub
    ''' <summary>
    ''' Required method for ArcGIS Component Category unregistration -
    ''' Do not modify the contents of this method with the code editor.
    ''' </summary>
    Private Shared Sub ArcGISCategoryUnregistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxDockableWindows.Unregister(regKey)

    End Sub

#End Region
#End Region

    Private m_application As IApplication

    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

#Region "IDockableWindowDef Members"

    Public ReadOnly Property Caption() As String Implements ESRI.ArcGIS.Framework.IDockableWindowDef.Caption
        Get
            'TODO: Replace with locale-based initial title bar caption
            Return "Selection Dockable Window"
        End Get
    End Property

    Public ReadOnly Property ChildHWND() As Integer Implements ESRI.ArcGIS.Framework.IDockableWindowDef.ChildHWND
        Get
            Return Me.Handle.ToInt32()
        End Get
    End Property

    Public ReadOnly Property Name1() As String Implements ESRI.ArcGIS.Framework.IDockableWindowDef.Name
        Get
            'TODO: Replace with any non-localizable string
            Return Me.Name
        End Get
    End Property

    Public Sub OnCreate(ByVal hook As Object) Implements ESRI.ArcGIS.Framework.IDockableWindowDef.OnCreate
        m_application = CType(hook, IApplication)
    End Sub

    Public Sub OnDestroy() Implements ESRI.ArcGIS.Framework.IDockableWindowDef.OnDestroy
        'TODO: Release resources and call dispose of any ActiveX control initialized
    End Sub

    Public ReadOnly Property UserData() As Object Implements ESRI.ArcGIS.Framework.IDockableWindowDef.UserData
        Get
            Return Nothing
        End Get
    End Property
#End Region


    Dim selectedState As String
    Dim citiesFL As IFeatureLayer2

    Dim statesLayer As IFeatureLayer2



    Private Sub btnPopulateList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateList.Click
        lstStates.Items.Clear()
        Dim mxdoc As IMxDocument = TryCast(m_application.Document, IMxDocument)
        Dim map As IMap = mxdoc.FocusMap

        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()

        While layer IsNot Nothing
            If TypeOf layer Is IFeatureLayer2 AndAlso layer.Name = "U.S. States (Generalized)" Then
                statesLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        If statesLayer Is Nothing Then
            Exit Sub
        End If

        Dim statesFCursor As IFeatureCursor = statesLayer.FeatureClass.Search(Nothing, True)
        Dim state_nameIndex As Integer = statesFCursor.Fields.FindField("STATE_NAME")
        Dim state As IFeature = statesFCursor.NextFeature()

        If state_nameIndex < 0 Then
            Exit Sub
        End If

        While state IsNot Nothing
            lstStates.Items.Add(state.Value(state_nameIndex))
            state = statesFCursor.NextFeature()
        End While

    End Sub

    Private Sub lstStates_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstStates.SelectedIndexChanged
        If lstStates.SelectedIndex >= 0 Then
            selectedState = lstStates.SelectedItem.ToString
        End If
    End Sub

    Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click
        Dim mxdoc As IMxDocument = TryCast(m_application.Document, IMxDocument)

        Dim stateFC As IFeatureClass = statesLayer.FeatureClass
        Dim qF As IQueryFilter2 = New QueryFilterClass()
        qF.WhereClause = String.Format("STATE_NAME='{0}'", selectedState)
        Dim stateFCursor As IFeatureCursor = stateFC.Search(qF, True)
        'just one state is selected
        Dim selectedStateFeature As IFeature = stateFCursor.NextFeature()
        Dim shapeOfSelectedState As IGeometry5 = TryCast(selectedStateFeature.Shape, IGeometry5)

        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()



        While layer IsNot Nothing
            If layer.Name = "U.S. Cities" AndAlso TypeOf layer Is IFeatureLayer2 Then
                citiesFL = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        If citiesFL Is Nothing Then
            Exit Sub
        End If
        Dim sF As ISpatialFilter = New SpatialFilterClass()
        sF.Geometry = shapeOfSelectedState
        sF.SpatialRel = esriSpatialRelEnum.esriSpatialRelContains

        Dim citiesFeatureSelection As IFeatureSelection = TryCast(citiesFL, IFeatureSelection)
        citiesFeatureSelection.SelectFeatures(sF, esriSelectionResultEnum.esriSelectionResultNew, False)


        Dim citiesCursor As ICursor = Nothing
        citiesFeatureSelection.SelectionSet.Search(Nothing, True, citiesCursor)
        Dim pop1990Index As Integer = citiesCursor.Fields.FindField("POP1990")
        Dim totalPopulation As Long = 0
        Dim city As IRow = citiesCursor.NextRow()
        While city IsNot Nothing

            totalPopulation += Long.Parse(city.Value(pop1990Index).ToString())

            city = citiesCursor.NextRow()
        End While


        'zoom to selected features
        mxdoc.ActiveView.Extent = shapeOfSelectedState.Envelope
        'IFeatureClass citiesFC = citiesFL.FeatureClass;
        mxdoc.ActiveView.Refresh()


        lblReport.Text = String.Format("Number of Selected Cities: {0} " & vbNewLine, citiesFeatureSelection.SelectionSet.Count)
        lblReport.Text += String.Format("Total Population: {0}", totalPopulation)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        selectedState = ""
        lstStates.ClearSelected()
        lblReport.Text = ""
        'todo: clear selected features in specified layer
        TryCast(citiesFL, IFeatureSelection).Clear()

        Dim mxdoc As IMxDocument = TryCast(m_application.Document, IMxDocument)
        If statesLayer IsNot Nothing Then
            mxdoc.ActiveView.Extent = TryCast(statesLayer, ILayer).AreaOfInterest
        End If
        mxdoc.ActiveView.Refresh()
    End Sub
End Class
