<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SelectionDockable
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.labelPlaceholder = New System.Windows.Forms.Label()
        Me.btnPopulateList = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.lstStates = New System.Windows.Forms.ListBox()
        Me.lblReport = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'labelPlaceholder
        '
        Me.labelPlaceholder.AutoSize = True
        Me.labelPlaceholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.labelPlaceholder.Location = New System.Drawing.Point(0, 0)
        Me.labelPlaceholder.Name = "labelPlaceholder"
        Me.labelPlaceholder.Size = New System.Drawing.Size(314, 13)
        Me.labelPlaceholder.TabIndex = 1
        Me.labelPlaceholder.Text = "Place controls on the canvas for your dockable window definition"
        Me.labelPlaceholder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnPopulateList
        '
        Me.btnPopulateList.Location = New System.Drawing.Point(15, 56)
        Me.btnPopulateList.Name = "btnPopulateList"
        Me.btnPopulateList.Size = New System.Drawing.Size(210, 23)
        Me.btnPopulateList.TabIndex = 2
        Me.btnPopulateList.Text = "Populate List of States"
        Me.btnPopulateList.UseVisualStyleBackColor = True
        '
        'btnSelect
        '
        Me.btnSelect.Location = New System.Drawing.Point(22, 309)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(203, 43)
        Me.btnSelect.TabIndex = 3
        Me.btnSelect.Text = "Select Cities in the Selected States"
        Me.btnSelect.UseVisualStyleBackColor = True
        '
        'lstStates
        '
        Me.lstStates.FormattingEnabled = True
        Me.lstStates.Location = New System.Drawing.Point(15, 85)
        Me.lstStates.Name = "lstStates"
        Me.lstStates.Size = New System.Drawing.Size(210, 199)
        Me.lstStates.TabIndex = 4
        '
        'lblReport
        '
        Me.lblReport.Location = New System.Drawing.Point(12, 387)
        Me.lblReport.Name = "lblReport"
        Me.lblReport.Size = New System.Drawing.Size(210, 100)
        Me.lblReport.TabIndex = 5
        Me.lblReport.Text = "Label1"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(51, 533)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(137, 23)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear Selection"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'SelectionDockable
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblReport)
        Me.Controls.Add(Me.lstStates)
        Me.Controls.Add(Me.btnSelect)
        Me.Controls.Add(Me.btnPopulateList)
        Me.Controls.Add(Me.labelPlaceholder)
        Me.Name = "SelectionDockable"
        Me.Size = New System.Drawing.Size(250, 570)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents labelPlaceholder As System.Windows.Forms.Label
    Friend WithEvents btnPopulateList As System.Windows.Forms.Button
    Friend WithEvents btnSelect As System.Windows.Forms.Button
    Friend WithEvents lstStates As System.Windows.Forms.ListBox
    Friend WithEvents lblReport As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
