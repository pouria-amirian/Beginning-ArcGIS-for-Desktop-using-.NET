Imports System.Runtime.InteropServices
Imports System.Drawing
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.esriSystem

<ComClass(SelectionDockableCommand.ClassId, SelectionDockableCommand.InterfaceId, SelectionDockableCommand.EventsId), _
 ProgId("DockableSelection_VB.SelectionDockableCommand")> _
Public NotInheritable Class SelectionDockableCommand
    Inherits BaseCommand

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "aa4816e6-dcde-4e26-9e57-e6c9e77be98f"
    Public Const InterfaceId As String = "2a06b3cc-33bf-48f9-a6be-4817aff13191"
    Public Const EventsId As String = "9aba4846-df0e-4307-899b-0f78a349e38a"
#End Region

#Region "COM Registration Function(s)"
    <ComRegisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub RegisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryRegistration(registerType)

        'Add any COM registration code after the ArcGISCategoryRegistration() call

    End Sub

    <ComUnregisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub UnregisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryUnregistration(registerType)

        'Add any COM unregistration code after the ArcGISCategoryUnregistration() call

    End Sub

#Region "ArcGIS Component Category Registrar generated code"
    Private Shared Sub ArcGISCategoryRegistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxCommands.Register(regKey)

    End Sub
    Private Shared Sub ArcGISCategoryUnregistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxCommands.Unregister(regKey)

    End Sub

#End Region
#End Region

    Private m_application As IApplication
    Private m_dockableWindow As IDockableWindow

    Private Const DockableWindowGuid As String = "{a938f84f-8e48-4131-963d-0981b18d9e66}"

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        ' TODO: Define values for the public properties
        MyBase.m_category = "ArcGISBook_VB"  'localizable text 
        MyBase.m_caption = "Show/Hide Selection Dockable Window"   'localizable text 
        MyBase.m_message = "Show/Hide Selection Dockable Window in the user interface of ArcMap"   'localizable text 
        MyBase.m_toolTip = "Show/Hide Selection Dockable Window" 'localizable text 
        MyBase.m_name = "ArcGISBook_VB_SelectionDockableCommand"  'unique id, non-localizable (e.g. "MyCategory_ArcMapCommand")

        Try
            'TODO: change bitmap name if necessary
            Dim bitmapResourceName As String = Me.GetType().Name + ".bmp"
            MyBase.m_bitmap = New Bitmap(Me.GetType(), bitmapResourceName)
        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap")
        End Try
    End Sub

    ''' <summary>
    ''' Occurs when this command is created
    ''' </summary>
    ''' <param name="hook">Instance of the application</param>
    Public Overrides Sub OnCreate(ByVal hook As Object)
        If Not hook Is Nothing Then
            m_application = CType(hook, IApplication)
        End If

        If m_application IsNot Nothing Then
            SetupDockableWindow()
            MyBase.m_enabled = m_dockableWindow IsNot Nothing
        Else
            MyBase.m_enabled = False
        End If
    End Sub

    ''' <summary>
    ''' Toggle visiblity of dockable window and show the visible state by its checked property
    ''' </summary>
    Public Overrides Sub OnClick()
        If m_dockableWindow Is Nothing Then Return

        If m_dockableWindow.IsVisible() Then
            m_dockableWindow.Show(False)
        Else
            m_dockableWindow.Show(True)
        End If

        MyBase.m_checked = m_dockableWindow.IsVisible()
    End Sub

    Public Overrides ReadOnly Property Checked() As Boolean
        Get
            Return (m_dockableWindow IsNot Nothing) AndAlso (m_dockableWindow.IsVisible())
        End Get
    End Property

    Private Sub SetupDockableWindow()
        If m_dockableWindow Is Nothing Then
            Dim dockWindowManager As IDockableWindowManager
            dockWindowManager = CType(m_application, IDockableWindowManager)
            If Not dockWindowManager Is Nothing Then
                Dim windowID As UID = New UIDClass
                windowID.Value = DockableWindowGuid
                m_dockableWindow = dockWindowManager.GetDockableWindow(windowID)
            End If
        End If
    End Sub
End Class



