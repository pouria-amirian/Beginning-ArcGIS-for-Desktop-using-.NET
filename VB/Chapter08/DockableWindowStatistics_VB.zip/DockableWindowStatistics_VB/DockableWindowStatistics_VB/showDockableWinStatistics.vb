﻿Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Framework

Public Class showDockableWinStatistics
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim dockableWinUID As UID = New UIDClass()

        dockableWinUID.Value = My.ThisAddIn.IDs.DockableWinStatistics
        Dim statsticsDockableWin As IDockableWindow = My.ArcMap.DockableWindowManager.GetDockableWindow(dockableWinUID)
        statsticsDockableWin.Show(True)
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
