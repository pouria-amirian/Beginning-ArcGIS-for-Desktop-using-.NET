﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.esriSystem

''' <summary>
''' Designer class of the dockable window add-in. It contains user interfaces that
''' make up the dockable window.
''' </summary>
Public Class DockableWinStatistics

  Public Sub New(ByVal hook As Object)

    ' This call is required by the Windows Form Designer.
    InitializeComponent()

    ' Add any initialization after the InitializeComponent() call.
    Me.Hook = hook
  End Sub


  Private m_hook As Object
  ''' <summary>
  ''' Host object of the dockable window
  ''' </summary> 
  Public Property Hook() As Object
    Get
      Return m_hook
    End Get
    Set(ByVal value As Object)
      m_hook = value
    End Set
  End Property

  ''' <summary>
  ''' Implementation class of the dockable window add-in. It is responsible for
  ''' creating and disposing the user interface class for the dockable window.
  ''' </summary>
  Public Class AddinImpl
    Inherits ESRI.ArcGIS.Desktop.AddIns.DockableWindow

    Private m_windowUI As DockableWinStatistics

    Protected Overrides Function OnCreateChild() As System.IntPtr
      m_windowUI = New DockableWinStatistics(Me.Hook)
      Return m_windowUI.Handle
    End Function

    Protected Overrides Sub Dispose(ByVal Param As Boolean)
      If m_windowUI IsNot Nothing Then
        m_windowUI.Dispose(Param)
      End If

      MyBase.Dispose(Param)
    End Sub

  End Class
    Dim mxdoc As IMxDocument = My.ArcMap.Document

    Private Sub btnPopulateLayerList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateLayerList.Click
        lstLayers.Items.Clear()
        cboNumFields.Tag = Nothing

        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()

        While layer IsNot Nothing
            If TypeOf layer Is IFeatureLayer2 Then
                lstLayers.Items.Add(layer.Name)
            End If
            layer = enumLayer.Next()
        End While
    End Sub

    Private Sub lstLayers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstLayers.SelectedIndexChanged
        cboNumFields.Items.Clear()
        Dim selectedLayerName As String = Nothing
        If lstLayers.SelectedIndex >= 0 Then
            selectedLayerName = lstLayers.SelectedItem.ToString()
        End If

        If selectedLayerName Is Nothing Then
            Exit Sub
        End If

        'getting all the numerical fields
        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()
        Dim featureLayer As IFeatureLayer2 = Nothing

        While layer IsNot Nothing
            If layer.Name = selectedLayerName Then
                featureLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        Dim FC As IFeatureClass = featureLayer.FeatureClass
        For i As Integer = 0 To FC.Fields.FieldCount - 1
            Dim field As IField = FC.Fields.Field(i)
            If field.Type = esriFieldType.esriFieldTypeDouble OrElse field.Type = esriFieldType.esriFieldTypeInteger OrElse field.Type = esriFieldType.esriFieldTypeSingle OrElse field.Type = esriFieldType.esriFieldTypeSmallInteger Then
                cboNumFields.Items.Add(field.Name)
            End If
            'to be able to reach to the parent FeatureLayer
            cboNumFields.Tag = TryCast(featureLayer, ILayer).Name
        Next
    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim selectedFieldName As String = Nothing
        If cboNumFields.SelectedIndex >= 0 Then
            selectedFieldName = cboNumFields.SelectedItem.ToString()
        End If

        If selectedFieldName Is Nothing Then
            Exit Sub
        End If

        If cboNumFields.Tag Is Nothing Then
            lblReport.Text = ""
            Exit Sub
        End If

        Dim featureLayerName As String = cboNumFields.Tag.ToString()

        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()
        Dim featureLayer As IFeatureLayer2 = Nothing

        While layer IsNot Nothing
            If layer.Name = featureLayerName Then
                featureLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        If featureLayer Is Nothing Then
            Return
        End If

        Dim FC As IFeatureClass = featureLayer.FeatureClass
        Dim featureCursor As IFeatureCursor = FC.Search(Nothing, True)


        Dim dataStatistics As IDataStatistics = New DataStatisticsClass()
        dataStatistics.Field = selectedFieldName
        dataStatistics.Cursor = TryCast(featureCursor, ICursor)

        Dim sR As IStatisticsResults = dataStatistics.Statistics

        lblReport.Text = String.Format("Count: {0}" & vbNewLine, sR.Count)
        lblReport.Text += String.Format("Min: {0:#.00}" & vbNewLine, sR.Minimum)
        lblReport.Text += String.Format("Max: {0:#.00}" & vbNewLine, sR.Maximum)
        lblReport.Text += String.Format("Sum: {0:#.00}" & vbNewLine, sR.Sum)
        lblReport.Text += String.Format("Average: {0:#.00}" & vbNewLine, sR.Mean)
        lblReport.Text += String.Format("Standard Deviation: {0:#.00}" & vbNewLine, sR.StandardDeviation)
    End Sub
End Class