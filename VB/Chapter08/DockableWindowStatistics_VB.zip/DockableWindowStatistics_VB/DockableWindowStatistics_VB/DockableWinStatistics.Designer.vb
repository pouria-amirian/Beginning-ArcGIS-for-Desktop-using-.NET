﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DockableWinStatistics
  Inherits System.Windows.Forms.UserControl

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing AndAlso components IsNot Nothing Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.cboNumFields = New System.Windows.Forms.ComboBox()
        Me.lstLayers = New System.Windows.Forms.ListBox()
        Me.lblReport = New System.Windows.Forms.Label()
        Me.btnPopulateLayerList = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(14, 312)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(214, 27)
        Me.btnCalculate.TabIndex = 9
        Me.btnCalculate.Text = "Calculate Statistics"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'cboNumFields
        '
        Me.cboNumFields.FormattingEnabled = True
        Me.cboNumFields.Location = New System.Drawing.Point(17, 274)
        Me.cboNumFields.Name = "cboNumFields"
        Me.cboNumFields.Size = New System.Drawing.Size(213, 21)
        Me.cboNumFields.TabIndex = 8
        '
        'lstLayers
        '
        Me.lstLayers.FormattingEnabled = True
        Me.lstLayers.Location = New System.Drawing.Point(17, 72)
        Me.lstLayers.Name = "lstLayers"
        Me.lstLayers.Size = New System.Drawing.Size(213, 160)
        Me.lstLayers.TabIndex = 7
        '
        'lblReport
        '
        Me.lblReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblReport.Location = New System.Drawing.Point(14, 351)
        Me.lblReport.Name = "lblReport"
        Me.lblReport.Size = New System.Drawing.Size(216, 154)
        Me.lblReport.TabIndex = 6
        '
        'btnPopulateLayerList
        '
        Me.btnPopulateLayerList.Location = New System.Drawing.Point(16, 27)
        Me.btnPopulateLayerList.Name = "btnPopulateLayerList"
        Me.btnPopulateLayerList.Size = New System.Drawing.Size(214, 27)
        Me.btnPopulateLayerList.TabIndex = 5
        Me.btnPopulateLayerList.Text = "List of Layers"
        Me.btnPopulateLayerList.UseVisualStyleBackColor = True
        '
        'DockableWinStatistics
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.cboNumFields)
        Me.Controls.Add(Me.lstLayers)
        Me.Controls.Add(Me.lblReport)
        Me.Controls.Add(Me.btnPopulateLayerList)
        Me.Name = "DockableWinStatistics"
        Me.Size = New System.Drawing.Size(255, 620)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents btnCalculate As System.Windows.Forms.Button
    Private WithEvents cboNumFields As System.Windows.Forms.ComboBox
    Private WithEvents lstLayers As System.Windows.Forms.ListBox
    Private WithEvents lblReport As System.Windows.Forms.Label
    Private WithEvents btnPopulateLayerList As System.Windows.Forms.Button

End Class
