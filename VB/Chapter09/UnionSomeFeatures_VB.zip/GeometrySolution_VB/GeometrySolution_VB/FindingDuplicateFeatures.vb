﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Geodatabase

Public Class FindingDuplicateFeatures
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()
        Dim statesFLayer As IFeatureLayer2 = Nothing

        While layer IsNot Nothing
            If layer.Name = "U.S. States (Generalized)" AndAlso TypeOf layer Is IFeatureLayer2 Then
                statesFLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        If statesFLayer Is Nothing Then
            Exit Sub
        End If

        Dim message As String = Nothing

        Dim polygon1 As IPolygon4 = Nothing
        Dim polygon2 As IPolygon4 = Nothing


        Dim relOperator As IRelationalOperator2
        For i As Integer = 1 To statesFLayer.FeatureClass.FeatureCount(Nothing) - 1

            polygon1 = TryCast(statesFLayer.FeatureClass.GetFeature(i).Shape, IPolygon4)


            For j As Integer = i + 1 To statesFLayer.FeatureClass.FeatureCount(Nothing)

                polygon2 = TryCast(statesFLayer.FeatureClass.GetFeature(j).Shape, IPolygon4)

                relOperator = TryCast(polygon1, IRelationalOperator2)

                ' if polygon1 = polygon2
                If relOperator.Equals(polygon2) = True Then
                    message += String.Format("{0} and {1},", i, j)
                End If
            Next
        Next

        If message IsNot Nothing Then
            My.ArcMap.Application.StatusBar.Message(0) = "Duplicate Features: " & message
        Else
            My.ArcMap.Application.StatusBar.Message(0) = "There is no duplicate in U.S. States Layer"
        End If
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
