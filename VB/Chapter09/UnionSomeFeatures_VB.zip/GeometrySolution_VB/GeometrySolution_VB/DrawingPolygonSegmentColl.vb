﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI

Public Class DrawingPolygonSegmentColl
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim p1 As Point = New PointClass()
        p1.X = 10
        p1.Y = 10

        Dim p2 As IPoint = New PointClass()
        p2.X = 20
        p2.Y = 20

        Dim lineSegment1 As ILine = New LineClass()
        lineSegment1.FromPoint = p1
        lineSegment1.ToPoint = p2

        Dim p3 As IPoint = New PointClass()
        p3.X = 35
        p3.Y = 15

        Dim p4 As IPoint = New PointClass()
        p4.X = 40
        p4.Y = 17

        Dim circularSegment As ICircularArc = New CircularArcClass()
        circularSegment.PutCoords(p3, p2, p4, esriArcOrientation.esriArcClockwise)


        Dim ringSegColl1 As ISegmentCollection = New RingClass()
        ringSegColl1.AddSegment(TryCast(lineSegment1, ISegment))
        ringSegColl1.AddSegment(TryCast(circularSegment, ISegment))

        Dim ring1 As IRing = TryCast(ringSegColl1, IRing)
        ring1.Close()

        Dim p5 As IPoint = New PointClass()
        p5.X = 50
        p5.Y = 19

        Dim p6 As IPoint = New PointClass()
        p6.X = 60
        p6.Y = 18

        Dim p7 As IPoint = New PointClass()
        p7.X = 70
        p7.Y = 29

        Dim lineSegment2 As ILine = New LineClass()
        lineSegment2.FromPoint = p5
        lineSegment2.ToPoint = p6

        Dim lineSegment3 As ILine = New LineClass()
        lineSegment3.FromPoint = p6
        lineSegment3.ToPoint = p7

        Dim ringSegColl2 As ISegmentCollection = New RingClass()
        ringSegColl2.AddSegment(TryCast(lineSegment2, ISegment))
        ringSegColl2.AddSegment(TryCast(lineSegment3, ISegment))

        Dim ring2 As IRing = TryCast(ringSegColl2, IRing)
        ring2.Close()

        Dim polygon As IGeometryCollection = New PolygonClass()
        polygon.AddGeometry(TryCast(ring1, IGeometry))
        polygon.AddGeometry(TryCast(ring2, IGeometry))

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 255
        color.Blue = 28
        color.Green = 20

        Dim simpleFillSymbol As ISimpleFillSymbol = New SimpleFillSymbolClass()
        simpleFillSymbol.Color = color
        screenDisp.SetSymbol(TryCast(simpleFillSymbol, ISymbol))
        screenDisp.DrawPolygon(TryCast(polygon, IGeometry))
        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
