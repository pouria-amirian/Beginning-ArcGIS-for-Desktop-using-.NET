﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI

Public Class drawingPolygonInteriorExteriorRings
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        'exterior Ring
        Dim p1 As IPoint = New PointClass()
        p1.X = 70
        p1.Y = 70

        Dim p2 As IPoint = New PointClass()
        p2.X = 110
        p2.Y = 70

        Dim p3 As IPoint = New PointClass()
        p3.X = 110
        p3.Y = 20

        Dim p4 As IPoint = New PointClass()
        p4.X = 70
        p4.Y = 20

        Dim exRing As IPointCollection = New RingClass()
        exRing.AddPoint(p1)
        exRing.AddPoint(p2)
        exRing.AddPoint(p3)
        exRing.AddPoint(p4)

        'interior Ring
        Dim p5 As IPoint = New PointClass()
        p5.X = 100
        p5.Y = 55

        Dim p6 As IPoint = New PointClass()
        p6.X = 80
        p6.Y = 55

        Dim p7 As IPoint = New PointClass()
        p7.X = 80
        p7.Y = 40

        Dim p8 As IPoint = New PointClass()
        p8.X = 100
        p8.Y = 40

        Dim inRing As IPointCollection = New RingClass()
        inRing.AddPoint(p5)
        inRing.AddPoint(p6)
        inRing.AddPoint(p7)
        inRing.AddPoint(p8)

        Dim polygon As IGeometryCollection = New PolygonClass()
        polygon.AddGeometry(TryCast(exRing, IGeometry))
        polygon.AddGeometry(TryCast(inRing, IGeometry))

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 255
        color.Blue = 28
        color.Green = 20
        Dim simpleFillSymbol As ISimpleFillSymbol = New SimpleFillSymbolClass()
        simpleFillSymbol.Color = color

        screenDisp.SetSymbol(TryCast(simpleFillSymbol, ISymbol))
        screenDisp.DrawPolygon(TryCast(polygon, IGeometry))

        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
