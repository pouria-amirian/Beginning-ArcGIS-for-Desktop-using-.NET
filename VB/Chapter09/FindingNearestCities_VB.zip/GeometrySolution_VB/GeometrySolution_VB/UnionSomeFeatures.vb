﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Geodatabase

Public Class UnionSomeFeatures
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim california As IFeature = GetState("California")
        Dim arizona As IFeature = GetState("Arizona")
        Dim oregon As IFeature = GetState("Oregon")

        If california Is Nothing OrElse arizona Is Nothing OrElse oregon Is Nothing Then
            Return
        End If

        Dim topoOperator As ITopologicalOperator = TryCast(california.Shape, ITopologicalOperator)

        Dim unionPolygon As IPolygon5 = TryCast(topoOperator.Union(arizona.Shape), IPolygon5)
        Dim unionPolygon2 As IPolygon5 = TryCast(TryCast(unionPolygon, ITopologicalOperator).Union(oregon.Shape), IPolygon5)

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView

        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 214
        color.Blue = 156
        color.Green = 78

        Dim simpleFillSymbol As ISimpleFillSymbol = New SimpleFillSymbolClass()
        simpleFillSymbol.Color = color
        screenDisp.SetSymbol(TryCast(simpleFillSymbol, ISymbol))

        screenDisp.DrawPolygon(TryCast(unionPolygon2, IGeometry))
        screenDisp.FinishDrawing()
    End Sub
    Private Function GetState(ByVal stateName As String) As IFeature
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim map As IMap = TryCast(activeView, IMap)
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()
        Dim statesFLayer As IFeatureLayer2 = Nothing

        While layer IsNot Nothing
            If layer.Name = "U.S. States (Generalized)" AndAlso TypeOf layer Is IFeatureLayer2 Then
                statesFLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.[Next]()
        End While

        If statesFLayer Is Nothing Then
            Return Nothing
        End If

        Dim qF As IQueryFilter = New QueryFilterClass()
        qF.WhereClause = String.Format("STATE_NAME='{0}'", stateName)
        Dim featureCursor As IFeatureCursor = statesFLayer.FeatureClass.Search(qF, True)
        Dim state As IFeature = featureCursor.NextFeature()

        Return state
    End Function
    Protected Overrides Sub OnUpdate()

    End Sub
End Class
