﻿Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Framework

Public Class NearestToggle
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()

    End Sub

    Protected Overrides Sub OnUpdate()
        Dim dockableWinUID As UID = New UIDClass()
        dockableWinUID.Value = My.ThisAddIn.IDs.NearestDockableWindow
        Dim nearestDockableWin As IDockableWindow = My.ArcMap.DockableWindowManager.GetDockableWindow(dockableWinUID)
        nearestDockableWin.Show(True)
    End Sub
End Class
