﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI

Public Class DrawingPolylines
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        'create a Line Segment
        Dim p1 As Point = New PointClass()
        p1.X = 10
        p1.Y = 10

        Dim p2 As IPoint = New PointClass()
        p2.X = 20
        p2.Y = 20

        Dim lineSegment As ILine = New LineClass()
        lineSegment.FromPoint = p1
        lineSegment.ToPoint = p2

        'create a CircularArc Segment
        Dim p3 As IPoint = New PointClass()
        p3.X = 35
        p3.Y = 15

        Dim p4 As IPoint = New PointClass()
        p4.X = 40
        p4.Y = 17

        Dim circularSegment As ICircularArc = New CircularArcClass()
        circularSegment.PutCoords(p3, p2, p4, esriArcOrientation.esriArcClockwise)

        'create a BezierCurve Segment
        Dim p5 As IPoint = New PointClass()
        p5.X = 50
        p5.Y = 19

        Dim p6 As IPoint = New PointClass()
        p6.X = 60
        p6.Y = 18

        Dim p7 As IPoint = New PointClass()
        p7.X = 70
        p7.Y = 29

        Dim p8 As IPoint = New PointClass()
        p8.X = 80
        p8.Y = 38

        Dim bezierSegment As IBezierCurve = New BezierCurveClass()
        Dim controlPoints As IPoint() = {p5, p6, p7, p8}
        Dim bezierSegmenGen As IBezierCurveGEN = TryCast(bezierSegment, IBezierCurveGEN)
        bezierSegmenGen.PutCoords(controlPoints)

        'create a Polyline out of Segments
        Dim path As ISegmentCollection = New PathClass()
        path.AddSegment(TryCast(lineSegment, ISegment))
        path.AddSegment(TryCast(circularSegment, ISegment))
        path.AddSegment(TryCast(bezierSegment, ISegment))

        Dim polyline As IGeometryCollection = New PolylineClass()
        polyline.AddGeometry(TryCast(path, IGeometry))

        'draw the Polyline
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 255
        color.Blue = 28
        color.Green = 20

        Dim simpleLineSymbol As ISimpleLineSymbol = New SimpleLineSymbolClass()
        simpleLineSymbol.Color = color
        simpleLineSymbol.Width = 2

        screenDisp.SetSymbol(TryCast(simpleLineSymbol, ISymbol))
        screenDisp.DrawPolyline(TryCast(polyline, IGeometry))

        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
