﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Geodatabase

''' <summary>
''' Designer class of the dockable window add-in. It contains user interfaces that
''' make up the dockable window.
''' </summary>
Public Class NearestDockableWindow

  Public Sub New(ByVal hook As Object)

    ' This call is required by the Windows Form Designer.
    InitializeComponent()

    ' Add any initialization after the InitializeComponent() call.
    Me.Hook = hook
  End Sub


  Private m_hook As Object
  ''' <summary>
  ''' Host object of the dockable window
  ''' </summary> 
  Public Property Hook() As Object
    Get
      Return m_hook
    End Get
    Set(ByVal value As Object)
      m_hook = value
    End Set
  End Property

  ''' <summary>
  ''' Implementation class of the dockable window add-in. It is responsible for
  ''' creating and disposing the user interface class for the dockable window.
  ''' </summary>
  Public Class AddinImpl
    Inherits ESRI.ArcGIS.Desktop.AddIns.DockableWindow

    Private m_windowUI As NearestDockableWindow

    Protected Overrides Function OnCreateChild() As System.IntPtr
      m_windowUI = New NearestDockableWindow(Me.Hook)
      Return m_windowUI.Handle
    End Function

    Protected Overrides Sub Dispose(ByVal Param As Boolean)
      If m_windowUI IsNot Nothing Then
        m_windowUI.Dispose(Param)
      End If

      MyBase.Dispose(Param)
    End Sub

  End Class
    Public Function GetFeatureLayer(ByVal layerName As String) As IFeatureLayer2

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers
        Dim layer As ILayer = enumLayer.Next()
        While layer IsNot Nothing
            If layer.Name = layerName AndAlso TypeOf layer Is IFeatureLayer2 Then
                Return TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While
        Return Nothing
    End Function
    Private Sub btnPopulateListOfCitiesStates_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateListOfCitiesStates.Click
        lstCities.Items.Clear()
        lstStates.Items.Clear()
        lstCities.Sorted = True
        lstStates.Sorted = True

        Dim statesFLayer As IFeatureLayer2 = GetFeatureLayer("U.S. States (Generalized)")
        Dim citiesFLayer As IFeatureLayer2 = GetFeatureLayer("U.S. Cities")

        If statesFLayer Is Nothing OrElse citiesFLayer Is Nothing Then
            Return
        End If

        Dim featureCursor As IFeatureCursor = statesFLayer.Search(Nothing, True)
        Dim feature As IFeature = featureCursor.NextFeature()
        Dim statenameFieldIndex As Integer = statesFLayer.FeatureClass.Fields.FindField("STATE_NAME")
        While feature IsNot Nothing
            lstStates.Items.Add(feature.Value(statenameFieldIndex))
            feature = featureCursor.NextFeature()
        End While

        featureCursor = citiesFLayer.Search(Nothing, True)
        feature = featureCursor.NextFeature()
        Dim citynameFieldIndex As Integer = citiesFLayer.FeatureClass.Fields.FindField("CITY_NAME")
        While feature IsNot Nothing
            lstCities.Items.Add(feature.Value(citynameFieldIndex))
            feature = featureCursor.NextFeature()
        End While
    End Sub

    Private Sub btnCalculateDistance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculateDistance.Click
        Dim nearCities As New List(Of NearCity)()

        If lstCities.SelectedIndex < 0 OrElse lstStates.SelectedIndex < 0 Then
            Return
        End If

        Dim specifiedState As String = lstStates.SelectedItem.ToString()
        Dim specifiedCity As String = lstCities.SelectedItem.ToString()

        'select cities inside the specified state
        'select specified city and use its geometry as 
        'ProximityOperator to calculate all distances

        Dim qF As IQueryFilter = New QueryFilterClass()
        qF.WhereClause = String.Format("CITY_NAME='{0}'", specifiedCity)
        Dim citiesFC As IFeatureClass = GetFeatureLayer("U.S. Cities").FeatureClass
        Dim citiesFSelection As IFeatureSelection = TryCast(GetFeatureLayer("U.S. Cities"), IFeatureSelection)

        Dim featureCursor As IFeatureCursor = citiesFC.Search(qF, True)
        Dim city As IFeature = featureCursor.NextFeature()
        citiesFSelection.SelectFeatures(qF, esriSelectionResultEnum.esriSelectionResultNew, True)

        Dim proximityOp As IProximityOperator = TryCast(city.Shape, IProximityOperator)

        qF.WhereClause = String.Format("STATE_NAME='{0}'", specifiedState)
        citiesFSelection.SelectFeatures(qF, esriSelectionResultEnum.esriSelectionResultAdd, False)

        featureCursor = citiesFC.Search(qF, True)
        Dim candidateCity As IFeature = featureCursor.NextFeature()

        Dim citynameFieldIndex As Integer = citiesFC.Fields.FindField("CITY_NAME")

        While candidateCity IsNot Nothing
            Dim aNearCity As New NearCity(candidateCity.Value(citynameFieldIndex).ToString())
            aNearCity.Distance = proximityOp.ReturnDistance(TryCast(candidateCity.Shape, IGeometry4))
            nearCities.Add(aNearCity)
            candidateCity = featureCursor.NextFeature()
        End While

        nearCities.Sort()
        dgv.DataSource = nearCities
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        mxdoc.ActiveView.Extent = city.Shape.Envelope
        mxdoc.ActiveView.Refresh()
    End Sub
End Class