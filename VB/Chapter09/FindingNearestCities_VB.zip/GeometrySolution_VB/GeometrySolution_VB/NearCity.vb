﻿Public Class NearCity
    Implements IComparable(Of NearCity)

    Public Property Name As String

    Public Property Distance As Double

  
    Public Sub New(ByVal name As String)
        Me.Name = name
    End Sub


    Public Function CompareTo(ByVal other As NearCity) As Integer Implements System.IComparable(Of NearCity).CompareTo
        If Me.Distance > other.Distance Then
            Return 1
        ElseIf Me.Distance < other.Distance Then
            Return -1
        Else
            Return 0
        End If
    End Function
End Class
