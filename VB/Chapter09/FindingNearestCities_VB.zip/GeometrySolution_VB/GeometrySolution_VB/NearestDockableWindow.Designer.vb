﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NearestDockableWindow
  Inherits System.Windows.Forms.UserControl

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing AndAlso components IsNot Nothing Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.btnCalculateDistance = New System.Windows.Forms.Button()
        Me.lstStates = New System.Windows.Forms.ListBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.lstCities = New System.Windows.Forms.ListBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.btnPopulateListOfCitiesStates = New System.Windows.Forms.Button()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv
        '
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(16, 465)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(269, 150)
        Me.dgv.TabIndex = 13
        '
        'btnCalculateDistance
        '
        Me.btnCalculateDistance.Location = New System.Drawing.Point(16, 418)
        Me.btnCalculateDistance.Name = "btnCalculateDistance"
        Me.btnCalculateDistance.Size = New System.Drawing.Size(269, 41)
        Me.btnCalculateDistance.TabIndex = 12
        Me.btnCalculateDistance.Text = "Calculate Distance"
        Me.btnCalculateDistance.UseVisualStyleBackColor = True
        '
        'lstStates
        '
        Me.lstStates.FormattingEnabled = True
        Me.lstStates.Location = New System.Drawing.Point(16, 264)
        Me.lstStates.Name = "lstStates"
        Me.lstStates.Size = New System.Drawing.Size(269, 147)
        Me.lstStates.TabIndex = 11
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(22, 236)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(19, 13)
        Me.label2.TabIndex = 10
        Me.label2.Text = "In:"
        '
        'lstCities
        '
        Me.lstCities.FormattingEnabled = True
        Me.lstCities.Location = New System.Drawing.Point(16, 77)
        Me.lstCities.Name = "lstCities"
        Me.lstCities.Size = New System.Drawing.Size(269, 147)
        Me.lstCities.TabIndex = 9
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(22, 49)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(101, 13)
        Me.label1.TabIndex = 8
        Me.label1.Text = "Find Distance From:"
        '
        'btnPopulateListOfCitiesStates
        '
        Me.btnPopulateListOfCitiesStates.Location = New System.Drawing.Point(16, -1)
        Me.btnPopulateListOfCitiesStates.Name = "btnPopulateListOfCitiesStates"
        Me.btnPopulateListOfCitiesStates.Size = New System.Drawing.Size(269, 33)
        Me.btnPopulateListOfCitiesStates.TabIndex = 7
        Me.btnPopulateListOfCitiesStates.Text = "Populate List of Cities and States"
        Me.btnPopulateListOfCitiesStates.UseVisualStyleBackColor = True
        '
        'NearestDockableWindow
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.btnCalculateDistance)
        Me.Controls.Add(Me.lstStates)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.lstCities)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnPopulateListOfCitiesStates)
        Me.Name = "NearestDockableWindow"
        Me.Size = New System.Drawing.Size(300, 614)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents dgv As System.Windows.Forms.DataGridView
    Private WithEvents btnCalculateDistance As System.Windows.Forms.Button
    Private WithEvents lstStates As System.Windows.Forms.ListBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents lstCities As System.Windows.Forms.ListBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnPopulateListOfCitiesStates As System.Windows.Forms.Button

End Class
