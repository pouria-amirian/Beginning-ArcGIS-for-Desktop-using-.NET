﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Geodatabase

Public Class CreatingANewCity
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        'finding cities layer
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim map As IMap = mxdoc.FocusMap
        Dim enumLayer As IEnumLayer = map.Layers

        Dim layer As ILayer = enumLayer.Next()
        Dim cityFLayer As IFeatureLayer2 = Nothing

        While layer IsNot Nothing
            If layer.Name = "U.S. Cities" AndAlso TypeOf layer Is IFeatureLayer2 Then
                cityFLayer = TryCast(layer, IFeatureLayer2)
            End If
            layer = enumLayer.Next()
        End While

        If cityFLayer Is Nothing Then
            Exit Sub
        End If

        Try
            Dim newCity As IFeature = cityFLayer.FeatureClass.CreateFeature()
            Dim citypoint As IPoint = New PointClass()
            citypoint.PutCoords(-118.802581987, 34.020762811)
            newCity.Shape = citypoint

            Dim nameFieldIndex As Integer = cityFLayer.FeatureClass.Fields.FindField("CITY_NAME")
            Dim stateFieldIndex As Integer = cityFLayer.FeatureClass.Fields.FindField("STATE_NAME")
            Dim popFieldIndex As Integer = cityFLayer.FeatureClass.Fields.FindField("POP1990")
            newCity.Value(nameFieldIndex) = "Malibu"
            newCity.Value(stateFieldIndex) = "California"
            newCity.Value(popFieldIndex) = 12000

            newCity.Store()
        Catch ex As Exception
            My.ArcMap.Application.StatusBar.Message(0) = ex.Message
        End Try
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
