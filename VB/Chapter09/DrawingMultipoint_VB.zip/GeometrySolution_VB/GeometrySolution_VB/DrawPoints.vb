﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI
Public Class DrawPoints
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim p1 As IPoint = New PointClass()
        p1.X = 10
        p1.Y = 10

        Dim p2 As IPoint = New PointClass()
        p2.X = 20
        p2.Y = 20

        Dim p3 As IPoint = New PointClass()
        p3.PutCoords(35, 15)

        Dim p4 As IPoint = New PointClass()
        p4.X = 40
        p4.Y = 17

        Dim p5 As IPoint = New PointClass()
        p5.X = 50
        p5.Y = 19

        Dim p6 As IPoint = New PointClass()
        p6.X = 60
        p6.Y = 18

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView

        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        'screenDisp.StartDrawing(screenDisp.hDC, screenCache);

        screenDisp.StartDrawing(0, screenCache)
        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 0
        color.Blue = 255
        color.Green = 0

        Dim simpleMarkerSymbol As ISimpleMarkerSymbol = New SimpleMarkerSymbolClass()
        'any call to draw methods must be between
        'StartDrawing() and FinishDrawing() methods
        simpleMarkerSymbol.Color = color
        screenDisp.SetSymbol(TryCast(simpleMarkerSymbol, ISymbol))
        screenDisp.DrawPoint(p1)
        screenDisp.DrawPoint(p2)
        screenDisp.DrawPoint(p3)
        screenDisp.DrawPoint(p4)
        screenDisp.DrawPoint(p5)
        screenDisp.DrawPoint(p6)
        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()
        Enabled = My.ArcMap.Application IsNot Nothing
    End Sub
End Class
