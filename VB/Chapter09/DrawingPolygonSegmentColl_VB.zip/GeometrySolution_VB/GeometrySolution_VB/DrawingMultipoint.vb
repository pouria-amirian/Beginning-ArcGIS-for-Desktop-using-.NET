﻿
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI

Public Class DrawingMultipoint
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim centerPoint As IPoint = New PointClass()
        centerPoint.PutCoords(0, 0)

        Dim fromPoint As IPoint = New PointClass()
        fromPoint.PutCoords(100, 0)

        Dim toPoint As IPoint = New PointClass()
        toPoint.PutCoords(0, 200)

        Dim circularArcConstruction As ICircularArc = New CircularArcClass()
        circularArcConstruction.PutCoords(centerPoint, fromPoint, toPoint, esriArcOrientation.esriArcClockwise)

        Dim multipoint As IMultipoint = New MultipointClass()
        Dim multipointConst As IConstructMultipoint = TryCast(multipoint, IConstructMultipoint)
        'divide circularArc in equal-length parts
        multipointConst.ConstructDivideLength(TryCast(circularArcConstruction, ICurve), 50)

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 100
        color.Blue = 255
        color.Green = 0

        Dim simpleMarkerSymbol As ISimpleMarkerSymbol = New SimpleMarkerSymbolClass()
        simpleMarkerSymbol.Color = color
        screenDisp.SetSymbol(TryCast(simpleMarkerSymbol, ISymbol))
        screenDisp.DrawMultipoint(multipoint)

        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
