﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Display
Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.ArcMapUI

Public Class DrawingPolylineUsingPointColl
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        'drawing a polyline
        Dim p1 As Point = New PointClass()
        p1.X = 10
        p1.Y = 10

        Dim p2 As IPoint = New PointClass()
        p2.X = 20
        p2.Y = 20

        Dim p3 As IPoint = New PointClass()
        p3.X = 35
        p3.Y = 15

        Dim p4 As IPoint = New PointClass()
        p4.X = 40
        p4.Y = 17

        Dim p5 As IPoint = New PointClass()
        p5.X = 50
        p5.Y = 19

        Dim p6 As IPoint = New PointClass()
        p6.X = 60
        p6.Y = 18

        Dim polyline As IPolyline = New PolylineClass()
        Dim pointColl As IPointCollection = TryCast(polyline, IPointCollection)
        pointColl.AddPoint(p1)
        pointColl.AddPoint(p2)
        pointColl.AddPoint(p3)
        pointColl.AddPoint(p4)
        pointColl.AddPoint(p5)
        pointColl.AddPoint(p6)

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim activeView As IActiveView = mxdoc.ActiveView
        Dim screenDisp As IScreenDisplay = activeView.ScreenDisplay
        Dim screenCache As Short = Convert.ToInt16(esriScreenCache.esriNoScreenCache)
        screenDisp.StartDrawing(screenDisp.hDC, screenCache)

        Dim color As IRgbColor = New RgbColorClass()
        color.Red = 255
        color.Blue = 128
        color.Green = 120

        Dim simpleLineSymbol As ISimpleLineSymbol = New SimpleLineSymbolClass()
        simpleLineSymbol.Color = color
        simpleLineSymbol.Width = 2

        screenDisp.SetSymbol(TryCast(simpleLineSymbol, ISymbol))
        screenDisp.DrawPolyline(polyline)

        screenDisp.FinishDrawing()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
