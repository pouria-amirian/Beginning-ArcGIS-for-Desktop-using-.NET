﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.ArcMapUI;

namespace GeospatialDataRenderer
{
    public class usingSimpleRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingSimpleRenderer()
        {
        }

        protected override void OnClick()
        {
            IRgbColor fillColor = new RgbColorClass();
            fillColor.Red = 243; fillColor.Green = 188; fillColor.Blue = 245;

            IRgbColor outlineColor = new RgbColorClass();
            outlineColor.Red = 14; outlineColor.Green = 99; outlineColor.Blue = 24;

            ISimpleLineSymbol outlineSymbol = new SimpleLineSymbolClass();
            outlineSymbol.Color = outlineColor;
            outlineSymbol.Width = 1.5;

            ISimpleFillSymbol simpleFillSymbol = new SimpleFillSymbolClass();
            simpleFillSymbol.Style = esriSimpleFillStyle.esriSFSSolid;
            simpleFillSymbol.Color = fillColor;
            simpleFillSymbol.Outline = outlineSymbol;

            ISimpleRenderer simpleRenderer = new SimpleRendererClass();
            simpleRenderer.Label = "USA States in the same Color";
            simpleRenderer.Symbol = simpleFillSymbol as ISymbol;

            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;

            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 statesFL = null;
            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. States (Generalized)")
                {
                    statesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (statesFL == null)
            { return; }

            IGeoFeatureLayer geoFL = statesFL as IGeoFeatureLayer;
            geoFL.Renderer = simpleRenderer as IFeatureRenderer;
            mxdoc.ActiveView.Refresh();
            mxdoc.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, geoFL, mxdoc.ActiveView.Extent);
            mxdoc.UpdateContents();
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
