﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DisplayUI;
using ESRI.ArcGIS.CartoUI;
using ESRI.ArcGIS.esriSystem;

namespace GeospatialDataRenderer
{
    public class usingCBRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingCBRenderer()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 countiesFL = null;
            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. Counties (Generalized)")
                {
                    countiesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (countiesFL == null)
            { return; }

            ITableHistogram tableHistogram = new TableHistogramClass();
            tableHistogram.Table = countiesFL.FeatureClass as ITable;
            tableHistogram.Field = "POP2000";

            IHistogram histogram = tableHistogram as IHistogram;
            object dataValues, dataFrequencies;
            histogram.GetHistogram(out dataValues, out dataFrequencies);


            IClassify classify = new QuantileClass();
            classify.SetHistogramData(dataValues, dataFrequencies);

            int numOfClasses = 5;
            classify.Classify(ref numOfClasses);
            double[] classBreaks = new double[numOfClasses];
            classBreaks = (double[])classify.ClassBreaks;

            IClassBreaksRenderer classBreaksRen = new ClassBreaksRendererClass();
            classBreaksRen.Field = "POP2000";
            classBreaksRen.BreakCount = numOfClasses;
            classBreaksRen.MinimumBreak = classBreaks[0];


            IEnumColors colors = GetColorRamp(numOfClasses);
            IFillSymbol fillSymbol = null;
            for (int i = 0; i < numOfClasses; i++)
            {
                fillSymbol = new SimpleFillSymbolClass();
                fillSymbol.Color = colors.Next();
                classBreaksRen.Symbol[i] = fillSymbol as ISymbol;
                classBreaksRen.Break[i] = classBreaks[i + 1];
                classBreaksRen.Label[i] = string.Format("{0}___{1}", classBreaks[i], classBreaks[i + 1]);
            }

            IGeoFeatureLayer countiesGFL = countiesFL as IGeoFeatureLayer;
            countiesGFL.Renderer = classBreaksRen as IFeatureRenderer;
            mxdoc.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, countiesGFL, mxdoc.ActiveView.Extent);
            mxdoc.UpdateContents();
        }

        protected override void OnUpdate()
        {
        }

        private IEnumColors GetColorRamp(int size)
        {
            IAlgorithmicColorRamp algColorRamp = new AlgorithmicColorRampClass();
            IRgbColor startColor = new RgbColorClass();
            startColor.Red = 255; startColor.Green = 204; startColor.Blue = 204;

            IRgbColor toColor = new RgbColorClass();
            toColor.Red = 219; toColor.Green = 0; toColor.Blue = 0;

            algColorRamp.FromColor = startColor;
            algColorRamp.ToColor = toColor;
            algColorRamp.Size = size;
            algColorRamp.Algorithm = esriColorRampAlgorithm.esriHSVAlgorithm;
            bool ok = true;
            algColorRamp.CreateRamp(out ok);
            return algColorRamp.Colors;
        }
    }
}
