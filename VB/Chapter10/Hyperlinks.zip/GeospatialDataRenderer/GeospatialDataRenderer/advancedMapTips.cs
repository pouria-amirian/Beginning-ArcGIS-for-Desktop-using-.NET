﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
namespace GeospatialDataRenderer
{
    public class advancedMapTips : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public advancedMapTips()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 statesFL = null;
            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. States (Generalized)")
                {
                    statesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (statesFL == null)
            { return; }

            IDisplayString displayString = statesFL as IDisplayString;
            IDisplayExpressionProperties dEP = displayString.ExpressionProperties;
            if ((statesFL as ILayer).ShowTips == false)
            {
                (statesFL as ILayer).ShowTips = true;

                dEP.Expression = string.Format("\"State Name: \" +  [STATE_NAME] + vbNewline + \"State Abbreviation: \" + [STATE_ABBR] + vbNewline + \"Population :\" + [POP2000]");
                this.Checked = true;
            }
            else
            {
                ILayer aLayer = mxdoc.SelectedLayer;
                aLayer.ShowTips = true;
                (statesFL as ILayer).ShowTips = false;
                this.Checked = false;
                dEP.Expression = "";
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
