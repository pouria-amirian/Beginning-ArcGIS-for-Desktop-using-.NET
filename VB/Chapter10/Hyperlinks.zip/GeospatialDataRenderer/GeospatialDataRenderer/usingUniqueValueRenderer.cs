﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;


namespace GeospatialDataRenderer
{
    public class usingUniqueValueRenderer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingUniqueValueRenderer()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 countiesFL = null;

            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. Counties (Generalized)")
                {
                    countiesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (countiesFL == null)
            { return; }

            IFeatureLayer2 FL = map.Layer[map.LayerCount - 1] as IFeatureLayer2;
            IFeatureCursor fCursor = FL.FeatureClass.Search(null, true);

            List<string> uniqueValues = new List<string>();
            IFeature feature = fCursor.NextFeature();
            int fieldIndex = FL.FeatureClass.Fields.FindField("STATE_NAME");

            while (feature != null)
            {
                if (uniqueValues.Contains(feature.Value[fieldIndex].ToString()) == false)
                {
                    uniqueValues.Add(feature.Value[fieldIndex].ToString());
                }
                feature = fCursor.NextFeature();
            }

            IUniqueValueRenderer uVRenderer = new UniqueValueRendererClass();
            uVRenderer.FieldCount = 1;
            uVRenderer.Field[0] = "STATE_NAME";

            IEnumColors enumColors = GetColorRamp(uniqueValues.Count);
            for (int i = 0; i < uniqueValues.Count; i++)
            {
                ISimpleFillSymbol simpleFSymbol = new SimpleFillSymbolClass();
                simpleFSymbol.Color = enumColors.Next();
                uVRenderer.AddValue(uniqueValues[i], "States", simpleFSymbol as ISymbol);
            }

            IGeoFeatureLayer geoFL = FL as IGeoFeatureLayer;
            geoFL.Renderer = uVRenderer as IFeatureRenderer;
            mxdoc.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, geoFL, mxdoc.ActiveView.Extent);
            mxdoc.UpdateContents();
        }


        private IEnumColors GetColorRamp(int size)
        {
            IRandomColorRamp randomColorRamp = new RandomColorRampClass();
            randomColorRamp.Size = size;
            bool ok = true;
            randomColorRamp.CreateRamp(out ok);
            return randomColorRamp.Colors;
        }


        protected override void OnUpdate()
        {
        }
    }
}
