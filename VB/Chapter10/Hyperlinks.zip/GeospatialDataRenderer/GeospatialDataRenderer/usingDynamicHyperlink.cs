﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;


namespace GeospatialDataRenderer
{
    public class usingDynamicHyperlink : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public usingDynamicHyperlink()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            IEnumLayer layers = map.Layers;
            ILayer layer = layers.Next();
            IFeatureLayer2 statesFL = null;
            while (layer != null)
            {
                if (layer is IFeatureLayer2 && layer.Name == "U.S. States (Generalized)")
                {
                    statesFL = layer as IFeatureLayer2;
                }
                layer = layers.Next();
            }
            if (statesFL == null)
            { return; }

            IHyperlinkContainer statesHLC = statesFL as IHyperlinkContainer;
            if (this.Checked == false)
            {
                this.Checked = true;

                IFeatureCursor featureCursor = statesFL.FeatureClass.Search(null, true);

                IFeature feature = featureCursor.NextFeature();

                while (feature != null)
                {
                    IHyperlink hyperlink = new HyperlinkClass();
                    hyperlink.LinkType = esriHyperlinkType.esriHyperlinkTypeURL;
                    IPoint centroid = (feature.Shape as IArea).Centroid;
                    string link = string.Format("http://www.openstreetmap.org/?lat={0}&lon={1}&zoom=9", centroid.Y, centroid.X);
                    hyperlink.Link = link;
                    hyperlink.FeatureId = feature.OID;
                    statesHLC.AddHyperlink(hyperlink);
                    feature = featureCursor.NextFeature();
                }
            }
            else
            {
                this.Checked = false;
                int numberOfHL = statesHLC.HyperlinkCount;
                for (int i = 1; i <= numberOfHL; i++)
                {
                    statesHLC.RemoveHyperlink(0);
                }
            }

        }

        protected override void OnUpdate()
        {
        }
    }
}
