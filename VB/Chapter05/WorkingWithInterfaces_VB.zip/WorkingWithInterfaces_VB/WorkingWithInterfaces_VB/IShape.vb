﻿Public Interface I2DShape
    Function CalculateArea() As Double
    ReadOnly Property NumberOfVerices As Integer
End Interface

Public Interface I2DShape2
    Function CalculatePerimeter() As Double

End Interface

Public Class Square
    Implements I2DShape, I2DShape2

    Private side As Double
    Public Sub New(ByVal side As Double)
        Me.side = side
    End Sub
    Public Function CalculateArea() As Double Implements I2DShape.CalculateArea
        Return side * side
    End Function

    Public ReadOnly Property NumberOfVerices As Integer Implements I2DShape.NumberOfVerices
        Get
            Return 4
        End Get
    End Property

    Public Function CalculatePerimeter() As Double Implements I2DShape2.CalculatePerimeter
        Return 4 * side
    End Function
End Class