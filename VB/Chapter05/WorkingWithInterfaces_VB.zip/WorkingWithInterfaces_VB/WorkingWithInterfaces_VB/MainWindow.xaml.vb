﻿Class MainWindow 

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        'only members of I2DShape are available
        Dim mySQ As I2DShape = New Square(2.0)

        Dim area As Double = mySQ.CalculateArea()

        Dim numOfVertics = mySQ.NumberOfVerices


        'to accessing perimeter we have to cast (Query) interface
        Dim mySQ2 As I2DShape2 = TryCast(mySQ, I2DShape2)

        Dim perimeter As Double = mySQ2.CalculatePerimeter()


        'both mySQ and mySQ2 are the same object 
        'with two different ways of exposing members

        'using is keyword
        If TypeOf mySQ Is I2DShape2 Then

            'following lines of code are the same
            Dim mySQ3 As I2DShape2 = CType(mySQ, I2DShape)
            Dim mySQ4 As I2DShape2 = TryCast(mySQ, I2DShape)

        End If

    End Sub
End Class
