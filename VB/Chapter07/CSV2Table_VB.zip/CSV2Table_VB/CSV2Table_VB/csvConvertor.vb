﻿Imports ESRI.ArcGIS.Catalog
imports ESRI.ArcGIS.CatalogUI
imports ESRI.ArcGIS.DataSourcesGDB
imports ESRI.ArcGIS.Geodatabase
Imports System.IO

Public Class csvConvertor
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Enum FieldDataType
        numericField
        textField
        dateField
    End Enum

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        'using gxdiaolog to get the text file
        Dim gxd As IGxDialog = New GxDialogClass()
        gxd.AllowMultiSelect = False
        gxd.ButtonCaption = "Select txt file"
        gxd.Title = "Select a text file to be converted to a Table inside a File GDB"
        gxd.RememberLocation = True

        Dim gxTxtFilter As IGxObjectFilter = New GxFilterTextFilesClass()
        gxd.ObjectFilter = gxTxtFilter

        Dim gxEnumObj As IEnumGxObject
        gxd.DoModalOpen(My.ArcCatalog.Application.hWnd, gxEnumObj)

        Dim gxObj As IGxObject = gxEnumObj.Next()
        'user clicks on cancel button
        If gxObj Is Nothing Then
            Exit Sub
        End If

        'getting the address of text file
        Dim fileAddress As String = gxObj.FullName
        'set the name of table as the name of text file
        Dim tableName As String = gxObj.BaseName
        'again displaying gxDialog to select file GDB
        gxd.ButtonCaption = "Select FileGDB"
        gxd.Title = "Select target file Geodatabase "
        Dim gxGDBFilter As IGxObjectFilter = New GxFilterFileGeodatabasesClass()
        gxd.ObjectFilter = gxGDBFilter
        gxd.DoModalOpen(My.ArcCatalog.Application.hWnd, gxEnumObj)
        gxObj = gxEnumObj.Next()
        If gxObj Is Nothing Then
            Exit Sub
        End If
        'getting the address of fileGDB
        Dim fileGDBAddress As String = gxObj.FullName

        Dim fs As New FileStream(fileAddress, FileMode.Open)
        Dim sr As New StreamReader(fs)
        Try
            'read the first line (field names)
            Dim lineOfTxtFile As String = sr.ReadLine()
            'extracting fieldNames
            Dim spliter As String() = {","}
            Dim fieldNames As String() = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries)
            'read the second line of text file (first line of data)
            lineOfTxtFile = sr.ReadLine()
            'create fields based on the data type of first record
            Dim dataItems As String() = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries)
            'Create collection of Fields to be used to build a Table
            Dim fields As IFieldsEdit = CreateTableSchema(dataItems, fieldNames)
            'create Table instance
            Dim table As ITable = CreateTable(tableName, fields, fileGDBAddress)
            'table exists
            If table Is Nothing Then
                Exit Sub
            End If

            'create each row as reader reads the text file
            While lineOfTxtFile IsNot Nothing
                Dim row As IRow = table.CreateRow()
                'Important tip: any table must have one OID Field
                'the first field is OID
                For i As Integer = 0 To table.Fields.FieldCount - 2
                    If table.Fields.Field(i + 1).Type = esriFieldType.esriFieldTypeDouble Then
                        row.Value(i + 1) = Double.Parse(dataItems(i))
                    ElseIf table.Fields.Field(i).Type = esriFieldType.esriFieldTypeDate Then
                        row.Value(i + 1) = DateTime.Parse(dataItems(i))
                    Else
                        row.Value(i + 1) = dataItems(i).Trim()
                    End If
                Next
                'saving a row in table
                row.Store()

                lineOfTxtFile = sr.ReadLine()
                If lineOfTxtFile IsNot Nothing Then
                    dataItems = lineOfTxtFile.Split(spliter, StringSplitOptions.RemoveEmptyEntries)
                End If
            End While
        Catch ex As Exception
            My.ArcCatalog.Application.Caption = ex.Message
        Finally
            sr.Close()
            fs.Close()
        End Try
    End Sub

    Private Function CreateTable(ByVal tableName As String, ByVal fields As IFieldsEdit, ByVal fileGDBAddress As String) As ITable

        Dim wsf As IWorkspaceFactory = New FileGDBWorkspaceFactoryClass()
        Dim ws As IWorkspace = wsf.OpenFromFile(fileGDBAddress, My.ArcCatalog.Application.hWnd)

        Dim fws As IFeatureWorkspace = TryCast(ws, IFeatureWorkspace)
        Dim ws2 As IWorkspace2 = TryCast(ws, IWorkspace2)
        If Not ws2.NameExists(esriDatasetType.esriDTTable, tableName) Then
            Dim table As ITable = fws.CreateTable(tableName, fields, Nothing, Nothing, "")
            Return table
        End If
        Return Nothing
    End Function

    Private Function DetermineTheFieldType(ByVal item As String) As FieldDataType
        Dim num As Double
        Dim dateVar As DateTime
        If Double.TryParse(item, num) Then
            Return FieldDataType.numericField
        ElseIf DateTime.TryParse(item, dateVar) Then
            Return FieldDataType.dateField
        End If
        'otherwise it is text
        Return FieldDataType.textField
    End Function


    Private Function CreateTableSchema(ByVal dataItemsOfFirstLine As String(), ByVal fieldNames As String()) As IFieldsEdit
        Dim fields As IFieldsEdit = New FieldsClass()
        fields.FieldCount_2 = fieldNames.Length + 1
        'creating OID field
        Dim OIDField As IFieldEdit = TryCast(New FieldClass(), IFieldEdit2)
        OIDField.Name_2 = "ObjectIDentifier"
        OIDField.Type_2 = esriFieldType.esriFieldTypeOID
        fields.Field_2(0) = OIDField

        For i As Integer = 0 To fieldNames.Length - 1
            Dim newField As IFieldEdit2 = TryCast(New FieldClass(), IFieldEdit2)
            Dim FDT As FieldDataType = DetermineTheFieldType(dataItemsOfFirstLine(i))

            newField.Name_2 = fieldNames(i).Trim()

            Select Case FDT
                Case FieldDataType.numericField
                    newField.Type_2 = esriFieldType.esriFieldTypeDouble

                Case FieldDataType.dateField
                    newField.Type_2 = esriFieldType.esriFieldTypeDate

                Case Else
                    newField.Type_2 = esriFieldType.esriFieldTypeString

            End Select

            fields.Field_2(i + 1) = newField
        Next
        Return fields
    End Function


    Protected Overrides Sub OnUpdate()
        Enabled = My.ArcCatalog.Application IsNot Nothing
    End Sub
End Class
