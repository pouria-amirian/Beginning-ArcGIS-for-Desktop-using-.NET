﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Geodatabase

Public Class SimpleSchemaReporter
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim mxDoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)

        If TypeOf mxDoc.SelectedItem Is IFeatureLayer2 OrElse TypeOf mxDoc.SelectedItem Is ITable Then
            Dim selectedTbl As ITable = TryCast(mxDoc.SelectedItem, ITable)

            reportSchema(selectedTbl)
        End If
    End Sub

    Protected Overrides Sub OnUpdate()
        Enabled = My.ArcMap.Application IsNot Nothing
    End Sub

    Private Sub reportSchema(ByVal table As ITable)
        'Build a generic list of fldClass instances 
        Dim fldClassList As New List(Of fldClass)()


        Dim fields As IFields2 = TryCast(table.Fields, IFields2)
        For i As Integer = 0 To fields.FieldCount - 1
            Dim field As IField2 = TryCast(fields.Field(i), IField2)
            Dim fldClassInstance As New fldClass(i + 1)
            'code for dealing with each field
            fldClassInstance.AliasName = field.AliasName
            fldClassInstance.Name = field.Name

            fldClassInstance.IsNullable = field.IsNullable
            fldClassInstance.IsRequired = field.Required

            fldClassInstance.FieldType = field.Type
            fldClassInstance.Length = field.Length
            'populating list
            fldClassList.Add(fldClassInstance)
        Next
        'for being able to use the Name of Table or FeatureClass
        Dim dsTable As IDataset = TryCast(table, IDataset)

        Dim gridForm As New frmGrid()
        'databinding
        gridForm.dgv.DataSource = fldClassList
        gridForm.Text = "Simple Schema of: " + dsTable.Name
        gridForm.ShowDialog()
    End Sub
End Class


