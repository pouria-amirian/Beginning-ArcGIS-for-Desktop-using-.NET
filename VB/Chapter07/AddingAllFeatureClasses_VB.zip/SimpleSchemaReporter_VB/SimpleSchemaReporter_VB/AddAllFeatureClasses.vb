﻿Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.DataSourcesGDB
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Catalog
Imports ESRI.ArcGIS.CatalogUI
Imports ESRI.ArcGIS.Framework

Public Class AddAllFeatureClasses
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim gxd As IGxDialog = New GxDialogClass()
        gxd.AllowMultiSelect = False
        gxd.ButtonCaption = "Add FileGDB"
        gxd.Title = "Add All FeatureClasses inside FileGDB"
        gxd.RememberLocation = True

        Dim gxObjFilter As IGxObjectFilter = New GxFilterFileGeodatabasesClass()
        gxd.ObjectFilter = gxObjFilter

        Dim gxEnumObj As IEnumGxObject
        gxd.DoModalOpen(My.ArcMap.Application.hWnd, gxEnumObj)

        Dim gxObj As IGxObject = gxEnumObj.Next()
        'getting the address of fileGDB
        Dim fileGDBAddress As String = gxObj.FullName

        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim wsf As IWorkspaceFactory = New FileGDBWorkspaceFactoryClass()
        Dim fws As IFeatureWorkspace = TryCast(wsf.OpenFromFile(fileGDBAddress, My.ArcMap.Application.hWnd), IFeatureWorkspace)
        Dim ws As IWorkspace = TryCast(fws, IWorkspace)

        'get all FeatureDatasets inside fileGDB
        Dim enumDS As IEnumDataset = ws.Datasets(esriDatasetType.esriDTFeatureDataset)

        Try
            'first FeatureDataset
            Dim featureDataSet As IDataset = enumDS.Next()
            While featureDataSet IsNot Nothing
                'get all FeatureClasses inside a FeatureDataset
                Dim featureClassesInFDS As IEnumDataset = featureDataSet.Subsets
                Dim singleFeatureClassAsDataset As IDataset = featureClassesInFDS.Next()

                While singleFeatureClassAsDataset IsNot Nothing
                    If TypeOf singleFeatureClassAsDataset Is IFeatureClass Then
                        Dim singleFeatureClass As IFeatureClass = TryCast(singleFeatureClassAsDataset, IFeatureClass)
                        Dim featureLayer As IFeatureLayer = New FeatureLayerClass()
                        featureLayer.Name = singleFeatureClassAsDataset.Name
                        featureLayer.FeatureClass = singleFeatureClass
                        mxdoc.AddLayer(featureLayer)
                    End If
                    singleFeatureClassAsDataset = featureClassesInFDS.Next()
                End While
                featureDataSet = enumDS.Next()
            End While
            mxdoc.ActiveView.Refresh()
            mxdoc.UpdateContents()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message, ex.Source)
        End Try
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
