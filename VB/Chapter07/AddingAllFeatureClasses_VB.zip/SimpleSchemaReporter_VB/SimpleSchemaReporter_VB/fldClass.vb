﻿Imports ESRI.ArcGIS.Geodatabase
Public Class fldClass
    Public Property No As Integer
    Public Property AliasName As String
    Public Property Name As String

    Public Property FieldType As esriFieldType
    Public Property Length As Integer
    Public Property IsRequired As Boolean
    Public Property IsNullable As Boolean

    Public Sub New(ByVal no As Integer)
        Me.No = no
    End Sub
End Class
