﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Geodatabase;
using System.Windows.Forms;

namespace GeoprocessingProject
{
    public class MultipleRingBuffer : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public MultipleRingBuffer()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            if (map.Layer[0] == null)
            { return; }

            ILayer layer = map.Layer[0];
            IDataset dataset = layer as IDataset;

            IGeoProcessor2 gp = new GeoProcessorClass();
            gp.AddOutputsToMap = true;
            gp.OverwriteOutput = true;

            //syntax of the tool from tool's reference page
            //MultipleRingBuffer_analysis (Input_Features, Output_Feature_class, Distances,
            //{Buffer_Unit}, {Field_Name}, {Dissolve_Option}, {Outside_Polygons_Only})

            IVariantArray parameters = new VarArrayClass();
            //Input_Features
            parameters.Add(layer);
            //Output_Feature_class
            parameters.Add(dataset.BrowseName + "MRB"); 
            //you have to use ; to separate the distances (multivalue)
            parameters.Add("10;50;100");
            //{Buffer_Unit}
            parameters.Add("kilometers");
            //{Field_Name}
            parameters.Add("");
            //{Dissolve_Option}
            parameters.Add("ALL");
            gp.Execute("MultipleRingBuffer_analysis", parameters, null);
            
            object severity = null;
            MessageBox.Show(gp.GetMessages(ref severity));
            
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
