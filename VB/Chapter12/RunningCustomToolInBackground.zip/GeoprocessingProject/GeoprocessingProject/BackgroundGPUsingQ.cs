﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geoprocessor;
using ESRI.ArcGIS.AnalysisTools;
using System.Windows.Forms;

namespace GeoprocessingProject
{
    public class BackgroundGPUsingQ : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        Geoprocessor geoprocessor = null;
        Queue<IGPProcess> gpToolsQ = null;

        public BackgroundGPUsingQ()
        {
            geoprocessor = new Geoprocessor();
            gpToolsQ = new Queue<IGPProcess>();
            geoprocessor.OverwriteOutput = true;
            geoprocessor.AddOutputsToMap = true;

            geoprocessor.ToolExecuted += new EventHandler<ToolExecutedEventArgs>(geoprocessor_ToolExecuted);
        }

        protected override void OnClick()
        {
            try
            {
                string copyOfTemplateGDB = @"D:\DataFolder\fileGDB.gdb";
                gpToolsQ.Clear();

                ESRI.ArcGIS.AnalysisTools.Buffer bufferTool = new ESRI.ArcGIS.AnalysisTools.Buffer();
                bufferTool.in_features = copyOfTemplateGDB + @"\us_rivers";
                bufferTool.buffer_distance_or_field = "50 Kilometers";
                bufferTool.out_feature_class = copyOfTemplateGDB + @"\bufferRivers";

                Erase eraseTool = new Erase();
                eraseTool.in_features = copyOfTemplateGDB + @"\states";
                eraseTool.erase_features = bufferTool.out_feature_class;
                eraseTool.out_feature_class = copyOfTemplateGDB + @"\distantAreasFromRivers";

                gpToolsQ.Enqueue(bufferTool);
                gpToolsQ.Enqueue(eraseTool);

                geoprocessor.ExecuteAsync(gpToolsQ.Dequeue());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void geoprocessor_ToolExecuted(object sender, ToolExecutedEventArgs e)
        {
            IGeoProcessorResult2 result = (IGeoProcessorResult2)e.GPResult;

            try
            {
                //the first tool has executed successfully
                if (result.Status == esriJobStatus.esriJobSucceeded)
                {
                    //execute next tool in the queue using background
                    if (gpToolsQ.Count > 0)
                    {
                        geoprocessor.ExecuteAsync(gpToolsQ.Dequeue());
                    }
                }
                //If the background process of a tool fails
                //stop executing next tools in the queue
                else if (result.Status == esriJobStatus.esriJobFailed)
                {
                    string message = result.Process.Tool.Name + " failed, any remaining processes will not be executed.";
                    gpToolsQ.Clear();
                    MessageBox.Show(message, "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
