﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.esriSystem;


using ESRI.ArcGIS.Geoprocessor;
using ESRI.ArcGIS.AnalysisTools;
namespace GeoprocessingProject
{
    public class RunningCustomToolInBackground : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public RunningCustomToolInBackground()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            if (map.LayerCount < 2)
            { return; }
            Geoprocessor gp = new Geoprocessor();
            gp.AddOutputsToMap = true;
            gp.OverwriteOutput = true;

            gp.AddToolbox(@"D:\testToolbox.tbx");

            //syntax of the custom tool  
            //BufferSelectKML (BufferFeatures, Input_Feature_Layer, Output_KMZ_File) 
            IVariantArray parameters = new VarArrayClass();
            //BufferFeatures
            parameters.Add(map.Layer[1]);

            //Input_Feature_Layer
            parameters.Add(map.Layer[0]);
            //Output_KMZ_File
            parameters.Add(@"D:\selectedCities.kmz");
            //executing by Name of custom tool
            gp.ExecuteAsync("BufferSelectKML", parameters);
        }

        protected override void OnUpdate()
        {
        }
    }
}
