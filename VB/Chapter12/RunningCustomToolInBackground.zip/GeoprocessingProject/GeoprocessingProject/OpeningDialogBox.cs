﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.GeoprocessingUI;

namespace GeoprocessingProject
{
    public class OpeningDialogBox : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public OpeningDialogBox()
        {
        }

        protected override void OnClick()
        {
            string fileGDBAddress = @"D:\testFileGDB.gdb";
            string toolboxName = "testToolbox";
            string toolName = "simpleMultipleRingBuffer";

            IWorkspaceFactory fWF = new FileGDBWorkspaceFactoryClass();
            IWorkspace ws = fWF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd);
            IToolboxWorkspace toolboxWS = ws as IToolboxWorkspace;

            //access to the toolbox
            IGPToolbox toolbox = toolboxWS.OpenToolbox(toolboxName);
            //get the tool or model
            IGPTool tool = toolbox.OpenTool(toolName);
                                   
            IGPToolCommandHelper2 commandHelper = new GPToolCommandHelperClass() as IGPToolCommandHelper2;
            commandHelper.SetTool(tool);
            commandHelper.Invoke(null);


            //IArcToolboxExtension arcToolbox = ArcMap.Application.FindExtensionByName("esriGeoprocessingUI.ArcToolboxExtension") as IArcToolboxExtension;
            //arcToolbox.ArcToolbox.InvokeTool(0, tool, null, true);


        }

        protected override void OnUpdate()
        {
        }
    }
}
