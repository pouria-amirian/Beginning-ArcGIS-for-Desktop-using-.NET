﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Geodatabase;
using System.Windows.Forms;

namespace GeoprocessingProject
{
    public class UsingCustomTool : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public UsingCustomTool()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;

            IGeoProcessor2 gp = new GeoProcessorClass();
            gp.AddOutputsToMap = true;
            gp.OverwriteOutput = true;
            
            if (map.LayerCount < 2)
            { return; }

            gp.AddToolbox(@"D:\testToolbox.tbx");
            
            //syntax of the custom tool  
            //BufferSelectKML (BufferFeatures, Input_Feature_Layer, Output_KMZ_File) 
            IVariantArray parameters = new VarArrayClass();
            //BufferFeatures
            parameters.Add(map.Layer[1]);

            //Input_Feature_Layer
            parameters.Add(map.Layer[0]);

            //Output_KMZ_File
            parameters.Add(@"D:\selectedCities.kmz");

            //executing by Name of custom tool
            gp.Execute("BufferSelectKML", parameters, null);

            object severity = null;
            MessageBox.Show(gp.GetMessages(ref severity));
        }

        protected override void OnUpdate()
        {
        }
    }
}
