﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Geodatabase;

using ESRI.ArcGIS.Geoprocessor;
using ESRI.ArcGIS.AnalysisTools;

using System.Windows.Forms;

namespace GeoprocessingProject
{
    public class MultipleRingBufferManaged : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public MultipleRingBufferManaged()
        {
        }

        protected override void OnClick()
        {
            IMxDocument mxdoc = ArcMap.Application.Document as IMxDocument;
            IMap map = mxdoc.FocusMap;
            if (map.Layer[0] == null)
            { return; }

            ILayer layer = map.Layer[0];
            IDataset dataset = layer as IDataset;

            Geoprocessor gp = new Geoprocessor();
            gp.AddOutputsToMap = true;
            gp.OverwriteOutput = true;

            ESRI.ArcGIS.AnalysisTools.MultipleRingBuffer multipleRB = new ESRI.ArcGIS.AnalysisTools.MultipleRingBuffer();
            multipleRB.Buffer_Unit = "Kilometers";
            multipleRB.Dissolve_Option = "ALL";
            multipleRB.Distances = "10;50;100";
            multipleRB.Input_Features = layer;
            multipleRB.Output_Feature_class = dataset.BrowseName + "MRB";
            gp.Execute(multipleRB, null);

            object severity = null;
            MessageBox.Show(gp.GetMessages(ref severity));
        }

        protected override void OnUpdate()
        {
        }
    }
}
