﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.CatalogUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Catalog

Public Class ShowAddDialog
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)

        'Setting some properties for GxDialog instance
        Dim gxd As IGxDialog = New GxDialogClass()
        gxd.AllowMultiSelect = True
        gxd.ButtonCaption = "Add Layer"
        gxd.Title = "Add Layer Window"
        gxd.RememberLocation = True

        'creating filter for GxDialog instance
        Dim gxObjFilter As IGxObjectFilter = New GxFilterLayersClass()
        gxd.ObjectFilter = gxObjFilter

        'Adding each selected layer to map
        Dim gxEnumObj As IEnumGxObject
        gxd.DoModalOpen(My.ArcMap.Application.hWnd, gxEnumObj)

        Dim gxObj As IGxObject = gxEnumObj.Next()
        While gxObj IsNot Nothing
            Dim gxlayer As IGxLayer = TryCast(gxObj, IGxLayer)
            mxdoc.AddLayer(gxlayer.Layer)
            gxObj = gxEnumObj.Next()
        End While
        'refreshing the main window and TOC
        mxdoc.ActiveView.Refresh()
        mxdoc.UpdateContents()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
