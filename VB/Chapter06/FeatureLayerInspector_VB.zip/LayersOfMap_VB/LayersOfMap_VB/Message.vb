﻿Public Class Message

End Class