﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Framework


Public Class LayersOfMapButton
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim data As String = ""
        Dim doc As IDocument = My.ArcMap.Application.Document
        Dim mxDoc As IMxDocument = TryCast(doc, IMxDocument)
        Dim map As IMap = mxDoc.FocusMap
        'using layerCount property
        data += "Using LayerCount Property " + vbNewLine
        Dim layer As ILayer
        For i As Integer = 0 To map.LayerCount - 1
            layer = map.Layer(i)
            data += " >> " + layer.Name + vbNewLine
        Next
        'Terminating layer object  
        layer = Nothing
        data += String.Format("{0} Map contains {1} Layers" + vbNewLine, map.Name, map.LayerCount)
        data += "--------------------------------------" + vbNewLine
        data += "Using Layers Property " + vbNewLine
        Dim enumLayer As IEnumLayer = map.Layers
        layer = enumLayer.[Next]()
        Dim j As Integer = 0
        While layer IsNot Nothing
            j += 1
            data += " >> " + layer.Name + vbNewLine
            layer = enumLayer.[Next]()
        End While
        data += String.Format("{0} Map contains {1} Layers", map.Name, j)
        Dim msgForm As New Message()
        msgForm.lbl.Text = data
        msgForm.ShowDialog()
    End Sub

    Protected Overrides Sub OnUpdate()
        Enabled = My.ArcMap.Application IsNot Nothing
    End Sub
End Class
