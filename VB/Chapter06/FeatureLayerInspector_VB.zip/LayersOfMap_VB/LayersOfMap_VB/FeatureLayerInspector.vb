﻿Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.Geodatabase
Imports ESRI.ArcGIS.Geometry



Public Class FeatureLayerInspector
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()
        Dim data As String = ""
        Dim mxdoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim selectedLayer As ILayer = mxdoc.SelectedLayer
        If selectedLayer IsNot Nothing Then
            If TypeOf selectedLayer Is IFeatureLayer2 Then
                'using IFeatureLayer2 interface
                Dim selectedFL As IFeatureLayer2 = TryCast(selectedLayer, IFeatureLayer2)
                data += "Data Source Type: " + selectedFL.DataSourceType + vbNewLine
                data += "Shape Type: " + selectedFL.ShapeType.ToString + vbNewLine
                data += "Is Selectable? " + selectedFL.Selectable.ToString + vbNewLine
                data += "Primary Display Field: " + selectedFL.DisplayField + vbNewLine
                'using ILayerFields interface
                Dim selectedLayerFields As ILayerFields = TryCast(selectedFL, ILayerFields)
                data += "field count: " + selectedLayerFields.FieldCount.ToString + vbNewLine
                data += "Third Field Name: " + selectedLayerFields.Field(2).Name
                'using IGeoFeatureLayer interface
                Dim selectedGFL As IGeoFeatureLayer = TryCast(selectedFL, IGeoFeatureLayer)
                'toggle labeling for selected layer
                If selectedGFL.DisplayAnnotation = True Then
                    selectedGFL.DisplayAnnotation = False
                Else
                    selectedGFL.DisplayAnnotation = True
                End If
                'since you modify rendering of the map by toggling labeling
                'you have to refresh the main window of ArcMap
                mxdoc.ActiveView.Refresh()
                Dim msgForm As New Message()
                msgForm.lbl.Text = data
                msgForm.ShowDialog()
            End If
        End If
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub
End Class
