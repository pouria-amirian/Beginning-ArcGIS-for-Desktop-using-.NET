Imports ESRI.ArcGIS.Geometry
Imports ESRI.ArcGIS.Carto
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports ESRI.ArcGIS.ADF.BaseClasses
Imports ESRI.ArcGIS.ADF.CATIDs
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI

<ComClass(ZoomToActiveLayer.ClassId, ZoomToActiveLayer.InterfaceId, ZoomToActiveLayer.EventsId), _
 ProgId("UsingAOSDKVB.ZoomToActiveLayer")> _
Public NotInheritable Class ZoomToActiveLayer
    Inherits BaseCommand

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "a4a8e531-cea0-4d24-873a-dfa67a47fa2e"
    Public Const InterfaceId As String = "6ede9d44-cb89-43fd-951c-5da493af4c89"
    Public Const EventsId As String = "48da1700-5311-430c-97b8-15bfe0c264ef"
#End Region

#Region "COM Registration Function(s)"
    <ComRegisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub RegisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryRegistration(registerType)

        'Add any COM registration code after the ArcGISCategoryRegistration() call

    End Sub

    <ComUnregisterFunction(), ComVisibleAttribute(False)> _
    Public Shared Sub UnregisterFunction(ByVal registerType As Type)
        ' Required for ArcGIS Component Category Registrar support
        ArcGISCategoryUnregistration(registerType)

        'Add any COM unregistration code after the ArcGISCategoryUnregistration() call

    End Sub

#Region "ArcGIS Component Category Registrar generated code"
    Private Shared Sub ArcGISCategoryRegistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxCommands.Register(regKey)

    End Sub
    Private Shared Sub ArcGISCategoryUnregistration(ByVal registerType As Type)
        Dim regKey As String = String.Format("HKEY_CLASSES_ROOT\CLSID\{{{0}}}", registerType.GUID)
        MxCommands.Unregister(regKey)

    End Sub

#End Region
#End Region


    Private m_application As IApplication

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()

        ' TODO: Define values for the public properties
        MyBase.m_category = "ArcGISBook_VB"  'localizable text 
        MyBase.m_caption = "Zooms To Active Layer_VB"   'localizable text 
        MyBase.m_message = "Zooms To Active Layer inside TOC_VB"   'localizable text 
        MyBase.m_toolTip = "Zooms To Active Layer inside TOC_VB" 'localizable text 
        MyBase.m_name = "ZoomToActiveLayer"  'unique id, non-localizable (e.g. "MyCategory_ArcMapCommand")

        Try
            'TODO: change bitmap name if necessary
            Dim bitmapResourceName As String = Me.GetType().Name + ".bmp"
            MyBase.m_bitmap = New Bitmap(Me.GetType(), bitmapResourceName)
        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap")
        End Try


    End Sub


    Public Overrides Sub OnCreate(ByVal hook As Object)
        If Not hook Is Nothing Then
            m_application = CType(hook, IApplication)

            'Disable if it is not ArcMap
            If TypeOf hook Is IMxApplication Then
                MyBase.m_enabled = True
            Else
                MyBase.m_enabled = False
            End If
        End If

        ' TODO:  Add other initialization code
    End Sub

    Public Overrides Sub OnClick()

        Dim mxdoc As IMxDocument = TryCast(m_application.Document, IMxDocument)
        ZoomToActiveLayerInTOC(mxdoc)


    End Sub
    

#Region "Zoom to Active Layer in TOC"

'''<summary>Zooms to the selected layer in the TOC associated with the active view.</summary>
''' 
'''<param name="mxDocument">An IMxDocument interface</param>
'''  
'''<remarks></remarks>
Public Sub ZoomToActiveLayerInTOC(ByVal mxDocument As IMxDocument)

  If mxDocument Is Nothing Then
    Return
  End If

  ' Get the map
  Dim activeView As IActiveView = mxDocument.ActiveView

  ' Get the TOC
  Dim contentsView As IContentsView = mxDocument.CurrentContentsView

  ' Get the selected layer
  Dim selectedItem As System.Object = contentsView.SelectedItem
  If Not (TypeOf selectedItem Is ILayer) Then
    Return
  End If

  Dim layer As ILayer = TryCast(selectedItem, ILayer) ' Dynamic Cast

  ' Zoom to the extent of the layer and refresh the map
  activeView.Extent = layer.AreaOfInterest
  activeView.Refresh()

End Sub
#End Region

End Class



