import arcpy
mxd = arcpy.mapping.MapDocument('Current')
df = arcpy.mapping.ListDataFrames(mxd)[0]
lyrs = arcpy.mapping.ListLayers(mxd)
for lyr in lyrs :
	arcpy.mapping.RemoveLayer(df, lyr)
