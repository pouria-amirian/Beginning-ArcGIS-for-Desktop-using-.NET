﻿Imports ESRI.ArcGIS.esriSystem
Imports ESRI.ArcGIS.Framework
Imports ESRI.ArcGIS.ArcMapUI
Imports ESRI.ArcGIS.Carto
Imports ESRI.ArcGIS.Desktop.AddIns

Public Class RemoveAllLayers
    Inherits ESRI.ArcGIS.Desktop.AddIns.Button

    Public Sub New()

    End Sub

    Protected Overrides Sub OnClick()

        Dim mxDoc As IMxDocument = TryCast(My.ArcMap.Application.Document, IMxDocument)
        Dim map As IMap = mxDoc.FocusMap
        map.ClearLayers()
        Dim activeView As IActiveView = TryCast(map, IActiveView)
        activeView.Refresh()
        mxDoc.UpdateContents()
    End Sub

    Protected Overrides Sub OnUpdate()

    End Sub

End Class
