﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Windows.Forms;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geometry;

namespace FeatureDataManagement
{
    public class CreatingFileGeodatabase : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public CreatingFileGeodatabase()
        {
        }

        protected override void OnClick()
        {
            try
            {
                string path = util.path;
                string fileGDBName = util.fileGDBName;

                if (System.IO.Directory.Exists(path + "\\" + fileGDBName))
                {
                    MessageBox.Show("there is a file geodatabase with the same path and name");
                    return;
                }

                //for file Geodatabase
                Guid fgdbGUID = new Guid("71FE75F0-EA0C-4406-873E-B7D53748AE7E");
                Type factoryType = Type.GetTypeFromCLSID(fgdbGUID);

                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                wsF.Create(path, fileGDBName, null, ArcMap.Application.hWnd);
                MessageBox.Show(fileGDBName + " created successsfully");

                //releasing all the references to singleton COM objecte
                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
