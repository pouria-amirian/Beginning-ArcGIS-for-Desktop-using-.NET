﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Windows.Forms;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesGDB;
using ESRI.ArcGIS.Geometry;

namespace FeatureDataManagement
{
    public class CreatingFDS : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public CreatingFDS()
        {
        }

        protected override void OnClick()
        {
            try
            {
                Type factoryType = Type.GetTypeFromProgID("esriDataSourcesGDB.FileGDBWorkspaceFactory");
                IWorkspaceFactory wsF = Activator.CreateInstance(factoryType) as IWorkspaceFactory;
                string fileGDBAddress = util.path + "\\" + util.fileGDBName;
                string fdsName = util.featureDatasetName;
                //check the existance of the file geodatabase
                if (!System.IO.Directory.Exists(fileGDBAddress))
                {
                    MessageBox.Show("there isn't a file geodatabase with the specified path and name");
                    return;
                }

                IFeatureWorkspace fws = wsF.OpenFromFile(fileGDBAddress, ArcMap.Application.hWnd) as IFeatureWorkspace;
                //check the existnace of FeatureDataset
                IWorkspace2 ws = fws as IWorkspace2;
                if (ws.get_NameExists(esriDatasetType.esriDTFeatureDataset, fdsName) == true)
                {
                    MessageBox.Show(string.Format("The {0} FeatureDataset already exist in the {1} file geodatabase", fdsName, util.fileGDBName));
                    return;
                }

                //create SRS object
                ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironmentClass();
                int coordinateSystemID = (int)esriSRGeoCSType.esriSRGeoCS_WGS1984;
                ISpatialReference spatialReference = spatialReferenceFactory.CreateGeographicCoordinateSystem(coordinateSystemID);
                //creating FeatureDataset
                IFeatureDataset fds = fws.CreateFeatureDataset(fdsName, spatialReference);

                //Creating FeatureClass
                IFieldsEdit fields = new FieldsClass();
                fields.FieldCount_2 = 5;

                IFieldEdit field = new FieldClass();
                field.Name_2 = "ObjectID";
                field.Type_2 = esriFieldType.esriFieldTypeOID;
                fields.Field_2[0] = field;

                //there is no need to set the spatial reference for FeatureClasses inside a FeatureDataset
                //since the spatial reference system is inherited from the parent FeatureDataset
                IGeometryDefEdit geometryDef = new GeometryDefClass();
                geometryDef.GeometryType_2 = esriGeometryType.esriGeometryPoint;

                field = new FieldClass();
                field.Name_2 = "Shape";
                field.Type_2 = esriFieldType.esriFieldTypeGeometry;
                field.GeometryDef_2 = geometryDef;
                fields.Field_2[1] = field;

                field = new FieldClass();
                field.Name_2 = "Name";
                field.Type_2 = esriFieldType.esriFieldTypeString;
                fields.Field_2[2] = field;

                field = new FieldClass();
                field.Name_2 = "Population";
                field.Type_2 = esriFieldType.esriFieldTypeInteger;
                fields.Field_2[3] = field;


                field = new FieldClass();
                field.Name_2 = "Area";
                field.Type_2 = esriFieldType.esriFieldTypeDouble;
                fields.Field_2[4] = field;

                fds.CreateFeatureClass(util.featureClassName + "2", fields, null, null, esriFeatureType.esriFTSimple, "Shape", null);

                int refsLeft = 0;
                do
                {
                    refsLeft = System.Runtime.InteropServices.Marshal.ReleaseComObject(wsF);
                }
                while (refsLeft > 0);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        protected override void OnUpdate()
        {
        }
    }
}
